"""Кланы: создание, участники и роли, казна, магазин нападения и защиты, войны с другими кланами."""
import random

from ..data.clans import (
    BASE_MEMBERS, CLAN_ITEMS, CLAN_ITEMS_BY_KEY, CREATE_COST, DEF_LOOT_MAX, DEF_LOOT_PCT, DEF_LOSE_TROPHIES,
    DEF_WIN_TROPHIES, DEFENDER_SHIELD, LEVEL_POWER_BONUS, LOSE_TROPHIES, LOSS_LOSER_PCT, LOSS_WINNER_PCT, MAX_LEVEL,
    MAX_NAME, MAX_STACK, MEMBER_POWER, MIN_ATTACKERS, MIN_NAME, PAIR_COOLDOWN, UPGRADE_COST, WAR_COOLDOWN,
    WIN_LOOT_MAX, WIN_LOOT_PCT, WIN_TROPHIES, max_members,
)
from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, dur, mention, num, rub
from ..util.money import _value
from ..util.pages import paginate

RNG = random.Random()            # в тестах подменяется на предсказуемый
ROLE_RANK = {'member': 1, 'officer': 2, 'leader': 3}
ROLE_ICON = {'leader': '👑', 'officer': '⭐', 'member': '👤'}
ROLE_NAME = {'leader': 'Глава', 'officer': 'Офицер', 'member': 'Боец'}
PAGE = 3
STACKABLE = ('attack', 'defense')


class _Stop(Exception):
    pass


# ---------------------------------------------------------------------------
# Данные клана и расчёт мощи
# ---------------------------------------------------------------------------

async def my_clan(db, scope: int, uid: int):
    """Клан игрока вместе с его ролью (my_role) или None."""
    return await db.fetchrow(
        'SELECT c.*, m.role AS my_role, m.donated AS my_donated FROM clan_members m JOIN clans c ON c.id = m.clan_id '
        'WHERE m.scope=$1 AND m.user_id=$2', scope, uid)


async def clan_by_id(db, scope: int, clan_id: int):
    return await db.fetchrow('SELECT * FROM clans WHERE id=$1 AND scope=$2', clan_id, scope)


async def find_clan(db, scope: int, ref: str):
    """Клан по названию (без учёта регистра) или по началу названия, если оно однозначно."""
    ref = (ref or '').strip().casefold()
    if not ref:
        return None
    rows = await db.fetch('SELECT * FROM clans WHERE scope=$1', scope)
    exact = [r for r in rows if r['name'].casefold() == ref]
    if exact:
        return exact[0]
    starts = [r for r in rows if r['name'].casefold().startswith(ref)]
    return starts[0] if len(starts) == 1 else None


async def stock(db, clan_id: int) -> dict[str, int]:
    rows = await db.fetch('SELECT item_key, qty FROM clan_items WHERE clan_id=$1 AND qty > 0', clan_id)
    return {r['item_key']: r['qty'] for r in rows if r['item_key'] in CLAN_ITEMS_BY_KEY}


async def member_count(db, clan_id: int) -> int:
    return await db.fetchval('SELECT COUNT(*) FROM clan_members WHERE clan_id=$1', clan_id)


def power(items: dict[str, int], level: int, members: int) -> tuple[int, int]:
    """(мощь атаки, мощь защиты) клана: предметы + бойцы, умноженные на бонус уровня."""
    atk = deff = MEMBER_POWER * members
    for key, qty in items.items():
        item = CLAN_ITEMS_BY_KEY.get(key)
        if item is None:
            continue
        if item.kind == 'attack':
            atk += item.power * qty
        elif item.kind == 'defense':
            deff += item.power * qty
    mult = 1 + LEVEL_POWER_BONUS * (level - 1)
    return int(atk * mult), int(deff * mult)


def clean_name(raw: str) -> str:
    name = raw
    for ch in '[]|«»"\'':
        name = name.replace(ch, '')
    return ' '.join(name.split())[:MAX_NAME]


def shield_text(clan, now: int) -> str:
    left = clan['shield_until'] - now
    return f'🔰 Щит мира: ещё {dur(left)}' if left > 0 else '🔓 Щита мира нет'


def _need(role: str, minimum: str) -> bool:
    return ROLE_RANK.get(role, 0) >= ROLE_RANK[minimum]


# ---------------------------------------------------------------------------
# Главная команда /клан
# ---------------------------------------------------------------------------

@registry.command('clan', names=['клан', 'clan', 'кланы', 'clans'], desc='кланы: создать, казна, магазин, войны',
                  section='clans', usage='[создать|пригласить|взнос ...]')
async def cmd_clan(ctx):
    await ctx.wallet()
    argv = ctx.argv
    sub = argv[0].lower().replace('ё', 'е') if argv else ''
    rest = ' '.join(argv[1:])
    handlers = {
        'создать': _create, 'create': _create,
        'принять': _accept, 'вступить': _accept, 'accept': _accept, 'join': _accept,
        'пригласить': _invite, 'invite': _invite,
        'выйти': _leave, 'leave': _leave,
        'исключить': _kick, 'kick': _kick,
        'повысить': _promote, 'promote': _promote,
        'понизить': _demote, 'demote': _demote,
        'лидер': _transfer, 'передать': _transfer,
        'взнос': _donate, 'внести': _donate, 'donate': _donate,
        'снять': _withdraw, 'withdraw': _withdraw,
        'состав': _members, 'members': _members,
        'улучшить': _upgrade, 'upgrade': _upgrade,
        'распустить': _disband, 'disband': _disband,
        'инфо': _info, 'info': _info,
    }
    if sub in ('магазин', 'shop'):
        ctx.args = ''
        return await cmd_clan_shop(ctx)
    if sub in ('война', 'war'):
        ctx.args = rest
        return await cmd_clan_war(ctx)
    if sub in ('топ', 'top'):
        from .top import top_clans
        return await top_clans(ctx)
    if sub in handlers:
        ctx.args = rest
        return await handlers[sub](ctx)
    await _home(ctx)


async def _home(ctx, intro: str = ''):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None:
        invite = await ctx.db.fetchrow(
            'SELECT i.*, c.name FROM clan_invites i JOIN clans c ON c.id = i.clan_id WHERE i.scope=$1 AND i.user_id=$2',
            ctx.scope, ctx.user_id)
        lines = [f'{intro}⚔ Кланы\n{SEP}',
                 'Клан - это команда игроков с общей казной. В магазине клана покупают оружие и защиту, '
                 'а затем воюют с другими кланами за добычу и трофеи.', '',
                 f'Создать клан стоит {rub(CREATE_COST)}. Вступить можно по приглашению главы или офицера.']
        kb = ctx.kb().btn('➕ Создать клан', 'clan', 'создать', color='positive')
        if invite:
            lines.append(f'\n💌 Вас пригласили в клан «{invite["name"]}»!')
            kb.row().btn('✅ Принять приглашение', 'clan', 'принять', color='positive')
        kb.row().btn('🏆 Топ кланов', 'top', 'клан').btn('🏠 Меню', 'menu')
        return await ctx.respond('\n'.join(lines), kb)

    now = accounts.now()
    items = await stock(ctx.db, clan['id'])
    n = await member_count(ctx.db, clan['id'])
    atk, deff = power(items, clan['level'], n)
    lines = [
        f'{intro}🏰 Клан «{clan["name"]}»\n{SEP}',
        f'⭐ Уровень: {clan["level"]} из {MAX_LEVEL} · 👥 {n} из {max_members(clan["level"])}',
        f'🏆 Трофеи: {clan["trophies"]} · побед {clan["wins"]} / поражений {clan["losses"]}',
        f'💰 Казна: {rub(clan["bank"])}',
        f'⚔ Атака: {num(atk)} · 🛡 Защита: {num(deff)}',
        shield_text(clan, now),
        '',
        f'Ваша роль: {ROLE_ICON[clan["my_role"]]} {ROLE_NAME[clan["my_role"]]} · внесено в казну: {rub(clan["my_donated"])}',
    ]
    kb = ctx.kb()
    if _need(clan['my_role'], 'officer'):
        kb.btn('🛒 Магазин', 'clan_shop', color='primary').btn('⚔ В бой', 'clan_war', color='negative').row()
    kb.btn('👥 Состав', 'clan', 'состав').btn('💰 Взнос', 'clan', 'взнос').row()
    if _need(clan['my_role'], 'officer'):
        kb.btn('⬆ Улучшить', 'clan', 'улучшить')
    kb.btn('🏆 Топ', 'top', 'клан').row().btn('🚪 Выйти', 'clan', 'выйти', color='negative').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


@registry.pending('clan_name')
async def pending_clan_name(ctx, data):
    await _create(ctx)


# ---------------------------------------------------------------------------
# Создание, приглашения, состав
# ---------------------------------------------------------------------------

async def _create(ctx):
    raw = ctx.args.strip()
    if not raw:
        return await ctx.ask(
            'clan_name', f'➕ Создание клана\n{SEP}\nОтправьте название клана следующим сообщением '
                         f'({MIN_NAME}-{MAX_NAME} символов). Создание стоит {rub(CREATE_COST)}.',
            ctx.kb().btn('❌ Отмена', 'clan'))
    name = clean_name(raw)
    if len(name) < MIN_NAME:
        return await ctx.respond(f'❗ Название должно быть не короче {MIN_NAME} символов')
    try:
        async with ctx.db.transaction() as tx:
            if await tx.fetchval('SELECT 1 FROM clan_members WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id):
                raise _Stop('in_clan')
            taken = await tx.fetch('SELECT name FROM clans WHERE scope=$1', ctx.scope)
            if any(r['name'].casefold() == name.casefold() for r in taken):
                raise _Stop('taken')
            if await accounts.change(tx, ctx.scope, ctx.user_id, -CREATE_COST, 'rub', 'clan', f'клан {name}') is None:
                raise _Stop('money')
            cid = await tx.fetchval(
                'INSERT INTO clans (scope, name, owner_id, created_at) VALUES ($1, $2, $3, $4) RETURNING id',
                ctx.scope, name, ctx.user_id, accounts.now())
            await tx.execute(
                "INSERT INTO clan_members (scope, user_id, clan_id, role, joined_at) VALUES ($1, $2, $3, 'leader', $4)",
                ctx.scope, ctx.user_id, cid, accounts.now())
    except _Stop as stop:
        return await ctx.respond({
            'in_clan': '❗ Вы уже состоите в клане. Сначала выйдите из него',
            'taken': '❗ Клан с таким названием уже есть',
            'money': f'❗ Не хватает денег: создание клана стоит {rub(CREATE_COST)}',
        }[str(stop)])
    await _home(ctx, intro=f'🎉 Клан «{name}» создан! Вы - его глава.\n\n')


async def _invite(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None or not _need(clan['my_role'], 'officer'):
        return await ctx.respond('❗ Приглашать могут глава и офицеры клана')
    target, _ = await ctx.target()
    if target is None:
        return await ctx.respond('❗ Укажите, кого пригласить: /клан пригласить @имя (или ответом на сообщение)')
    if target == ctx.user_id:
        return await ctx.respond('❗ Вы уже в клане')
    if await my_clan(ctx.db, ctx.scope, target):
        return await ctx.respond('❗ Этот игрок уже состоит в клане')
    if await member_count(ctx.db, clan['id']) >= max_members(clan['level']):
        return await ctx.respond(f'❗ В клане нет мест ({max_members(clan["level"])}). Улучшите клан, чтобы расширить его')
    await accounts.ensure_wallet(ctx.db, ctx.scope, target)
    await ctx.db.execute(
        'INSERT INTO clan_invites (scope, user_id, clan_id, ts) VALUES ($1, $2, $3, $4) '
        'ON CONFLICT (scope, user_id) DO UPDATE SET clan_id = EXCLUDED.clan_id, ts = EXCLUDED.ts',
        ctx.scope, target, clan['id'], accounts.now())
    kb = ctx.kb().btn('✅ Принять', 'clan', 'принять', color='positive', u=target)
    text = (f'💌 {await ctx.mention(target)}, вас приглашают в клан «{clan["name"]}»!\n'
            'Нажмите кнопку или напишите /клан принять')
    if ctx.is_chat:
        await ctx.respond(text, kb)
    else:
        await ctx.respond(f'✅ Приглашение отправлено: {await ctx.mention(target)}')
        await ctx.app.vk.send(target, text, kb.to_json())


async def _accept(ctx):
    try:
        async with ctx.db.transaction() as tx:
            invite = await tx.fetchrow('SELECT * FROM clan_invites WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
            if invite is None:
                raise _Stop('none')
            if await tx.fetchval('SELECT 1 FROM clan_members WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id):
                raise _Stop('in_clan')
            clan = await tx.fetchrow('SELECT * FROM clans WHERE id=$1', invite['clan_id'])
            if clan is None:
                raise _Stop('gone')
            count = await tx.fetchval('SELECT COUNT(*) FROM clan_members WHERE clan_id=$1', clan['id'])
            if count >= max_members(clan['level']):
                raise _Stop('full')
            await tx.execute(
                "INSERT INTO clan_members (scope, user_id, clan_id, role, joined_at) VALUES ($1, $2, $3, 'member', $4)",
                ctx.scope, ctx.user_id, clan['id'], accounts.now())
            await tx.execute('DELETE FROM clan_invites WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
    except _Stop as stop:
        return await ctx.respond({
            'none': 'ℹ У вас нет приглашений в клан', 'in_clan': '❗ Вы уже состоите в клане',
            'gone': '❗ Этого клана больше нет', 'full': '❗ В этом клане нет мест',
        }[str(stop)])
    await _home(ctx, intro='✅ Вы вступили в клан!\n\n')


async def _leave(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None:
        return await ctx.respond('ℹ Вы не состоите в клане')
    if clan['my_role'] == 'leader':
        if await member_count(ctx.db, clan['id']) > 1:
            return await ctx.respond('❗ Глава не может просто выйти. Передайте власть: /клан лидер @имя, '
                                     'или распустите клан: /клан распустить')
        return await _disband(ctx)
    await ctx.db.execute('DELETE FROM clan_members WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
    await ctx.respond(f'👋 Вы вышли из клана «{clan["name"]}»', ctx.kb().btn('⚔ Кланы', 'clan').btn('🏠 Меню', 'menu'))


async def _target_member(ctx, clan):
    target, _ = await ctx.target(register=False)
    if target is None:
        await ctx.respond('❗ Укажите участника: @имя, ссылка, id или ответом на сообщение')
        return None
    row = await ctx.db.fetchrow(
        'SELECT * FROM clan_members WHERE scope=$1 AND user_id=$2 AND clan_id=$3', ctx.scope, target, clan['id'])
    if row is None:
        await ctx.respond('❗ Этого игрока нет в вашем клане')
        return None
    return row


async def _kick(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None or not _need(clan['my_role'], 'officer'):
        return await ctx.respond('❗ Исключать могут глава и офицеры клана')
    row = await _target_member(ctx, clan)
    if row is None:
        return
    if row['user_id'] == ctx.user_id:
        return await ctx.respond('❗ Чтобы выйти, используйте /клан выйти')
    if ROLE_RANK[row['role']] >= ROLE_RANK[clan['my_role']]:
        return await ctx.respond('🚫 Нельзя исключить участника с той же или более высокой ролью')
    await ctx.db.execute('DELETE FROM clan_members WHERE scope=$1 AND user_id=$2', ctx.scope, row['user_id'])
    await ctx.respond(f'✅ {await ctx.mention(row["user_id"])} исключён(а) из клана')


async def _set_role(ctx, new_role: str):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None or clan['my_role'] != 'leader':
        return await ctx.respond('❗ Менять роли может только глава клана')
    row = await _target_member(ctx, clan)
    if row is None:
        return
    if row['user_id'] == ctx.user_id or row['role'] == 'leader':
        return await ctx.respond('❗ Это действие нельзя применить к главе')
    if row['role'] == new_role:
        return await ctx.respond(f'ℹ Участник уже {ROLE_NAME[new_role].lower()}')
    await ctx.db.execute('UPDATE clan_members SET role=$3 WHERE scope=$1 AND user_id=$2', ctx.scope, row['user_id'], new_role)
    await ctx.respond(f'✅ {await ctx.mention(row["user_id"])} теперь {ROLE_ICON[new_role]} {ROLE_NAME[new_role].lower()}')


async def _promote(ctx):
    await _set_role(ctx, 'officer')


async def _demote(ctx):
    await _set_role(ctx, 'member')


async def _transfer(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None or clan['my_role'] != 'leader':
        return await ctx.respond('❗ Передать власть может только глава клана')
    row = await _target_member(ctx, clan)
    if row is None:
        return
    if row['user_id'] == ctx.user_id:
        return await ctx.respond('❗ Вы и так глава')
    async with ctx.db.transaction() as tx:
        await tx.execute("UPDATE clan_members SET role='leader' WHERE scope=$1 AND user_id=$2", ctx.scope, row['user_id'])
        await tx.execute("UPDATE clan_members SET role='officer' WHERE scope=$1 AND user_id=$2", ctx.scope, ctx.user_id)
        await tx.execute('UPDATE clans SET owner_id=$2 WHERE id=$1', clan['id'], row['user_id'])
    await ctx.respond(f'👑 Новый глава клана «{clan["name"]}»: {await ctx.mention(row["user_id"])}. Вы стали офицером.')


async def _members(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None:
        return await _home(ctx)
    rows = await ctx.db.fetch('SELECT * FROM clan_members WHERE clan_id=$1', clan['id'])
    rows = sorted(rows, key=lambda r: (-ROLE_RANK[r['role']], -r['donated'], r['user_id']))
    lines = [f'👥 Состав клана «{clan["name"]}» ({len(rows)} из {max_members(clan["level"])})\n{SEP}']
    for r in rows:
        name = mention(r['user_id'], await accounts.display_name(ctx.app, r['user_id']))
        lines.append(f'{ROLE_ICON[r["role"]]} {name} - внёс {rub(r["donated"])}')
    if clan['my_role'] == 'leader':
        lines.append('\nУправление: /клан повысить @имя · /клан понизить @имя · /клан исключить @имя · /клан лидер @имя')
    elif _need(clan['my_role'], 'officer'):
        lines.append('\nУправление: /клан пригласить @имя · /клан исключить @имя')
    await ctx.respond('\n'.join(lines), ctx.kb().btn('◀ К клану', 'clan').btn('🏠 Меню', 'menu'))


async def _info(ctx):
    clan = await find_clan(ctx.db, ctx.scope, ctx.args) if ctx.args.strip() else await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None:
        return await ctx.respond('❗ Клан не найден. Топ кланов: /top клан')
    now = accounts.now()
    n = await member_count(ctx.db, clan['id'])
    atk, deff = power(await stock(ctx.db, clan['id']), clan['level'], n)
    owner = mention(clan['owner_id'], await accounts.display_name(ctx.app, clan['owner_id']))
    await ctx.respond(
        f'🏰 Клан «{clan["name"]}»\n{SEP}\n👑 Глава: {owner}\n'
        f'⭐ Уровень {clan["level"]} · 👥 {n} бойцов\n🏆 Трофеи: {clan["trophies"]} · побед {clan["wins"]} / '
        f'поражений {clan["losses"]}\n⚔ Атака: {num(atk)} · 🛡 Защита: {num(deff)}\n{shield_text(clan, now)}',
        ctx.kb().btn('⚔ Кланы', 'clan').btn('🏆 Топ', 'top', 'клан'))


# ---------------------------------------------------------------------------
# Казна: взнос, снятие, улучшение, роспуск
# ---------------------------------------------------------------------------

async def _donate(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None:
        return await _home(ctx)
    w = await ctx.wallet()
    token = ctx.argv[0] if ctx.argv else ''
    value = _value(token, w['rub']) if token else None
    amount = int(value) if value else 0
    if amount <= 0:
        text = (f'💰 Взнос в казну клана\n{SEP}\nВ казне: {rub(clan["bank"])}\nУ вас на руках: {rub(w["rub"])}\n'
                'Свою сумму: /клан взнос 5000')
        kb = (ctx.kb().btn('💰 1 000', 'clan', 'взнос 1000').btn('💰 10 000', 'clan', 'взнос 10000').row()
              .btn('💰 50%', 'clan', 'взнос 50%').btn('💰 Всё', 'clan', 'взнос все').row()
              .btn('◀ К клану', 'clan'))
        return await ctx.respond(text, kb)
    async with ctx.db.transaction() as tx:
        if await accounts.change(tx, ctx.scope, ctx.user_id, -amount, 'rub', 'clan', f'взнос в клан {clan["name"]}') is None:
            return await ctx.respond(f'❗ Недостаточно средств. На руках {rub(w["rub"])}')
        await tx.execute('UPDATE clans SET bank = bank + $2 WHERE id=$1', clan['id'], amount)
        await tx.execute('UPDATE clan_members SET donated = donated + $3 WHERE scope=$1 AND user_id=$2',
                         ctx.scope, ctx.user_id, amount)
    await _home(ctx, intro=f'✅ Внесено в казну клана: {rub(amount)}\n\n')


async def _withdraw(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None or clan['my_role'] != 'leader':
        return await ctx.respond('❗ Снимать деньги из казны может только глава клана')
    value = _value(ctx.argv[0], clan['bank']) if ctx.argv else None
    amount = int(value) if value else 0
    if amount <= 0:
        return await ctx.respond('❗ Укажите сумму. Пример: /клан снять 5000')
    async with ctx.db.transaction() as tx:
        row = await tx.fetchrow(
            'UPDATE clans SET bank = bank - $2 WHERE id=$1 AND bank >= $2 RETURNING bank', clan['id'], amount)
        if row is None:
            return await ctx.respond(f'❗ В казне только {rub(clan["bank"])}')
        await accounts.change(tx, ctx.scope, ctx.user_id, amount, 'rub', 'clan', f'из казны клана {clan["name"]}')
    await _home(ctx, intro=f'✅ Из казны снято: {rub(amount)}\n\n')


async def _upgrade(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None or not _need(clan['my_role'], 'officer'):
        return await ctx.respond('❗ Улучшать клан могут глава и офицеры')
    if clan['level'] >= MAX_LEVEL:
        return await ctx.respond('🌟 Клан уже достиг максимального уровня')
    nxt = clan['level'] + 1
    cost = UPGRADE_COST[nxt]
    if ctx.args.strip() != 'да':
        text = (f'⬆ Улучшение клана до уровня {nxt}\n{SEP}\nСтоимость (из казны): {rub(cost)}\nВ казне: {rub(clan["bank"])}\n'
                f'Даёт: {max_members(nxt)} мест (сейчас {max_members(clan["level"])}) и +{int(LEVEL_POWER_BONUS * 100)}% к мощи.')
        kb = ctx.kb()
        if clan['bank'] >= cost:
            kb.btn(f'✅ Улучшить за {rub(cost)}', 'clan', 'улучшить да', color='positive').row()
        kb.btn('◀ К клану', 'clan')
        return await ctx.respond(text + ('' if clan['bank'] >= cost else f'\n❗ Не хватает {rub(cost - clan["bank"])}'), kb)
    row = await ctx.db.fetchrow(
        'UPDATE clans SET bank = bank - $2, level = level + 1 WHERE id=$1 AND level=$3 AND bank >= $2 RETURNING level',
        clan['id'], cost, clan['level'])
    if row is None:
        return await ctx.respond(f'❗ В казне не хватает денег: нужно {rub(cost)}')
    await _home(ctx, intro=f'🌟 Клан улучшен до уровня {row["level"]}!\n\n')


async def _disband(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None or clan['my_role'] != 'leader':
        return await ctx.respond('❗ Распустить клан может только глава')
    if ctx.args.strip() != 'да':
        return await ctx.respond(
            f'⚠ Распустить клан «{clan["name"]}»?\nКазна ({rub(clan["bank"])}) вернётся вам, а весь арсенал будет потерян.',
            ctx.kb().btn('✅ Да, распустить', 'clan', 'распустить да', color='negative').btn('❌ Отмена', 'clan'))
    async with ctx.db.transaction() as tx:
        row = await tx.fetchrow('DELETE FROM clans WHERE id=$1 AND owner_id=$2 RETURNING bank', clan['id'], ctx.user_id)
        if row is None:
            return await ctx.respond('⚠ Клан уже распущен')
        await tx.execute('DELETE FROM clan_members WHERE clan_id=$1', clan['id'])
        await tx.execute('DELETE FROM clan_invites WHERE clan_id=$1', clan['id'])
        await tx.execute('DELETE FROM clan_items WHERE clan_id=$1', clan['id'])
        if row['bank']:
            await accounts.change(tx, ctx.scope, ctx.user_id, row['bank'], 'rub', 'clan', 'роспуск клана')
    await ctx.respond(f'💔 Клан «{clan["name"]}» распущен.', ctx.kb().btn('⚔ Кланы', 'clan').btn('🏠 Меню', 'menu'))


# ---------------------------------------------------------------------------
# Магазин клана
# ---------------------------------------------------------------------------

@registry.command('clan_shop', desc='магазин клана', section='clans', hidden=True)
async def cmd_clan_shop(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None:
        return await _home(ctx)
    arg = ctx.args.strip()
    if arg.startswith('i:'):
        return await _shop_item(ctx, clan, arg[2:])

    page = int(arg) if arg.isdigit() else 0
    items, page, total = paginate(list(CLAN_ITEMS), page, PAGE)
    have = await stock(ctx.db, clan['id'])
    atk, deff = power(have, clan['level'], await member_count(ctx.db, clan['id']))
    lines = [f'🛒 Магазин клана | стр. {page + 1}/{total}\n{SEP}',
             f'💰 Казна: {rub(clan["bank"])} · ⚔ {num(atk)} · 🛡 {num(deff)}', '']
    for it in items:
        if it.kind == 'shield':
            lines.append(f'{it.emoji} {it.title} - {rub(it.price)}\n    {it.description}')
        else:
            stat = 'атака' if it.kind == 'attack' else 'защита'
            lines.append(f'{it.emoji} {it.title} - {rub(it.price)} (+{it.power} {stat}), у вас: {have.get(it.key, 0)}')
    if not _need(clan['my_role'], 'officer'):
        lines.append('\nПокупать могут глава и офицеры клана')
    kb = ctx.kb()
    for it in items:
        kb.btn(f'{it.emoji} {it.title}', 'clan_shop', f'i:{it.key}').row()
    if page > 0:
        kb.btn('◀', 'clan_shop', str(page - 1))
    if page < total - 1:
        kb.btn('▶', 'clan_shop', str(page + 1))
    kb.row().btn('◀ К клану', 'clan').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


async def _shop_item(ctx, clan, key: str):
    it = CLAN_ITEMS_BY_KEY.get(key)
    if it is None:
        return await cmd_clan_shop(ctx)
    have = (await stock(ctx.db, clan['id'])).get(it.key, 0)
    lines = [f'{it.emoji} {it.title}\n{SEP}', it.description, '', f'💵 Цена: {rub(it.price)}']
    if it.kind == 'shield':
        lines.append(f'🔰 Защищает от нападений на {it.shield_hours} ч (время складывается)')
        lines.append(shield_text(clan, accounts.now()))
    else:
        stat = 'атаки' if it.kind == 'attack' else 'защиты'
        lines.append(f'💪 +{it.power} к мощи {stat} за штуку · у вас: {have}')
    lines.append(f'💰 Казна клана: {rub(clan["bank"])}')
    kb = ctx.kb()
    if _need(clan['my_role'], 'officer'):
        if it.kind == 'shield':
            kb.btn(f'✅ Купить за {rub(it.price)}', 'clan_buy', f'{it.key} 1', color='positive').row()
        else:
            lines.append('\nСколько купить?')
            kb.btn('×1', 'clan_buy', f'{it.key} 1', color='positive').btn('×5', 'clan_buy', f'{it.key} 5', color='positive') \
              .btn('×10', 'clan_buy', f'{it.key} 10', color='positive').row()
    else:
        lines.append('\nПокупать могут глава и офицеры клана')
    kb.btn('◀ Назад', 'clan_shop').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


@registry.command('clan_buy', desc='покупка для клана', section='clans', hidden=True)
async def cmd_clan_buy(ctx):
    clan = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if clan is None:
        return await _home(ctx)
    if not _need(clan['my_role'], 'officer'):
        return await ctx.respond('❗ Покупать могут глава и офицеры клана')
    argv = ctx.argv
    it = CLAN_ITEMS_BY_KEY.get(argv[0]) if argv else None
    if it is None:
        return await cmd_clan_shop(ctx)
    qty = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else 1
    qty = 1 if it.kind == 'shield' else max(1, min(qty, 1000))
    cost = it.price * qty
    now = accounts.now()
    try:
        async with ctx.db.transaction() as tx:
            paid = await tx.fetchrow(
                'UPDATE clans SET bank = bank - $2 WHERE id=$1 AND bank >= $2 RETURNING bank', clan['id'], cost)
            if paid is None:
                raise _Stop('money')
            if it.kind == 'shield':
                await tx.execute(
                    'UPDATE clans SET shield_until = CASE WHEN shield_until > $2 THEN shield_until + $3 ELSE $2 + $3 END '
                    'WHERE id=$1', clan['id'], now, it.shield_hours * 3600)
            else:
                have = await tx.fetchval('SELECT qty FROM clan_items WHERE clan_id=$1 AND item_key=$2', clan['id'], it.key) or 0
                if have + qty > MAX_STACK:
                    raise _Stop('stack')
                await tx.execute(
                    'INSERT INTO clan_items (clan_id, item_key, qty) VALUES ($1, $2, $3) '
                    'ON CONFLICT (clan_id, item_key) DO UPDATE SET qty = clan_items.qty + EXCLUDED.qty',
                    clan['id'], it.key, qty)
    except _Stop as stop:
        if str(stop) == 'stack':
            return await ctx.respond(f'❗ Нельзя хранить больше {MAX_STACK} штук одного предмета')
        return await ctx.respond(
            f'❗ В казне клана не хватает денег: нужно {rub(cost)}, в казне {rub(clan["bank"])}',
            ctx.kb().btn('💰 Взнос', 'clan', 'взнос').btn('◀ Назад', 'clan_shop', f'i:{it.key}'))
    kb = ctx.kb().btn('🛒 Ещё', 'clan_shop', f'i:{it.key}').btn('◀ К клану', 'clan')
    what = f'{it.title} ×{qty}' if it.kind != 'shield' else it.title
    await ctx.respond(f'✅ Куплено для клана: {it.emoji} {what} за {rub(cost)}\n💰 В казне осталось: {rub(paid["bank"])}', kb)


# ---------------------------------------------------------------------------
# Войны
# ---------------------------------------------------------------------------

async def war_blocker(db, attacker, target, now: int) -> str | None:
    """Почему нападение невозможно (или None, если можно)."""
    if not _need(attacker['my_role'], 'officer'):
        return 'Объявлять войну могут только глава и офицеры клана'
    if target['id'] == attacker['id']:
        return 'Нельзя напасть на свой клан'
    if await member_count(db, attacker['id']) < MIN_ATTACKERS:
        return f'В клане должно быть минимум {MIN_ATTACKERS} бойца, чтобы идти в бой'
    if target['shield_until'] > now:
        return f'Клан «{target["name"]}» под щитом мира ещё {dur(target["shield_until"] - now)}'
    if attacker['last_war'] and now - attacker['last_war'] < WAR_COOLDOWN:
        return f'Ваши бойцы отдыхают после боя: ещё {dur(WAR_COOLDOWN - (now - attacker["last_war"]))}'
    last_pair = await db.fetchval('SELECT MAX(ts) FROM clan_wars WHERE attacker_id=$1 AND defender_id=$2',
                                  attacker['id'], target['id'])
    if last_pair and now - last_pair < PAIR_COOLDOWN:
        return f'На этот клан недавно нападали: повторить можно через {dur(PAIR_COOLDOWN - (now - last_pair))}'
    return None


@registry.command('clan_war', names=['война', 'war'], desc='напасть на другой клан', section='clans',
                  usage='[название клана]')
async def cmd_clan_war(ctx):
    me = await my_clan(ctx.db, ctx.scope, ctx.user_id)
    if me is None:
        return await ctx.respond('❗ Для войны нужен клан. Создайте его: /клан создать <название>',
                                 ctx.kb().btn('⚔ Кланы', 'clan').btn('🏠 Меню', 'menu'))
    arg = ctx.args.strip()
    if arg.startswith('t:') and arg[2:].isdigit():
        return await _war_target(ctx, me, int(arg[2:]))
    if arg.startswith('go:') and arg[3:].isdigit():
        target = await clan_by_id(ctx.db, ctx.scope, int(arg[3:]))
    elif arg and not (arg.startswith('p') and arg[1:].isdigit()) and not arg.isdigit():
        target = await find_clan(ctx.db, ctx.scope, arg)
        if target is None:
            return await ctx.respond('❗ Клан с таким названием не найден. Список противников: /война',
                                     ctx.kb().btn('⚔ Противники', 'clan_war'))
    else:
        return await _war_list(ctx, me, int(arg[1:]) if arg.startswith('p') and arg[1:].isdigit() else 0)
    if target is None:
        return await ctx.respond('❗ Этот клан не найден')
    await _attack(ctx, me, target)


async def _war_list(ctx, me, page: int):
    now = accounts.now()
    rows = await ctx.db.fetch(
        'SELECT c.*, (SELECT COUNT(*) FROM clan_members m WHERE m.clan_id = c.id) AS members FROM clans c '
        'WHERE c.scope=$1 AND c.id != $2 ORDER BY ABS(c.trophies - $3), c.id LIMIT 30', ctx.scope, me['id'], me['trophies'])
    items, page, total = paginate(rows, page, PAGE)
    lines = [f'⚔ Противники | стр. {page + 1}/{total}\n{SEP}', f'Ваши трофеи: 🏆 {me["trophies"]}', '']
    if not rows:
        lines.append('Других кланов пока нет.')
    for r in items:
        shield = f' · 🔰 {dur(r["shield_until"] - now)}' if r['shield_until'] > now else ''
        lines.append(f'🏰 {r["name"]} · 🏆 {r["trophies"]} · 👥 {r["members"]}{shield}')
    lines.append('\nВыберите клан, чтобы посмотреть силы и напасть.')
    kb = ctx.kb()
    for r in items:
        kb.btn(f'⚔ {r["name"]}', 'clan_war', f't:{r["id"]}', color='negative').row()
    if page > 0:
        kb.btn('◀', 'clan_war', f'p{page - 1}')
    if page < total - 1:
        kb.btn('▶', 'clan_war', f'p{page + 1}')
    kb.row().btn('◀ К клану', 'clan').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


async def _war_target(ctx, me, target_id: int):
    target = await clan_by_id(ctx.db, ctx.scope, target_id)
    if target is None:
        return await ctx.respond('❗ Этот клан не найден', ctx.kb().btn('⚔ Противники', 'clan_war'))
    now = accounts.now()
    my_n, t_n = await member_count(ctx.db, me['id']), await member_count(ctx.db, target['id'])
    my_atk, my_def = power(await stock(ctx.db, me['id']), me['level'], my_n)
    t_atk, t_def = power(await stock(ctx.db, target['id']), target['level'], t_n)
    blocker = await war_blocker(ctx.db, me, target, now)
    lines = [
        f'🏰 Клан «{target["name"]}»\n{SEP}',
        f'⭐ Уровень {target["level"]} · 👥 {t_n} бойцов · 🏆 {target["trophies"]}',
        f'💰 Казна: {rub(target["bank"])} (можно отбить до {rub(min(target["bank"] * WIN_LOOT_PCT // 100, WIN_LOOT_MAX))})',
        shield_text(target, now), '',
        f'Ваша атака: {num(my_atk)} (+30% защиты) против их защиты: {num(t_def)} (+30% атаки)',
    ]
    if my_atk + my_def * 0.3 > t_def + t_atk * 0.3:
        lines.append('📊 Разведка: у вас есть преимущество')
    else:
        lines.append('📊 Разведка: враг сильнее - победа возможна лишь при удаче')
    if me['shield_until'] > now:
        lines.append('⚠ Ваш щит мира снимется, если вы нападёте')
    kb = ctx.kb()
    if blocker:
        lines.append(f'\n🚫 {blocker}')
    else:
        kb.btn('⚔ Напасть', 'clan_war', f'go:{target["id"]}', color='negative').row()
    kb.btn('◀ Назад', 'clan_war').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


def _apply_losses_sql() -> str:
    return 'UPDATE clan_items SET qty = qty - $3 WHERE clan_id=$1 AND item_key=$2 AND qty >= $3'


async def _attack(ctx, me, target):
    now = accounts.now()
    blocker = await war_blocker(ctx.db, me, target, now)
    if blocker:
        return await ctx.respond(f'🚫 {blocker}', ctx.kb().btn('⚔ Противники', 'clan_war').btn('◀ К клану', 'clan'))

    try:
        async with ctx.db.transaction() as tx:
            # Занимаем «окно нападения» одним условным UPDATE: так два быстрых нажатия не дадут два боя
            claimed = await tx.fetchrow(
                'UPDATE clans SET last_war=$2, shield_until=0 WHERE id=$1 AND last_war <= $3 RETURNING id',
                me['id'], now, now - WAR_COOLDOWN)
            if claimed is None:
                raise _Stop('cooldown')
            att = await tx.fetchrow('SELECT * FROM clans WHERE id=$1', me['id'])
            dfn = await tx.fetchrow('SELECT * FROM clans WHERE id=$1', target['id'])
            a_stock, d_stock = await stock(tx, att['id']), await stock(tx, dfn['id'])
            a_n, d_n = await member_count(tx, att['id']), await member_count(tx, dfn['id'])
            a_atk, a_def = power(a_stock, att['level'], a_n)
            d_atk, d_def = power(d_stock, dfn['level'], d_n)
            att_power = (a_atk + 0.3 * a_def) * RNG.uniform(0.85, 1.15)
            def_power = (d_def + 0.3 * d_atk) * RNG.uniform(0.85, 1.15)
            attacker_wins = att_power > def_power

            if attacker_wins:
                winner, loser, pct, cap = att, dfn, WIN_LOOT_PCT, WIN_LOOT_MAX
                w_tr, l_tr = WIN_TROPHIES, LOSE_TROPHIES
            else:
                winner, loser, pct, cap = dfn, att, DEF_LOOT_PCT, DEF_LOOT_MAX
                w_tr, l_tr = DEF_WIN_TROPHIES, DEF_LOSE_TROPHIES
            loot = min(loser['bank'] * pct // 100, cap)
            if loot:
                row = await tx.fetchrow('UPDATE clans SET bank = bank - $2 WHERE id=$1 AND bank >= $2 RETURNING bank', loser['id'], loot)
                if row is None:
                    loot = 0
            await tx.execute('UPDATE clans SET bank = bank + $2, trophies = trophies + $3, wins = wins + 1 WHERE id=$1',
                             winner['id'], loot, w_tr)
            await tx.execute(
                'UPDATE clans SET trophies = CASE WHEN trophies > $2 THEN trophies - $2 ELSE 0 END, losses = losses + 1 '
                'WHERE id=$1', loser['id'], l_tr)
            # защитник после нападения получает щит мира
            await tx.execute(
                'UPDATE clans SET shield_until = CASE WHEN shield_until > $2 THEN shield_until ELSE $2 END WHERE id=$1',
                dfn['id'], now + DEFENDER_SHIELD)
            # потери предметов
            lost = {}
            for clan_row, items, pct_loss in ((winner, a_stock if winner is att else d_stock, LOSS_WINNER_PCT),
                                              (loser, a_stock if loser is att else d_stock, LOSS_LOSER_PCT)):
                for key, qty in items.items():
                    loss = qty * pct_loss // 100
                    if loss:
                        await tx.execute(_apply_losses_sql(), clan_row['id'], key, loss)
                        lost.setdefault(clan_row['id'], 0)
                        lost[clan_row['id']] += loss
            await tx.execute(
                'INSERT INTO clan_wars (scope, attacker_id, defender_id, winner_id, loot, ts) VALUES ($1, $2, $3, $4, $5, $6)',
                ctx.scope, att['id'], dfn['id'], winner['id'], loot, now)
    except _Stop:
        return await ctx.respond('⏳ Бойцы ещё не готовы к новому бою', ctx.kb().btn('◀ К клану', 'clan'))

    icon = '🏆' if attacker_wins else '💀'
    verdict = f'{icon} Победа клана «{winner["name"]}»!'
    lines = [
        f'⚔ Война кланов\n{SEP}',
        f'«{att["name"]}» напал на «{dfn["name"]}»',
        f'Сила атаки: {num(int(att_power))} · сила обороны: {num(int(def_power))}',
        '', verdict,
        f'🏆 Трофеи: «{winner["name"]}» +{w_tr}, «{loser["name"]}» −{min(l_tr, loser["trophies"])}',
    ]
    if loot:
        lines.append(f'💰 Добыча: {rub(loot)} из казны «{loser["name"]}» → казна «{winner["name"]}»')
    else:
        lines.append('💰 В казне побеждённого нечего брать')
    if lost:
        lines.append(f'🩹 Потери: «{att["name"]}» −{lost.get(att["id"], 0)}, «{dfn["name"]}» −{lost.get(dfn["id"], 0)} ед. снаряжения')
    lines.append(f'🔰 «{dfn["name"]}» получает щит мира на {dur(DEFENDER_SHIELD)}')
    await ctx.respond('\n'.join(lines), ctx.kb().btn('🏰 Мой клан', 'clan').btn('🏆 Топ', 'top', 'клан'))
    if not ctx.is_chat:     # в личных сообщениях защищающемуся клану сообщаем отдельно
        await ctx.app.vk.send(dfn['owner_id'], f'⚔ На ваш клан «{dfn["name"]}» напал «{att["name"]}»!\n{verdict}\n'
                                               + (f'💰 Потеряно из казны: {rub(loot)}' if (loot and attacker_wins) else ''))
