"""Проверка строки подключения и повторных попыток подключения к базе (на заглушке asyncpg)."""
import asyncio
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from app import db as dbmod  # noqa: E402

# --- check_dsn / safe_dsn ---
assert dbmod.check_dsn('postgresql://u:p@host:5432/db') is None
assert dbmod.check_dsn('postgres://u:p@postgres.railway.internal:5432/railway') is None
assert dbmod.check_dsn('') and dbmod.check_dsn(None) and dbmod.check_dsn('   ')
bad = dbmod.check_dsn('postgresql://${{PGUSER}}:${{POSTGRES_PASSWORD}}@${{RAILWAY_PRIVATE_DOMAIN}}:5432/${{PGDATABASE}}')
assert bad and 'нераскрытые ссылки' in bad and '${{Postgres.DATABASE_URL}}' in bad
assert 'postgresql://' in dbmod.check_dsn('mysql://u:p@h/db') and 'адрес сервера' in dbmod.check_dsn('postgresql:///db')
safe = dbmod.safe_dsn('postgresql://postgres:СЕКРЕТ@postgres.railway.internal:5432/railway')
assert 'СЕКРЕТ' not in safe and safe == 'postgresql://postgres:***@postgres.railway.internal:5432/railway', safe
print('OK  проверка строки подключения: нераскрытые ${{...}}, неверная схема, пустая; пароль скрывается в логах')


# --- повторные попытки ---
async def main():
    dbmod.CONNECT_DELAY = 0
    attempts = []

    async def create_pool_flaky(dsn, **kw):
        attempts.append(dsn)
        if len(attempts) < 3:
            raise OSError('Name or service not known')
        return 'POOL'

    stub = types.ModuleType('asyncpg')
    stub.create_pool = create_pool_flaky
    sys.modules['asyncpg'] = stub

    d = dbmod.Database('postgres://u:p@h:5432/db')
    await d.connect()
    assert d.pool == 'POOL' and len(attempts) == 3, 'база стартует позже бота - бот подключается с третьей попытки'
    assert attempts[0] == 'postgresql://u:p@h:5432/db', 'postgres:// превращается в postgresql://'

    async def always_fail(dsn, **kw):
        raise OSError('boom')
    stub.create_pool = always_fail
    try:
        await dbmod.Database('postgresql://u:secret@h:5432/db').connect()
        raise SystemExit('ожидалась ошибка')
    except RuntimeError as e:
        text = str(e)
        assert 'за 6 попыток' in text and 'OSError: boom' in text and 'secret' not in text and 'DATABASE_URL' in text
    try:
        await dbmod.Database('postgresql://${{PGUSER}}:x@${{HOST}}:5432/db').connect()
        raise SystemExit('ожидалась ошибка')
    except RuntimeError as e:
        assert 'нераскрытые ссылки' in str(e)
    print('OK  подключение: повторные попытки, понятная итоговая ошибка без пароля, нераскрытые ссылки отсекаются сразу')

asyncio.run(main())
