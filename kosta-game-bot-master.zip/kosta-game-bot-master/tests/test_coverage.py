import ast
import asyncio
import logging
import pathlib

from sim import Sim, OWNER, CHAT_BASE
from app.framework.registry import registry
from app.modules.start import category_commands, help_pages
from app.roles import STAFF

CHAT = CHAT_BASE + 61
SRC = pathlib.Path(__file__).resolve().parents[1] / 'src' / 'app'

# Все команды из вашего списка: имя -> (ключ команды, минимальная роль в беседе)
REQUIRED = {
    'кошелек': 'wallet', 'кошелёк': 'wallet', 'эко': 'wallet', 'eco': 'wallet', 'wallet': 'wallet', 'финансы': 'wallet',
    'экономика': 'economy', 'экопомощь': 'economy', 'economy': 'economy',
    'курс': 'rates', 'курсы': 'rates', 'rates': 'rates',
    'обмен': 'exchange', 'обменять': 'exchange', 'exchange': 'exchange',
    'передать': 'send', 'отправить': 'send', 'send': 'send',
    'форбс': 'forbes', 'forbes': 'forbes', 'богачи': 'forbes',
    'операции': 'ops', 'ops': 'ops', 'транзакции': 'ops',
    'работы': 'jobs', 'вакансии': 'jobs', 'jobs': 'jobs',
    'устроиться': 'hire', 'hire': 'hire',
    'уволиться': 'quit', 'quit': 'quit',
    'работать': 'work', 'смена': 'work', 'work': 'work',
    'учеба': 'study', 'учёба': 'study', 'образование': 'study', 'study': 'study',
    'учиться': 'learn', 'learn': 'learn',
    'бизнес': 'biz', 'бизнесы': 'biz', 'biz': 'biz', 'business': 'biz',
    'собрать': 'collect', 'collect': 'collect',
    'имущество': 'prop', 'property': 'prop',
    'банк': 'bank', 'bank': 'bank',
    'вклад': 'deposit', 'deposit': 'deposit',
    'кредит': 'loan', 'loan': 'loan',
    'рынок': 'market', 'биржа': 'market', 'market': 'market',
    'акции': 'stocks', 'stocks': 'stocks',
    'крипта': 'crypto', 'крипто': 'crypto', 'crypto': 'crypto', 'криптовалюта': 'crypto',
    'график': 'chart', 'chart': 'chart',
    'купить': 'buy', 'buy': 'buy', 'продать': 'sell', 'sell': 'sell',
    'портфель': 'portfolio', 'portfolio': 'portfolio',
    'новости': 'news', 'news': 'news',
    'семья': 'family', 'family': 'family', 'бюджет': 'budget',
    'казна': 'treasury', 'treasury': 'treasury',
    'казнавыдать': 'treasury_give', 'казна-выдать': 'treasury_give',
    'эковыдать': 'eco_give', 'ecogive': 'eco_give',
    'экозабрать': 'eco_take', 'ecotake': 'eco_take',
    'экосброс': 'eco_reset', 'ecoreset': 'eco_reset',
    'правила': 'rules',
}
LEVELS = {'treasury_give': 80, 'eco_give': 80, 'eco_take': 80, 'eco_reset': 100}


def check_static():
    """Все кнопки в коде ссылаются на существующие команды; нет «чужих» ключей."""
    import app.modules  # noqa: F401
    bad, total = [], 0
    for path in SRC.rglob('*.py'):
        tree = ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'btn' and len(node.args) >= 2:
                cmd = node.args[1]
                if isinstance(cmd, ast.Constant) and isinstance(cmd.value, str):
                    total += 1
                    if cmd.value not in registry.commands:
                        bad.append((path.name, node.lineno, cmd.value))
    assert not bad, bad
    return total


async def main():
    # ===== список команд из задания =====
    import app.modules  # noqa: F401
    for name, key in REQUIRED.items():
        cmd = registry.find(name)
        assert cmd is not None and cmd.key == key, (name, cmd and cmd.key)
    for key, level in LEVELS.items():
        assert registry.commands[key].level == level, key
    for key in ('rules',):
        assert registry.commands[key].where == 'chat'
    print(f'OK  все {len(REQUIRED)} имён команд из вашего списка работают; роли казны/эко - 80 и 100')

    # ===== кнопки =====
    n = check_static()
    print(f'OK  {n} кнопок в коде ведут на существующие команды')

    s = await Sim.create()

    # ===== /help =====
    await s.say(1, '/start')
    m = await s.last(1, '/help')
    assert 'Команды пользователя' in m.text and '/кошелёк' in m.text and '/промо' in m.text and '/игры' in m.text
    assert '/промосоздать' not in m.text and '/рассылка' not in m.text, 'служебных команд обычный пользователь не видит'
    assert [b['action']['label'] for b in m.buttons()] == ['• Пользователь']
    assert 'Ваша должность: 👤 Пользователь' in m.text and len(m.text) < 4000
    print('OK  /help пользователя: только его команды и единственная кнопка «Пользователь»')

    # должности -> кнопки; нажатие показывает команды этой должности
    for role, n_buttons in ((1, 2), (3, 4), (6, 8)):
        await s.set_role(1, role)
        m = await s.last(1, '/help')
        labels = [b['action']['label'] for b in m.buttons()]
        assert len(labels) == n_buttons, (role, labels)
        assert labels[0] == '• Пользователь' and any(STAFF[1].split()[0] in l for l in labels[1:3])
    await s.set_role(1, 3)
    m = await s.last(1, '/help')
    m = await s.press(1, 'Агент поддержки')
    assert 'Должность: Агент поддержки' in m.text and '/тикеты' in m.text and '/ответ' in m.text and '/закрыть' in m.text
    assert m.find('• Агент поддержки') and m.find('Пользователь') and not m.find('Тех. администратор')
    m = await s.press(1, 'Администратор')
    assert '/гбан' in m.text and '/гразбан' in m.text and '/промолист' in m.text and '/обнулить' not in m.text
    m = await s.press(1, 'Пользователь'); assert 'Команды пользователя' in m.text
    print('OK  /help по должностям: набор кнопок растёт с должностью, на кнопке - команды именно этой должности')

    # руководитель в беседе: 10 кнопок и все страницы в пределах лимитов
    await s.make_chat(CHAT, creator=OWNER)
    await s.say(OWNER, '/start')
    m = await s.last(OWNER, '/help', peer=CHAT)
    assert len(m.buttons()) == 10
    for b in list(m.buttons()):
        m = await s.press(OWNER, b['action']['label'].replace('• ', ''), peer=CHAT, msg=m)
        assert len(m.text) < 4000
    m = await s.last(OWNER, '/help', peer=CHAT)
    m = await s.press(OWNER, 'Беседа', peer=CHAT, msg=m)
    assert '/кик' in m.text and '/бан' in m.text and '(60+)' in m.text and '(80+)' in m.text and '/экосброс' in m.text and '(100+)' in m.text
    m = await s.last(OWNER, '/help')                               # руководитель в ЛС: тоже видит блок управления
    assert m.find('Беседа') and len(m.buttons()) == 10
    print('OK  /help руководителя: 10 кнопок, все страницы в лимите, в «Беседе» видны нужные роли (60+/80+/100+)')

    # ===== дымовой тест: каждая команда без ошибок =====
    errors = []

    class Catcher(logging.Handler):
        def emit(self, record):
            if record.levelno >= logging.ERROR:
                errors.append(record.getMessage())
    logging.getLogger().addHandler(Catcher())

    for uid in (2, 3):
        await s.say(uid, '/start')
    await s.make_chat(CHAT + 1, creator=3, members=(2,))
    await s.chat_role(CHAT + 1, 3, 100)
    sample_args = ['', 'abc', '100', '@ivan 100', 'все', 'NFTX 1', '1', 'driver', 'loader', 'взять 1000', 'создать Тест', 'положить 100']
    s.vk.screen['ivan'] = 2
    tested = 0
    for cmd in registry.commands.values():
        names = cmd.names or ()
        for place, uid, peer in (('ЛС', OWNER, OWNER), ('беседа', 3, CHAT + 1), ('беседа-участник', 2, CHAT + 1)):
            for args in sample_args:
                if names:
                    await s.say(uid, f'/{names[0]} {args}'.strip(), peer=peer)
                else:
                    await s.cb(uid, cmd.key, args, peer=peer)
                tested += 1
    assert not errors, errors[:3]
    print(f'OK  дымовой тест: {len(registry.commands)} команд × {len(sample_args)} вариантов аргументов × 3 места ({tested} запусков) - без единой ошибки')

    print('\nВсе тесты coverage пройдены')

asyncio.run(main())
