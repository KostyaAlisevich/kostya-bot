import asyncio
import random
from sim import Sim, OWNER, CHAT_BASE
from app.data.jobs import JOBS, JOBS_BY_KEY
from app.data.education import EDUCATIONS
from app.modules import work

CHAT = CHAT_BASE + 9


async def main():
    s = await Sim.create()
    await s.say(1, '/start')

    # ===== вакансии =====
    m = await s.last(1, '/работы')
    assert 'Вакансии | стр. 1/6' in m.text and 'не работаете' in m.text
    labels = m.labels()
    assert len(m.buttons()) <= 10
    m = await s.press(1, 'Грузчик')                         # карточка
    assert 'Грузчик' in m.text and m.find('Устроиться')
    m = await s.press(1, 'Устроиться')
    assert 'Вы устроились' in m.text
    assert (await s.wallet(1))['job'] == 'loader'
    print('OK  вакансии со страницами, карточка, устроиться без образования')

    # для курьера нужны права
    m = await s.last(1, '/устроиться курьер')
    assert 'нужен диплом' in m.text and 'Водительские права' in m.text
    assert (await s.wallet(1))['job'] == 'loader'
    assert 'Такой вакансии нет' in (await s.last(1, '/устроиться космический пират')).text
    assert 'уже работаете' in (await s.last(1, '/устроиться грузчик')).text
    print('OK  без диплома на работу не берут, неизвестная вакансия, повторное устройство')

    # ===== смена =====
    random.seed(1)
    m = await s.last(1, '/работать')
    assert 'смена завершена' in m.text and 'Заработано' in m.text
    pay = (await s.wallet(1))['rub'] - 5000
    assert 45 <= pay <= 120, pay
    m = await s.last(1, '/смена')
    assert 'отдыхаете' in m.text, 'перерыв 40 секунд между сменами'
    assert (await s.wallet(1))['rub'] - 5000 == pay
    await s.db.execute('UPDATE wallets SET work_next=0 WHERE scope=0 AND user_id=1')
    assert 'смена завершена' in (await s.last(1, '/work')).text
    assert (await s.wallet(1))['shifts'] == 2
    print('OK  смена: оплата в диапазоне, перерыв, повторная смена после перерыва')

    # без работы
    await s.say(2, '/start')
    m = await s.last(2, '/работать')
    assert 'нигде не работаете' in m.text and m.find('Вакансии')
    m = await s.last(2, '/уволиться')
    assert 'нигде не работаете' in m.text
    m = await s.last(1, '/уволиться')
    assert 'вы уволились' in m.text.lower() and (await s.wallet(1))['job'] == ''
    print('OK  работать без работы, увольнение')

    # ===== учёба =====
    m = await s.last(1, '/учеба')
    assert 'Образование | стр. 1/3' in m.text and 'Дипломов: 0 из 12' in m.text
    m = await s.press(1, 'Водительские права')
    assert 'Открывает работы' in m.text and 'Курьер' in m.text and m.find('Записаться за 3 000 ₽')
    m = await s.press(1, 'Записаться')
    assert 'Вы записались' in m.text and (await s.wallet(1))['rub'] < 5000 + 200
    rub_after = (await s.wallet(1))['rub']
    m = await s.press(1, 'Пройти занятие')
    assert 'Занятие пройдено: 1/3' in m.text
    m = await s.last(1, '/учиться водительские')
    assert 'Следующее занятие' in m.text and 'через' in m.text, 'перерыв между занятиями'
    for i in (2, 3):
        await s.db.execute("UPDATE edu_progress SET next_at=0 WHERE scope=0 AND user_id=1")
        m = await s.last(1, '/учиться driver')
    assert 'получили диплом' in m.text and 'Курьер' in m.text and 'Таксист' in m.text
    assert (await s.wallet(1))['rub'] == rub_after, 'занятия бесплатные, платится только запись'
    assert 'уже есть' in (await s.last(1, '/учиться driver')).text
    print('OK  курс: запись (оплата), занятия с перерывом, диплом, список открытых работ')

    # диплом открыл работу
    m = await s.last(1, '/устроиться курьер')
    assert 'Вы устроились' in m.text
    print('OK  после диплома можно устроиться на курьера')

    # ===== ограничения курсов =====
    m = await s.last(1, '/учиться экономический')
    assert 'Сначала получите' in m.text and 'Бакалавриат' in m.text
    await s.db.execute('UPDATE wallets SET rub=100 WHERE scope=0 AND user_id=1')
    m = await s.last(1, '/учиться кулинарное')
    assert 'Не хватает денег' in m.text
    assert not await s.db.fetchrow("SELECT 1 FROM edu_progress WHERE user_id=1 AND edu_key='cook'"), 'без денег запись не создаётся'
    await s.db.execute('UPDATE wallets SET rub=100000 WHERE scope=0 AND user_id=1')
    await s.say(1, '/учиться кулинарное')
    m = await s.last(1, '/учиться фотографии')
    assert 'закончите текущий курс' in m.text, 'одновременно можно учиться только на одном курсе'
    m = await s.last(1, '/учиться')                     # без аргументов - занятие по текущему курсу
    assert 'Занятие пройдено: 1/4' in m.text
    print('OK  зависимости курсов, нехватка денег, один курс одновременно, /учиться без аргумента')

    # ===== налог казны в беседе =====
    await s.make_chat(CHAT, creator=10, members=(1,))
    await s.say(1, '/устроиться уборщик', peer=CHAT)
    await s.db.execute('UPDATE chats SET tax=10 WHERE peer_id=$1', CHAT)
    random.seed(5)
    m = await s.last(1, '/работать', peer=CHAT)
    assert 'Налог в казну' in m.text, m.text
    chat = await s.db.fetchrow('SELECT treasury FROM chats WHERE peer_id=$1', CHAT)
    assert chat['treasury'] > 0
    w = await s.wallet(1, CHAT)
    assert w['rub'] - 5000 + chat['treasury'] >= 30 and (await s.wallet(1))['job'] != 'cleaner'
    print('OK  в беседе налог идёт в казну; работа в беседе не связана с личной')

    # ===== розыгрыш смены =====
    rng = random.Random(3)
    for job in JOBS:
        outcomes = [work.roll_shift(job, 0, rng) for _ in range(3000)]
        for kind, amount, text in outcomes:
            if kind == 'fail':
                assert -job.fine[1] <= amount <= 0
            elif kind == 'success':
                assert job.min_pay <= amount <= job.max_pay
        fails = sum(k == 'fail' for k, _, _ in outcomes) / len(outcomes)
        assert abs(fails - job.fail_chance) < 0.03, (job.key, fails)
    checked = 0
    for seed in range(50):
        a = work.roll_shift(JOBS_BY_KEY['loader'], 0, random.Random(seed))
        b = work.roll_shift(JOBS_BY_KEY['loader'], 100, random.Random(seed))
        if a[0] == b[0] == 'success':
            assert b[1] == a[1] * 110 // 100, (a, b)       # 100 смен = +10%
            checked += 1
    assert checked > 30
    c = work.roll_shift(JOBS_BY_KEY['loader'], 10_000, random.Random(1))
    d = work.roll_shift(JOBS_BY_KEY['loader'], 0, random.Random(1))
    assert c[0] == d[0] and (c[1] * 100 // 150 <= d[1] + 1), 'бонус за стаж ограничен +50%'
    print('OK  розыгрыш смены: диапазоны, шансы провала, штрафы, бонус за стаж')

    # штраф не уводит в минус
    await s.say(1, '/устроиться трейдер', peer=CHAT)   # нужен диплом - не выйдет, проверим вручную через БД
    await s.db.execute("UPDATE wallets SET job='trader', work_next=0, rub=50 WHERE scope=$1 AND user_id=1", CHAT)
    real_roll = work.roll_shift
    work.roll_shift = lambda job, shifts=0, rng=None: ('fail', -700, 'Рынок обвалился.')
    try:
        m = await s.last(1, '/работать', peer=CHAT)
    finally:
        work.roll_shift = real_roll
    assert (await s.wallet(1, CHAT))['rub'] == 0 and 'Потеряно: 50 ₽' in m.text
    print('OK  штраф списывается не больше, чем есть на счёте')

    print('\nВсе тесты career пройдены')

asyncio.run(main())
