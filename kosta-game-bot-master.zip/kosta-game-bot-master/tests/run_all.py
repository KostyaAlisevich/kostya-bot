"""Запуск всех проверок: python tests/run_all.py"""
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
tests = sorted(ROOT.glob('test_*.py')) + [ROOT / 'lint310.py']
failed = []
started = time.time()
for path in tests:
    t = time.time()
    res = subprocess.run([sys.executable, str(path)], capture_output=True, text=True, cwd=ROOT)
    ok = res.returncode == 0
    last = (res.stdout.strip().splitlines() or [''])[-1]
    print(f'{"OK  " if ok else "FAIL"} {path.name:<28} {time.time() - t:5.1f}s  {last[:60]}')
    if not ok:
        failed.append(path.name)
        print((res.stdout + res.stderr)[-1500:])
print(f'\n{len(tests) - len(failed)}/{len(tests)} проверок пройдено за {time.time() - started:.0f} c')
sys.exit(1 if failed else 0)
