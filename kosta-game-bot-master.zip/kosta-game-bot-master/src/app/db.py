"""Работа с PostgreSQL через asyncpg.

Весь SQL проекта написан в общем подмножестве PostgreSQL/SQLite (параметры $1, $2...,
время - целые секунды Unix, флаги - SMALLINT 0/1), поэтому логику можно проверять и на SQLite.
"""
import asyncio
import logging
from contextlib import asynccontextmanager
from urllib.parse import urlsplit

from .schema import SCHEMA

log = logging.getLogger('bot.db')

CONNECT_ATTEMPTS = 6        # сколько раз пробуем подключиться (база на хостинге может стартовать дольше бота)
CONNECT_DELAY = 5.0         # пауза между попытками, секунд


def check_dsn(dsn: str) -> str | None:
    """Возвращает понятное описание проблемы, если строка подключения явно неверная, иначе None."""
    dsn = (dsn or '').strip()
    if not dsn:
        return 'переменная DATABASE_URL пуста'
    if '${{' in dsn or '}}' in dsn:
        return ('в DATABASE_URL остались нераскрытые ссылки вида ${{...}}. Эту переменную нужно задать в сервисе БОТА '
                'значением-ссылкой на Postgres: ${{Postgres.DATABASE_URL}} (где Postgres - точное название сервиса '
                'базы данных в вашем проекте), а не копировать строку из переменных самого Postgres')
    if not dsn.startswith(('postgres://', 'postgresql://')):
        return 'строка должна начинаться с postgresql://'
    parts = urlsplit(dsn)
    if not parts.hostname:
        return 'в строке не указан адрес сервера базы данных'
    return None


def safe_dsn(dsn: str) -> str:
    """Строка подключения без пароля - для логов."""
    try:
        parts = urlsplit(dsn)
        return f'{parts.scheme}://{parts.username or "?"}:***@{parts.hostname}:{parts.port or 5432}{parts.path}'
    except ValueError:
        return '(не удалось разобрать строку подключения)'


class Database:
    def __init__(self, dsn: str):
        self.dsn = dsn
        self.pool = None

    async def connect(self) -> None:
        import asyncpg  # импортируем здесь, чтобы тесты работали без asyncpg
        problem = check_dsn(self.dsn)
        if problem:
            raise RuntimeError(f'Неверная строка подключения к базе: {problem}')
        dsn = self.dsn.strip()
        if dsn.startswith('postgres://'):  # asyncpg понимает оба варианта, но так надёжнее
            dsn = 'postgresql://' + dsn[len('postgres://'):]
        last_error = None
        for attempt in range(1, CONNECT_ATTEMPTS + 1):
            try:
                self.pool = await asyncpg.create_pool(dsn, min_size=1, max_size=10, command_timeout=30)
                log.info('Подключено к базе данных: %s', safe_dsn(dsn))
                return
            except Exception as e:  # noqa: BLE001
                last_error = e
                log.warning('Не удалось подключиться к базе (%s), попытка %s из %s: %s: %s',
                            safe_dsn(dsn), attempt, CONNECT_ATTEMPTS, type(e).__name__, e)
                if attempt < CONNECT_ATTEMPTS:
                    await asyncio.sleep(CONNECT_DELAY)
        raise RuntimeError(
            f'Не удалось подключиться к базе {safe_dsn(dsn)} за {CONNECT_ATTEMPTS} попыток. '
            f'Последняя ошибка: {type(last_error).__name__}: {last_error}. '
            'Проверьте DATABASE_URL в переменных бота и что сервис Postgres запущен.') from last_error

    async def close(self) -> None:
        if self.pool is not None:
            await self.pool.close()

    async def fetch(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetch(query, *args)

    async def fetchrow(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetchrow(query, *args)

    async def fetchval(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetchval(query, *args)

    async def execute(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.execute(query, *args)

    @asynccontextmanager
    async def transaction(self):
        """Транзакция: все запросы внутри либо применяются вместе, либо откатываются."""
        async with self.pool.acquire() as conn:
            async with conn.transaction():
                yield conn


async def init_schema(db) -> None:
    """Создаёт недостающие таблицы (безопасно запускать при каждом старте)."""
    for statement in SCHEMA:
        await db.execute(statement)
