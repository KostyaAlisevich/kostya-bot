"""Капитал игроков: деньги, вклад, валюта, имущество и ценные бумаги."""
from ..data.assets import ITEMS_BY_KEY
from . import market_engine


async def _scope_data(db, scope: int, user_ids=None):
    if user_ids is None:
        wallets = await db.fetch('SELECT * FROM wallets WHERE scope=$1', scope)
        assets = await db.fetch('SELECT user_id, item_key FROM owned_assets WHERE scope=$1', scope)
        holds = await db.fetch('SELECT user_id, symbol, qty FROM holdings WHERE scope=$1', scope)
    else:
        from .accounts import placeholders
        ph = placeholders(2, len(user_ids))
        wallets = await db.fetch(f'SELECT * FROM wallets WHERE scope=$1 AND user_id IN ({ph})', scope, *user_ids)
        assets = await db.fetch(
            f'SELECT user_id, item_key FROM owned_assets WHERE scope=$1 AND user_id IN ({ph})', scope, *user_ids)
        holds = await db.fetch(
            f'SELECT user_id, symbol, qty FROM holdings WHERE scope=$1 AND user_id IN ({ph})', scope, *user_ids)
    return wallets, assets, holds


async def wealth_map(db, scope: int, user_ids=None) -> dict[int, int]:
    """{user_id: капитал в рублях} для всех игроков scope (или только для user_ids)."""
    if user_ids is not None and not user_ids:
        return {}
    wallets, assets, holds = await _scope_data(db, scope, user_ids)
    rates = await market_engine.fx_rates(db)
    px = await market_engine.prices(db)

    result: dict[int, float] = {}
    for w in wallets:
        result[w['user_id']] = (
            w['rub'] + w['deposit'] - w['loan']
            + w['usd'] / 100 * rates['usd'] + w['eur'] / 100 * rates['eur']
        )
    for a in assets:
        item = ITEMS_BY_KEY.get(a['item_key'])
        if item and a['user_id'] in result:
            result[a['user_id']] += item.price
    for h in holds:
        if h['user_id'] in result:
            result[h['user_id']] += h['qty'] * px.get(h['symbol'], 0)
    return {uid: int(v) for uid, v in result.items()}


async def net_worth(db, scope: int, uid: int) -> int:
    return (await wealth_map(db, scope, [uid])).get(uid, 0)


async def top_wealth(db, scope: int, limit: int = 10) -> list[tuple[int, int]]:
    wm = await wealth_map(db, scope)
    return sorted(wm.items(), key=lambda kv: kv[1], reverse=True)[:limit]
