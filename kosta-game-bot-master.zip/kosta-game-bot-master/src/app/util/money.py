"""Разбор сумм и валют, которые вводит пользователь."""
import re

CUR_ALIASES = {
    'rub': 'rub', 'р': 'rub', 'руб': 'rub', 'рубль': 'rub', 'рубли': 'rub', 'рублей': 'rub', '₽': 'rub', 'rur': 'rub',
    'usd': 'usd', '$': 'usd', 'долл': 'usd', 'доллар': 'usd', 'доллары': 'usd', 'долларов': 'usd',
    'бакс': 'usd', 'баксов': 'usd', 'dollar': 'usd',
    'eur': 'eur', '€': 'eur', 'евро': 'eur', 'euro': 'eur',
}
CUR_NAMES = {'rub': 'рубли ₽', 'usd': 'доллары $', 'eur': 'евро €'}
_SUFFIX = re.compile(r'^(.*?)(₽|\$|€|руб\.?|р\.?|rub|usd|eur|долл\.?|евро)$', re.IGNORECASE)
_ALL = ('все', 'всё', 'all', 'max', 'макс')


def parse_currency(token: str | None) -> str | None:
    if token is None:
        return None
    return CUR_ALIASES.get(token.strip().lower().replace('ё', 'е').rstrip('.'))


def _value(text: str, maximum: int | None) -> float | None:
    """Число из строки: '1500', '1 500', '1.5к', '2кк', 'всё' (maximum), '50%' (от maximum)."""
    t = text.strip().lower().replace('_', '').replace(',', '.').replace('ё', 'е')
    if t in _ALL:
        return float(maximum) if maximum else None
    if t.endswith('%'):
        try:
            p = float(t[:-1])
        except ValueError:
            return None
        return maximum * p / 100 if maximum and 0 < p <= 100 else None
    mult = 1
    if t.endswith(('кк', 'kk')):
        mult, t = 1_000_000, t[:-2]
    elif t.endswith(('к', 'k', 'м')):
        mult, t = (1_000_000 if t.endswith('м') else 1_000), t[:-1]
    try:
        return float(t) * mult
    except ValueError:
        return None


def parse_money(tokens: list[str], balances: dict[str, int] | None = None, default: str = 'rub'):
    """Сумма с необязательной валютой из списка слов.

    Примеры: ['500'] -> (500, 'rub'); ['10$'] -> (1000, 'usd'); ['10', 'долларов'] -> (1000, 'usd');
             ['всё', 'usd'] -> весь баланс долларов. Возвращает (минорные_единицы, валюта, остаток_слов)
    или None, если разобрать не удалось. Рубли - целые, доллары и евро - в центах.
    """
    if not tokens:
        return None
    first, rest = tokens[0], tokens[1:]
    cur = None
    m = _SUFFIX.match(first)
    if m and m.group(1) and m.group(1).strip():
        cur, first = parse_currency(m.group(2)), m.group(1)
    elif rest and parse_currency(rest[0]):
        cur, rest = parse_currency(rest[0]), rest[1:]
    cur = cur or default
    maximum = balances.get(cur) if balances else None
    value = _value(first, maximum if cur == 'rub' or maximum is None else maximum / 100)
    if value is None:
        return None
    minor = int(round(value * (1 if cur == 'rub' else 100)))
    return (minor, cur, rest) if minor > 0 else None
