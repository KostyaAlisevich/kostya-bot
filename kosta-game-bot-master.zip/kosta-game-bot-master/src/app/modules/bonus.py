"""Ежедневный бонус: чем дольше серия дней подряд, тем он больше."""
from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, bar, dur, rub

COOLDOWN = 20 * 3600          # бонус можно забирать раз в 20 часов
STREAK_WINDOW = 48 * 3600     # серия не прерывается, если зайти в течение 48 часов
BASE = 500                    # бонус за первый день серии
STEP = 150                    # прибавка за каждый следующий день серии
MAX_STEPS = 6                 # ... но не больше шести прибавок (7-й день и далее)
WEEK_BONUS = 3000             # дополнительно за каждые 7 дней подряд


def bonus_amount(streak: int) -> int:
    amount = BASE + STEP * min(max(streak, 1) - 1, MAX_STEPS)
    if streak > 0 and streak % 7 == 0:
        amount += WEEK_BONUS
    return amount


def _kb(ctx):
    return ctx.kb().btn('💰 Кошелёк', 'wallet').btn('🏠 Меню', 'menu')


@registry.command('bonus', names=['бонус', 'bonus', 'ежедневный', 'daily'], desc='ежедневный бонус', section='economy')
async def cmd_bonus(ctx):
    await ctx.wallet()
    now = accounts.now()
    await ctx.db.execute(
        'INSERT INTO daily_bonus (scope, user_id) VALUES ($1, $2) ON CONFLICT (scope, user_id) DO NOTHING',
        ctx.scope, ctx.user_id)
    row = await ctx.db.fetchrow('SELECT * FROM daily_bonus WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)

    left = row['last_ts'] + COOLDOWN - now
    if row['last_ts'] and left > 0:
        nxt = row['streak'] + 1 if now - row['last_ts'] <= STREAK_WINDOW else 1
        return await ctx.respond(
            f'🎁 Ежедневный бонус\n{SEP}\n'
            f'⏳ Вы уже забрали его сегодня. Следующий через {dur(left)}.\n'
            f'🔥 Серия: {row["streak"]} дн. подряд\n'
            f'Завтра вас ждёт {rub(bonus_amount(nxt))}', _kb(ctx))

    streak = row['streak'] + 1 if (row['last_ts'] and now - row['last_ts'] <= STREAK_WINDOW) else 1
    # условие last_ts = прочитанное значение защищает от двойного получения при быстрых повторных нажатиях
    claimed = await ctx.db.fetchrow(
        'UPDATE daily_bonus SET last_ts=$3, streak=$4 WHERE scope=$1 AND user_id=$2 AND last_ts=$5 RETURNING streak',
        ctx.scope, ctx.user_id, now, streak, row['last_ts'])
    if claimed is None:
        return await ctx.respond('⏳ Бонус уже получен', _kb(ctx))

    amount = bonus_amount(streak)
    await accounts.change(ctx.db, ctx.scope, ctx.user_id, amount, 'rub', 'bonus', f'серия {streak}')
    day_in_week = streak % 7 or 7
    lines = [
        f'🎁 Ежедневный бонус\n{SEP}',
        f'✅ Получено: +{rub(amount)}',
        f'🔥 Серия: {streak} дн. подряд',
        f'{bar(day_in_week, 7, 7)} {day_in_week}/7',
    ]
    if streak % 7 == 0:
        lines.append(f'🎉 Недельная награда: +{rub(WEEK_BONUS)} уже включена!')
    else:
        lines.append(f'За 7 дней подряд - дополнительно +{rub(WEEK_BONUS)}')
    lines.append(f'💳 Баланс: {rub((await ctx.wallet())["rub"])}')
    lines.append(f'Следующий бонус через {dur(COOLDOWN)}: {rub(bonus_amount(streak + 1))}')
    await ctx.respond('\n'.join(lines), _kb(ctx))
