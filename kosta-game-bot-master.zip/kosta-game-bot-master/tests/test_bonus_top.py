import asyncio
from sim import Sim, OWNER, CHAT_BASE
from app.modules import bonus
from app.services import accounts

CHAT = CHAT_BASE + 81
H = 3600


async def main():
    # ===== формула бонуса =====
    assert [bonus.bonus_amount(d) for d in range(1, 9)] == [500, 650, 800, 950, 1100, 1250, 1400 + 3000, 1400]
    assert bonus.bonus_amount(14) == 1400 + 3000 and bonus.bonus_amount(0) == 500
    print('OK  формула: 500 → 1400 за 7 дней, +3000 за каждую неделю подряд')

    s = await Sim.create()
    await s.say(1, '/start')
    bal = lambda uid=1, scope=0: s.wallet(uid, scope)

    # ===== первый бонус =====
    m = await s.last(1, '/bonus')
    assert '+500 ₽' in m.text and 'Серия: 1 дн.' in m.text and '1/7' in m.text and 'За 7 дней подряд' in m.text
    assert (await bal())['rub'] == 5500
    m = await s.last(1, '/бонус')
    assert 'уже забрали' in m.text and 'Следующий через 19 ч 59 мин' in m.text or 'через 20 ч' in m.text
    assert (await bal())['rub'] == 5500, 'повторно бонус не выдаётся'
    for alias in ('/ежедневный', '/daily'):
        assert 'забрали' in (await s.last(1, alias)).text
    print('OK  первый бонус +500 ₽, повторно - ожидание, псевдонимы')

    # ===== серия =====
    await s.db.execute('UPDATE daily_bonus SET last_ts=$1 WHERE user_id=1', accounts.now() - 21 * H)
    m = await s.last(1, '/bonus'); assert '+650 ₽' in m.text and 'Серия: 2 дн.' in m.text
    await s.db.execute('UPDATE daily_bonus SET last_ts=$1 WHERE user_id=1', accounts.now() - 49 * H)       # пропустили день
    m = await s.last(1, '/bonus'); assert '+500 ₽' in m.text and 'Серия: 1 дн.' in m.text, 'серия обнуляется после 48 часов'
    # 7-й день подряд - недельная награда
    await s.db.execute('UPDATE daily_bonus SET last_ts=$1, streak=6 WHERE user_id=1', accounts.now() - 21 * H)
    b0 = (await bal())['rub']
    m = await s.last(1, '/bonus')
    assert '+4 400 ₽' in m.text and 'Недельная награда' in m.text and '7/7' in m.text and (await bal())['rub'] == b0 + 4400
    await s.db.execute('UPDATE daily_bonus SET last_ts=$1 WHERE user_id=1', accounts.now() - 21 * H)
    m = await s.last(1, '/bonus'); assert '+1 400 ₽' in m.text and 'Серия: 8 дн.' in m.text
    print('OK  серия дней: рост, сброс после пропуска, недельная награда на 7-й день')

    # ===== в беседе - отдельный бонус; кнопка меню; гонка =====
    await s.make_chat(CHAT, creator=10, members=(1,))
    m = await s.last(1, '/бонус', peer=CHAT); assert '+500 ₽' in m.text and 'Серия: 1 дн.' in m.text
    assert (await s.wallet(1, CHAT))['rub'] == 5500
    await s.say(2, '/start')
    m = await s.last(2, '/menu'); m = await s.press(2, 'Бонус', msg=m)
    assert '+500 ₽' in m.text and m.find('Кошелёк') and m.find('Меню'), 'кнопка «Бонус» в главном меню'
    await s.say(3, '/start')
    await asyncio.gather(*[s.say(3, '/бонус') for _ in range(5)])
    assert (await s.wallet(3))['rub'] == 5500 and await s.db.fetchval('SELECT streak FROM daily_bonus WHERE user_id=3') == 1
    print('OK  в беседе отдельный бонус, кнопка в меню, быстрые повторы не дают двойной выплаты')

    # ===== топ игроков по балансу =====
    for u in (4, 5, 6):
        await s.say(u, '/start')
    await s.db.execute('UPDATE wallets SET rub=900000 WHERE scope=0 AND user_id=4')
    await s.db.execute('UPDATE wallets SET rub=700000 WHERE scope=0 AND user_id=5')
    await s.db.execute('UPDATE wallets SET rub=800000 WHERE scope=0 AND user_id=6')
    m = await s.last(1, '/top')
    assert 'Топ игроков по балансу (личных сообщений)' in m.text
    lines = m.text.split('\n')
    assert lines[2].startswith('🥇 [id4|Юзер4] - 900 000 ₽') and lines[3].startswith('🥈 [id6|') and lines[4].startswith('🥉 [id5|'), lines[:6]
    assert m.find('Игроки') and m.find('Кланы') and m.find('Форбс')
    for alias in ('/топ', '/рейтинг', '/leaders'):
        assert 'Топ игроков' in (await s.last(1, alias)).text
    # забаненные в топе не показываются
    await s.db.execute('UPDATE users SET banned=1 WHERE id=4')
    assert '[id4|' not in (await s.last(1, '/top')).text
    # сам игрок вне десятки видит своё место
    for u in range(100, 112):
        await s.say(u, '/start'); await s.db.execute('UPDATE wallets SET rub=$1 WHERE scope=0 AND user_id=$2', 2_000_000 + u, u)
    m = await s.last(3, '/top')
    assert 'Вы - 5 500 ₽' in m.text and '…' in m.text
    print('OK  /top: порядок по балансу, медали, алиасы, баны скрыты, своё место вне десятки')

    # беседа: свой рейтинг
    await s.give(1, rub=123456, scope=CHAT)
    m = await s.last(1, '/top', peer=CHAT)
    assert 'этой беседы' in m.text and '123 456 ₽' in m.text and '[id4|' not in m.text
    print('OK  в беседе свой рейтинг')

    # ===== вкладка кланов =====
    m = await s.last(1, '/top клан')
    assert 'Топ кланов' in m.text and 'Кланов пока нет' in m.text
    m = await s.press(1, 'Игроки'); assert 'Топ игроков' in m.text
    m = await s.press(1, 'Кланы'); assert 'Топ кланов' in m.text
    assert 'Топ кланов' in (await s.last(1, '/клантоп')).text
    print('OK  /top клан, вкладки «Игроки» и «Кланы» переключаются на месте')

    print('\nВсе тесты bonus/top пройдены')

asyncio.run(main())
