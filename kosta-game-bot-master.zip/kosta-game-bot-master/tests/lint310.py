"""Проверка, что исходники совместимы с Python 3.10 (в Docker-образе python:3.10)."""
import ast
import io
import pathlib
import re
import sys
import tokenize

SRC = pathlib.Path(__file__).resolve().parents[1] / 'src'
BLACKLIST = [r'\bExceptionGroup\b', r'\basyncio\.TaskGroup\b', r'\btomllib\b', r'\bitertools\.batched\b',
             r'from typing import[^\n]*\b(Self|override|LiteralString|Never|assert_never)\b', r'\bdatetime\.UTC\b',
             r'\bexcept\*', r'\btype \w+ = ']
problems = []
files = sorted(SRC.rglob('*.py'))
for path in files:
    text = path.read_text(encoding='utf-8')
    try:
        ast.parse(text, feature_version=(3, 10))
    except SyntaxError as e:
        problems.append(f'{path.name}:{e.lineno}: синтаксис не для 3.10: {e.msg}')
    for pattern in BLACKLIST:
        for m in re.finditer(pattern, text):
            problems.append(f'{path.name}: {m.group(0)!r} недоступно в 3.10')

    # f-строки: вложенные кавычки того же вида допустимы только с Python 3.12
    stack = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(text).readline):
            name = tokenize.tok_name[tok.type]
            if name == 'FSTRING_START':
                delim = tok.string.lstrip('fFrRbBuU')
                stack.append(delim)
            elif name == 'FSTRING_END':
                stack.pop()
            elif name == 'STRING' and stack:
                inner = tok.string.lstrip('fFrRbBuU')
                outer = stack[-1]
                if inner[:len(outer)] == outer and len(outer) == 1:
                    problems.append(f'{path.name}:{tok.start[0]}: f-строка с теми же кавычками внутри выражения ({tok.string}) - ошибка в Python 3.10')
            elif name == 'FSTRING_MIDDLE' and False:
                pass
    except tokenize.TokenError as e:
        problems.append(f'{path.name}: ошибка токенизации {e}')

print(f'Проверено файлов: {len(files)}')
if problems:
    print('\n'.join(problems))
    sys.exit(1)
print('Совместимость с Python 3.10: OK')
