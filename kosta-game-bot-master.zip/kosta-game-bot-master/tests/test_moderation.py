import asyncio
from sim import Sim, OWNER, CHAT_BASE
from app.modules.moderation import parse_duration
from app.services import accounts

CHAT = CHAT_BASE + 41


async def main():
    # ===== длительности =====
    assert parse_duration('30') == 1800 and parse_duration('30м') == 1800 and parse_duration('2ч') == 7200
    assert parse_duration('1д') == 86400 and parse_duration('45с') == 45 and parse_duration('10мин') == 600
    assert parse_duration('abc') is None and parse_duration('') is None and parse_duration('-5') is None
    print('OK  разбор длительности мута (30, 2ч, 1д, 45с)')

    s = await Sim.create()
    await s.make_chat(CHAT, creator=10, admins=(11,), members=(12, 13, 14, 15, 16))
    await s.chat_role(CHAT, 12, 60)      # модератор
    await s.chat_role(CHAT, 13, 20)      # помощник
    # все пользователи регистрируются при первом сообщении
    for u in (11, 12, 13, 14, 15, 16):
        await s.say(u, 'привет', peer=CHAT)
    lvl = lambda uid: s.db.fetchval('SELECT role FROM chat_members WHERE peer_id=$1 AND user_id=$2', CHAT, uid)
    say = lambda uid, text, **kw: s.last(uid, text, peer=CHAT, **kw)

    # ===== кик и права =====
    assert 'Нужна роль 60+' in (await say(14, '/кик @15')).text
    assert 'Нужна роль 60+' in (await say(13, '/кик @15')).text, 'помощник (20) тоже не может'
    s.vk.screen['petya'] = 15
    m = await say(12, '/кик @petya спам')
    assert 'исключён(а)' in m.text and 'Причина: спам' in m.text and (CHAT, 15) in s.vk.kicked
    assert 'роль не ниже' in (await say(12, '/кик @11')).text, 'модератор не может кикнуть админа'
    assert 'к себе' in (await say(12, '/кик @12')).text
    assert 'к себе' in (await say(12, '/кик', reply_from=12)).text
    s.vk.kick_fail.add(16)
    assert 'Не удалось исключить' in (await say(12, '/кик 16')).text
    assert 'Укажите пользователя' in (await say(12, '/кик')).text
    m = await say(12, '/кик', reply_from=14)                 # ответом на сообщение
    assert 'исключён(а)' in m.text and (CHAT, 14) in s.vk.kicked
    print('OK  /кик: права по роли, иерархия, ответом на сообщение, ошибки')

    # ===== бан =====
    assert 'Нужна роль 80+' in (await say(12, '/бан @14')).text, 'модератор банить не может'
    m = await say(11, '/бан @14 флуд')
    assert 'забанен(а)' in m.text and 'Причина: флуд' in m.text and m.find('Разбанить')
    s.vk.kicked.clear(); s.vk.deleted.clear()
    ev = await s.say(14, 'я вернулся', peer=CHAT)                 # забаненный пишет - сообщение удаляется, снова кик
    assert ev == [] and s.vk.deleted and s.vk.kicked == [(CHAT, 14)]
    m = await say(12, '/банлист'); assert '[id14|Юзер14]' in m.text
    # приглашение забаненного
    s.vk.kicked.clear()
    ev = await s.say(10, '', peer=CHAT, action={'type': 'chat_invite_user', 'member_id': 14})
    assert 'находится в бане' in ev[-1].text and s.vk.kicked == [(CHAT, 14)]
    m = await s.press(11, 'Разбанить', peer=CHAT, msg=s.latest_msg_with(CHAT, 'Разбанить'))
    assert 'разбанен(а)' in m.text
    assert 'не в бане' in (await say(11, '/разбан @14')).text
    n_del = len(s.vk.deleted)
    await s.say(14, 'снова тут', peer=CHAT)
    assert len(s.vk.deleted) == n_del, 'после разбана сообщения не удаляются'
    print('OK  /бан: кик + удаление сообщений, повторный вход, /банлист, разбан кнопкой')

    # ===== мут =====
    s.vk.deleted.clear()
    m = await say(12, '/мут @13 2ч флуд')
    assert 'заглушен(а) на 2 ч' in m.text and 'Причина: флуд' in m.text
    n = len(s.vk.deleted)
    assert await s.say(13, 'я не могу писать?', peer=CHAT) == []
    assert len(s.vk.deleted) == n + 1, 'сообщение замученного удалено'
    assert await s.say(13, '/кошелёк', peer=CHAT) == [], 'команды замученного тоже не работают'
    m = await say(12, '/мутлист'); assert '[id13|Юзер13]' in m.text and ('1 ч 59 мин' in m.text or '2 ч' in m.text)
    m = await s.press(12, 'Снять мут', peer=CHAT, msg=s.latest_msg_with(CHAT, 'Снять мут'))
    assert 'снова может писать' in m.text
    assert 'Кошелёк' in (await say(13, '/кошелёк')).text
    m = await say(12, '/мут @13')                                         # по умолчанию 30 минут
    assert 'на 30 мин' in m.text
    m = await say(12, '/мут @13 флуд и спам')                              # причина вместо времени -> 30 минут
    assert 'на 30 мин' in m.text and 'Причина: флуд и спам' in m.text
    assert 'от 1 секунды до 7 суток' in (await say(12, '/мут @13 30д')).text
    assert 'не заглушен' in (await say(12, '/размут @15')).text
    await say(12, '/размут @13')
    assert 'Список пуст' in (await say(12, '/мутлист')).text
    print('OK  /мут: сообщения и команды удаляются, снятие кнопкой, 30 минут по умолчанию, лимит 7 суток')

    # истёкший мут не мешает
    await say(12, '/мут @13 1')
    await s.db.execute('UPDATE chat_members SET muted_until=$1 WHERE peer_id=$2 AND user_id=13', accounts.now() - 1, CHAT)
    assert 'Кошелёк' in (await say(13, '/кошелёк')).text
    print('OK  истёкший мут больше не действует')

    # ===== варны =====
    s.vk.kicked.clear()
    m = await say(12, '/варн @13 грубость')
    assert 'предупреждение 1/3' in m.text and m.find('Снять варн')
    m = await s.press(12, 'Снять варн', peer=CHAT, msg=m)
    assert 'Предупреждение снято' in m.text and '0/3' in m.text
    assert 'нет предупреждений' in (await say(12, '/снятьварн @13')).text
    await say(12, '/варн @13'); await say(12, '/warn @13')
    m = await say(12, '/варн @13')
    assert '3/3' in m.text and 'исключён(а) из беседы' in m.text and (CHAT, 13) in s.vk.kicked
    assert (await s.db.fetchval('SELECT warns FROM chat_members WHERE peer_id=$1 AND user_id=13', CHAT)) == 0
    assert '0/3' in (await say(13, '/варны')).text
    await say(12, '/варн @13')
    assert '1/3' in (await say(14, '/варны @13')).text, 'смотреть чужие варны может любой'
    assert 'Нужна роль 90+' in (await say(12, '/варнлимит 5')).text
    assert 'Лимит предупреждений: 5' in (await say(11, '/варнлимит 5')).text
    assert 'от 2 до 10' in (await say(11, '/варнлимит 1')).text
    print('OK  /варн: счётчик, снятие, автоисключение по лимиту, /варны, /варнлимит')

    # ===== роли =====
    assert 'Нужна роль 90+' in (await say(12, '/роль @14 20')).text
    m = await say(11, '/роль @14 60')
    assert 'теперь «Модератор» (уровень 60)' in m.text and await lvl(14) == 60
    assert 'Выдать можно роль только ниже вашей' in (await say(11, '/роль @15 90')).text
    assert 'Выдать можно роль только ниже вашей' in (await say(11, '/роль @15 100')).text
    assert 'роль не ниже' in (await say(11, '/роль @10 10')).text, 'роль создателя менять нельзя'
    assert 'к себе' in (await say(11, '/роль @11 10')).text
    m = await say(10, '/роль @15 95')
    assert await lvl(15) == 95, m.text
    assert 'роль не ниже' in (await say(11, '/роль @15 0')).text, 'админ (90) не может менять роль 95'
    assert 'роль снята' in (await say(11, '/роль @14 0')).text and await lvl(14) == 0
    assert 'Укажите уровень' in (await say(11, '/роль @14')).text
    # названия ролей
    m = await say(11, '/создатьроль 70 Помощник админа')
    assert 'теперь называется «Помощник админа»' in m.text
    assert 'от 1 до 89' in (await say(11, '/создатьроль 90 Хитрец')).text
    assert 'Формат' in (await say(11, '/создатьроль')).text
    await say(11, '/роль @14 70')
    m = await say(14, '/роли')
    assert '70 - Помощник админа ✏ (1 чел.)' in m.text and '100 - Создатель (1 чел.)' in m.text and '60 - Модератор (1 чел.)' in m.text
    m = await say(14, '/админы')
    assert '70 · Помощник админа: [id14|Юзер14]' in m.text and '100 · Создатель' in m.text
    assert 'удалено' in (await say(11, '/удалитьроль 70')).text and 'нет вашего названия' in (await say(11, '/удалитьроль 70')).text
    assert '70 · Модератор+' in (await say(14, '/админы')).text, 'без своего названия роль 70 показывается как ближайшая нижняя'
    print('OK  роли: выдача (только ниже своей), создатель 95, названия ролей, /роли, /админы')

    # модератор с выданной ролью получает права
    s.vk.kick_fail.clear()
    assert 'исключён(а)' in (await say(14, '/кик @16')).text, 'выданная роль 70 даёт права модератора'

    # ===== правила =====
    assert 'пока не заданы' in (await say(14, '/правила')).text
    assert 'ролью 90' in (await say(14, '/правила 1. Уважайте друг друга')).text
    rules = '1. Не спамить\n2. Уважать других\n3. Без рекламы'
    m = await say(11, '/правила ' + rules)
    assert 'сохранены' in m.text
    m = await say(16, '/правила')
    assert '📜 Правила беседы' in m.text and rules in m.text, 'переносы строк сохраняются'
    assert 'слишком длинный' in (await say(11, '/правила ' + 'x' * 3100)).text.lower()
    assert 'сохранены' in (await say(10, '/rules Новые правила')).text and 'Новые правила' in (await say(15, '/правила')).text
    assert 'удалены' in (await say(11, '/правила очистить')).text and 'не заданы' in (await say(15, '/правила')).text
    await say(11, '/правила ' + rules)
    print('OK  /правила: задать (90+), прочитать любому, переносы строк, очистить')

    # ===== приветствие =====
    assert 'не задано' in (await say(15, '/приветствие')).text
    assert 'ролью 90' in (await say(16, '/приветствие Привет!')).text
    await say(11, '/приветствие Добро пожаловать, {имя}! Загляни в /правила')
    ev = await s.say(10, '', peer=CHAT, action={'type': 'chat_invite_user_by_link', 'member_id': 77})
    assert ev and 'Добро пожаловать, [id77|Юзер77]!' in ev[-1].text
    assert 'отключено' in (await say(11, '/приветствие выкл')).text
    assert await s.say(10, '', peer=CHAT, action={'type': 'chat_invite_user', 'member_id': 78}) == []
    print('OK  /приветствие: новичку приходит текст с его упоминанием')

    # ===== профиль и топ =====
    m = await say(15, '/профиль')
    assert 'Роль: Старший' not in m.text and '[id15|Юзер15]' in m.text and 'Сообщений:' in m.text and 'Капитал в этой беседе' in m.text
    m = await say(11, '/профиль @12'); assert 'Модератор (60)' in m.text
    m = await say(11, '/топ')
    assert 'Самые активные' in m.text and '🥇' in m.text
    # лидер по сообщениям
    for _ in range(60): await s.say(16, 'сообщение', peer=CHAT)
    m = await say(11, '/топ')
    top1 = m.text.split('\n')[2]
    assert '[id16|Юзер16]' in top1, top1
    print('OK  /профиль и /топ активности')

    # ===== в личке и в неактивной беседе =====
    assert 'только в беседах' in (await s.last(11, '/кик @15')).text
    assert 'только в беседах' in (await s.last(11, '/правила')).text
    other = CHAT_BASE + 99
    s.vk.members_by_peer[other] = [{'id': 10, 'admin': True, 'owner': True}]
    assert 'не активирован' in (await s.last(10, '/кик @15', peer=other)).text
    assert await s.say(10, '/мут @15', peer=other) == [], 'подсказка не чаще раза в 2 минуты'
    print('OK  модерация недоступна в личке и в неактивированной беседе')

    print('\nВсе тесты moderation пройдены')

asyncio.run(main())
