"""Ожидание ответа пользователя: бот задал вопрос («Введите промокод»), следующее сообщение - ответ."""
import time
from dataclasses import dataclass, field

TTL = 600  # секунд


@dataclass
class Pending:
    kind: str
    data: dict = field(default_factory=dict)
    expires: float = 0.0


class PendingStore:
    def __init__(self):
        self._items: dict[tuple[int, int], Pending] = {}

    def set(self, peer_id: int, user_id: int, kind: str, **data) -> None:
        self._items[(peer_id, user_id)] = Pending(kind, data, time.time() + TTL)

    def pop(self, peer_id: int, user_id: int) -> Pending | None:
        item = self._items.pop((peer_id, user_id), None)
        if item is None or item.expires < time.time():
            return None
        return item

    def clear(self, peer_id: int, user_id: int) -> None:
        self._items.pop((peer_id, user_id), None)
