import asyncio
from sim import Sim, OWNER, CHAT_BASE
from app.modules import admin
from app.roles import STAFF

CHAT = CHAT_BASE + 51


async def main():
    admin.BROADCAST_DELAY = 0
    s = await Sim.create()
    for u in range(1, 13):
        await s.say(u, '/start')
    await s.say(OWNER, '/start')
    roles = {1: 0, 2: 0, 3: 0, 4: 1, 5: 2, 6: 3, 7: 4, 8: 5, 9: 6, 10: 7}
    for u, r in roles.items():
        await s.set_role(u, r)

    # ===== панель =====
    assert 'Недостаточно прав' in (await s.last(1, '/админ')).text
    expected = {4: {'Тикеты'}, 5: {'Тикеты', 'Пользователь'}, 6: {'Тикеты', 'Пользователь', 'Промокоды'},
                8: {'Тикеты', 'Пользователь', 'Промокоды', 'Персонал'},
                9: {'Тикеты', 'Пользователь', 'Промокоды', 'Персонал', 'Статистика'},
                OWNER: {'Тикеты', 'Пользователь', 'Промокоды', 'Персонал', 'Статистика', 'Рассылка'}}
    for uid, labels in expected.items():
        m = await s.last(uid, '/panel')
        got = {b['action']['label'].split(' ', 1)[1] for b in m.buttons() if b['action']['label'] != '🏠 Меню'}
        assert got == labels, (uid, got)
    print('OK  панель: набор кнопок зависит от должности (1 → 8)')

    # ===== /инфо =====
    assert 'Недостаточно прав' in (await s.last(4, '/инфо @1')).text, 'агент (1) не видит инфо о пользователях'
    s.vk.screen['vasya'] = 1
    m = await s.last(5, '/инфо @vasya')
    assert '[id1|Юзер1]' in m.text and 'Должность: 👤 Пользователь' in m.text and 'Заблокирован: нет' in m.text
    assert 'Кошелёк (ЛС): 5 000 ₽' in m.text and 'Личные сообщения с ботом: да' in m.text
    assert not m.find('Заблокировать'), 'ст. агент (2) блокировать не может'
    assert 'не пользовался' in (await s.last(5, '/инфо 424242')).text
    assert 'Укажите пользователя' in (await s.last(5, '/info abc!')).text
    m = await s.last(5, '/инфо')                                  # диалог
    assert 'Отправьте пользователя' in m.text
    m = await s.last(5, '@vasya'); assert '[id1|Юзер1]' in m.text
    print('OK  /инфо: данные пользователя, права 2+, диалог')

    # ===== глобальный бан =====
    assert 'Недостаточно прав' in (await s.last(5, '/гбан @vasya')).text
    ev = await s.say(6, '/гбан @vasya накрутка')              # администратор (3)
    assert 'заблокирован(а) в боте' in ev[0].text and 'Причина: накрутка' in ev[0].text
    assert any(e.peer == 1 and 'заблокирован' in e.text for e in ev), 'пользователь уведомлён'
    assert (await s.db.fetchrow('SELECT banned, ban_reason FROM users WHERE id=1')) == {'banned': 1, 'ban_reason': 'накрутка'}
    assert 'уже заблокирован' in (await s.last(6, '/гбан @vasya')).text
    m = await s.last(5, '/инфо @vasya'); assert 'да (накрутка)' in m.text
    m = await s.last(6, '/инфо @vasya'); assert m.find('Разблокировать')
    # забаненный не может пользоваться ботом
    ev = await s.say(1, '/кошелёк'); assert 'заблокирован' in ev[-1].text and 'накрутка' in ev[-1].text
    # ... даже если добавить в беседу
    await s.make_chat(CHAT, creator=11, members=(1, 2))
    assert await s.say(1, '/кошелёк', peer=CHAT) == [], 'в беседе заблокированный игнорируется'
    assert await s.say(1, '/промо START', peer=CHAT) == []
    ev = await s.say(2, '/кошелёк', peer=CHAT); assert 'Кошелёк' in ev[-1].text, 'остальным бот отвечает'
    print('OK  /гбан: аккаунт заблокирован везде (лс и беседы), пользователь уведомлён')

    # иерархия
    assert 'к себе' in (await s.last(6, '/гбан @6')).text
    assert 'не ниже вашей' in (await s.last(6, '/гбан @7')).text, 'нельзя блокировать старше по должности'
    assert 'к себе' in (await s.last(6, '/гбан', reply_from=6)).text
    # разбан кнопкой из инфо
    m = await s.last(6, '/инфо @vasya')
    await s.press(6, 'Разблокировать', msg=m)
    assert 'разблокирован(а)' in m.text, 'сообщение с кнопкой отредактировано'
    ev = await s.say(1, '/меню'); assert 'Главное меню' in ev[-1].text
    assert 'не заблокирован' in (await s.last(6, '/гразбан @vasya')).text
    print('OK  иерархия при блокировке, разблокировка кнопкой, пользователь снова пользуется ботом')

    # ===== обнуление =====
    await s.give(2, rub=777_777)
    await s.give(2, rub=500, scope=CHAT)
    await s.cb(2, 'abuy', 'shawarma')
    await s.say(2, '/семья создать Тест')
    assert 'Недостаточно прав' in (await s.last(6, '/обнулить @2')).text, 'нужна должность 4+'
    m = await s.last(7, '/обнулить @2')
    assert 'Обнулить аккаунт' in m.text and m.find('Да, обнулить')
    assert (await s.wallet(2))['rub'] != 5000, 'до подтверждения всё на месте'
    m = await s.press(7, 'Да, обнулить', msg=m)
    assert 'обнулён' in m.text
    assert await s.wallet(2) is None and await s.wallet(2, CHAT) is None
    assert not await s.db.fetchrow('SELECT 1 FROM owned_assets WHERE user_id=2')
    assert not await s.db.fetchrow('SELECT 1 FROM families WHERE owner_id=2') and not await s.db.fetchrow('SELECT 1 FROM family_members WHERE user_id=2')
    assert await s.db.fetchrow('SELECT 1 FROM users WHERE id=2'), 'сам пользователь остаётся'
    await s.say(2, '/кошелёк'); assert (await s.wallet(2))['rub'] == 5000, 'после обнуления - как новичок'
    assert 'не ниже вашей' in (await s.last(7, '/обнулить @8')).text
    m = await s.last(7, '/обнулить @3'); m = await s.press(6, 'Да, обнулить', msg=m)
    assert s.vk.answers[-1][1] == 'Эта кнопка предназначена не для вас'
    print('OK  /обнулить: подтверждение, очистка во всех мирах, аккаунт остаётся; чужая кнопка не работает')

    # ===== должности =====
    assert 'Недостаточно прав' in (await s.last(7, '/должность @3 1')).text, 'нужна должность 5+'
    m = await s.last(8, '/должность @3')               # без номера - подсказка
    assert 'Формат' in m.text and '8 - Руководитель бота' in m.text
    ev = await s.say(8, '/должность @3 2')              # гл. админ (5) выдаёт 2
    assert 'Пользователь → Старший Агент Поддержки' in ev[0].text
    assert any(e.peer == 3 and 'Старший Агент Поддержки' in e.text and '⏫' in e.text for e in ev)
    assert (await s.db.fetchval('SELECT role FROM users WHERE id=3')) == 2
    assert 'только должность ниже вашей (до 4)' in (await s.last(8, '/должность @3 5')).text
    assert 'не ниже вашей' in (await s.last(8, '/должность @9 1')).text
    assert 'уже эта должность' in (await s.last(8, '/должность @3 2')).text
    assert 'от 0 до 8' in (await s.last(8, '/должность @3 9')).text
    assert 'свою должность' in (await s.last(8, '/должность @8 1')).text
    assert 'основателя изменить нельзя' in (await s.last(10, f'/должность {OWNER} 0')).text
    assert 'ещё не пользовался' in (await s.last(8, '/должность 31337 1')).text
    ev = await s.say(8, '/должность @3 0'); assert any('⏬' in e.text for e in ev)
    # заместитель (7) выдаёт до 6, руководитель (8, основатель) - любую
    await s.say(10, '/должность @3 6'); assert (await s.db.fetchval('SELECT role FROM users WHERE id=3')) == 6
    assert 'ниже вашей (до 6)' in (await s.last(10, '/должность @3 7')).text
    await s.say(OWNER, '/должность @3 8'); assert (await s.db.fetchval('SELECT role FROM users WHERE id=3')) == 8
    await s.say(OWNER, '/должность @3 0')
    m = await s.last(4, '/должности')
    assert 'Руководитель бота' in m.text and 'Агент поддержки' in m.text and '[id1000|' in m.text
    print('OK  /должность: только ниже своей, основатель недоступен, уведомления, список сотрудников')

    # ===== статистика =====
    assert 'Недостаточно прав' in (await s.last(8, '/статистика')).text
    m = await s.last(9, '/stats')
    assert 'Пользователей: 13' in m.text and 'Бесед: 1 (активных: 1)' in m.text and 'рублей в обороте' in m.text
    print('OK  /статистика (6+)')

    # ===== рассылка =====
    assert 'Недостаточно прав' in (await s.last(10, '/рассылка Привет всем')).text, 'зам. руководителя (7) рассылать не может'
    # получатели: dm_ok=1 и не заблокированы; закрытые ЛС → недоставка
    s.vk.blocked.add(5)
    await s.db.execute('UPDATE users SET banned=1 WHERE id=12')
    await s.say(50, '/кошелёк', peer=CHAT)                       # пользователь только из беседы - в ЛС не писал
    count = await s.db.fetchval('SELECT COUNT(*) FROM users WHERE dm_ok=1 AND banned=0')
    m = await s.last(OWNER, '/рассылка')
    assert 'Отправьте текст рассылки' in m.text
    m = await s.last(OWNER, 'Внимание!\nЗавтра в 20:00 начнётся турнир.\nПризовой фонд - 1 000 000 ₽')
    assert 'Предпросмотр рассылки' in m.text and 'Завтра в 20:00' in m.text
    assert f'Получателей: {count}' in m.text and m.find(f'Отправить ({count})') and m.find('Отмена')
    assert '📢 Это рассылка от [id1000|Основателя]' in m.text, 'слово «Основателя» - ссылка на профиль основателя'
    # отмена
    m2 = await s.press(OWNER, 'Отмена', msg=m)
    assert 'отменена' in m2.text
    m = await s.last(OWNER, '/рассылка Новый текст для всех')
    n_before = len(s.vk.events)
    m = await s.press(OWNER, 'Отправить', msg=m)
    assert 'Рассылка запущена' in m.text
    await asyncio.gather(*list(s.app.tasks))
    sent = [e for e in s.vk.events[n_before:] if 'Новый текст для всех' in e.text]
    peers = {e.peer for e in sent}
    assert peers == {r['id'] for r in await s.db.fetch('SELECT id FROM users WHERE dm_ok=1 AND banned=0 AND id != 5')}
    assert 12 not in peers and 50 not in peers and 5 not in peers
    assert all(e.text.endswith('📢 Это рассылка от [id1000|Основателя]') for e in sent)
    report = s.vk.events[-1]
    assert report.peer == OWNER and f'Доставлено: {count - 1}' in report.text and 'Не доставлено: 1' in report.text, report.text
    print(f'OK  рассылка: предпросмотр с подписью, отмена, отправка {len(peers)} получателям, отчёт; заблокированным и «только из бесед» не уходит')

    # повторное нажатие / устаревший черновик
    m = await s.press(OWNER, 'Отправить', msg=m)
    assert 'Черновик устарел' in m.text
    m = await s.last(OWNER, '/рассылка Ещё один текст')
    s.app.drafts[OWNER] = (s.app.drafts[OWNER][0], 0)
    m = await s.press(OWNER, 'Отправить', msg=m)
    assert 'Черновик устарел' in m.text
    assert 'Слишком длинный' in (await s.last(OWNER, '/рассылка ' + 'я' * 4000)).text
    print('OK  повторная отправка и устаревший черновик не рассылают заново')

    # пользователь не может запустить рассылку чужой кнопкой / через диалог
    m = await s.last(OWNER, '/рассылка Секретный текст')
    await s.press(10, 'Отправить', msg=m)
    assert s.vk.answers[-1][1] == 'Эта кнопка предназначена не для вас'
    await s.last(10, '/админ')
    assert OWNER in s.app.drafts
    print('OK  рассылку подтвердить может только её автор')

    print('\nВсе тесты admin пройдены')

asyncio.run(main())
