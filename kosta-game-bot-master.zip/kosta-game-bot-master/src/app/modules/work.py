"""Работа: вакансии, устроиться, уволиться, отработать смену."""
import random

from ..data.education import EDU_BY_KEY
from ..data.jobs import JOBS, JOBS_BY_KEY
from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, dur, rub
from ..util.pages import find_ref, paginate
from .study import diplomas

PAGE_SIZE = 4
BONUS_CHANCE = 0.07
BONUS_MULTIPLIER = 1.5
EXPERIENCE_STEP = 10          # +1% к оплате за каждые 10 смен
EXPERIENCE_MAX = 50           # но не больше +50%


def roll_shift(job, shifts: int = 0, rng=random):
    """Результат смены: (вид, сумма, текст). Сумма < 0 - штраф. Вид: success | bonus | fail."""
    if job.fail_chance and rng.random() < job.fail_chance:
        fine = rng.randint(*job.fine) if job.fine[1] > 0 else 0
        text = rng.choice(job.fail_texts) if job.fail_texts else 'Смена не задалась, и платить вам не стали.'
        return 'fail', -fine, text
    pay = rng.randint(job.min_pay, job.max_pay)
    pay = pay * (100 + min(EXPERIENCE_MAX, shifts // EXPERIENCE_STEP)) // 100
    text = rng.choice(job.success_texts)
    if rng.random() < BONUS_CHANCE:
        return 'bonus', int(pay * BONUS_MULTIPLIER), text
    return 'success', pay, text


def _job_line(job, done: set, current: str) -> str:
    if job.key == current:
        status = '⭐ ваша работа'
    elif job.edu and job.edu not in done:
        status = f'🔒 нужен диплом: {EDU_BY_KEY[job.edu].title}'
    else:
        status = '✅ можно устроиться'
    risk = ' · ⚠ риск' if job.fail_chance else ''
    return (f'{job.emoji} {job.title} - {job.description}\n'
            f'    💵 {rub(job.min_pay)}-{rub(job.max_pay)} · ⏱ {dur(job.cooldown)}{risk}\n    {status}')


@registry.command('jobs', names=['работы', 'вакансии', 'jobs'], desc='вакансии и ваша работа', section='work',
                  usage='[номер]')
async def cmd_jobs(ctx):
    w = await ctx.wallet()
    done = await diplomas(ctx.db, ctx.scope, ctx.user_id)
    arg = ctx.args.strip()
    if arg.startswith('c:'):
        return await _card(ctx, arg[2:], w, done)

    page = int(arg) if arg.isdigit() else 0
    items, page, total = paginate(JOBS, page, PAGE_SIZE)
    cur = JOBS_BY_KEY.get(w['job'])
    lines = [f'💼 Вакансии | стр. {page + 1}/{total}\n{SEP}',
             f'Ваша работа: {cur.emoji + " " + cur.title if cur else "не работаете"} · смен: {w["shifts"]}', '']
    lines += [_job_line(j, done, w['job']) + '\n' for j in items]
    lines.append('Выберите вакансию кнопкой. Нет диплома? Откройте 🎓 Учёбу.')
    kb = ctx.kb()
    for i, j in enumerate(items):
        if i and i % 2 == 0:
            kb.row()
        kb.btn(f'{j.emoji} {j.title}', 'jobs', f'c:{j.key}', color='primary' if j.key == w['job'] else 'secondary')
    kb.row()
    if page > 0:
        kb.btn('◀', 'jobs', str(page - 1))
    if page < total - 1:
        kb.btn('▶', 'jobs', str(page + 1))
    kb.btn('🎓 Учёба', 'study').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


async def _card(ctx, key: str, w, done: set):
    job = JOBS_BY_KEY.get(key)
    if job is None:
        return await ctx.respond('❗ Вакансия не найдена', ctx.kb().btn('💼 Вакансии', 'jobs'))
    kb = ctx.kb()
    if job.key == w['job']:
        kb.btn('⚒ Работать', 'work', color='positive')
    elif not job.edu or job.edu in done:
        kb.btn('✅ Устроиться', 'hire', job.key, color='positive')
    elif job.edu:
        kb.btn(f'🎓 {EDU_BY_KEY[job.edu].title}'[:40], 'study', f'c:{job.edu}')
    kb.row().btn('💼 К списку', 'jobs').btn('🏠 Меню', 'menu')
    risk = f'\n⚠ Есть риск неудачной смены ({int(job.fail_chance * 100)}%)' if job.fail_chance else ''
    if job.fine[1]:
        risk += f', штраф до {rub(job.fine[1])}'
    await ctx.respond(f'{_job_line(job, done, w["job"])}{risk}', kb)


@registry.command('hire', names=['устроиться', 'hire'], desc='устроиться на работу', section='work', usage='<работа>')
async def cmd_hire(ctx):
    w = await ctx.wallet()
    ref = ctx.args.strip()
    if not ref:
        return await cmd_jobs(ctx)
    job = find_ref(list(JOBS), ref)
    if job is None:
        return await ctx.respond('❗ Такой вакансии нет. Список: /работы', ctx.kb().btn('💼 Вакансии', 'jobs'))
    done = await diplomas(ctx.db, ctx.scope, ctx.user_id)
    if job.edu and job.edu not in done:
        e = EDU_BY_KEY[job.edu]
        return await ctx.respond(
            f'🔒 Для работы «{job.title}» нужен диплом: {e.emoji} {e.title}',
            ctx.kb().btn('🎓 Учиться', 'study', f'c:{e.key}', color='primary').btn('💼 Вакансии', 'jobs'))
    if w['job'] == job.key:
        return await ctx.respond(f'ℹ Вы уже работаете: {job.emoji} {job.title}', ctx.kb().btn('⚒ Работать', 'work'))
    await ctx.db.execute('UPDATE wallets SET job=$3 WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id, job.key)
    await ctx.respond(
        f'✅ Вы устроились: {job.emoji} {job.title}\n'
        f'💵 {rub(job.min_pay)}-{rub(job.max_pay)} за смену, перерыв {dur(job.cooldown)}',
        ctx.kb().btn('⚒ Работать', 'work', color='positive').btn('💼 Вакансии', 'jobs'))


@registry.command('quit', names=['уволиться', 'quit'], desc='уйти с работы', section='work')
async def cmd_quit(ctx):
    w = await ctx.wallet()
    job = JOBS_BY_KEY.get(w['job'])
    if job is None:
        return await ctx.respond('ℹ Вы нигде не работаете', ctx.kb().btn('💼 Вакансии', 'jobs'))
    await ctx.db.execute("UPDATE wallets SET job='' WHERE scope=$1 AND user_id=$2", ctx.scope, ctx.user_id)
    await ctx.respond(f'👋 Вы уволились с работы «{job.title}»', ctx.kb().btn('💼 Вакансии', 'jobs').btn('🏠 Меню', 'menu'))


@registry.command('work', names=['работать', 'смена', 'work'], desc='отработать смену', section='work')
async def cmd_work(ctx):
    w = await ctx.wallet()
    job = JOBS_BY_KEY.get(w['job'])
    if job is None:
        return await ctx.respond('💼 Вы пока нигде не работаете. Выберите вакансию:',
                                 ctx.kb().btn('💼 Вакансии', 'jobs', color='primary').btn('🏠 Меню', 'menu'))
    t = accounts.now()
    claimed = await ctx.db.fetchrow(
        'UPDATE wallets SET work_next=$3, shifts=shifts+1 '
        'WHERE scope=$1 AND user_id=$2 AND work_next <= $4 RETURNING shifts',
        ctx.scope, ctx.user_id, t + job.cooldown, t)
    if claimed is None:
        left = max(1, w['work_next'] - t)
        return await ctx.respond(
            f'⏳ {job.emoji} {job.title}: вы ещё отдыхаете после смены.\nСледующая смена через {dur(left)}.',
            ctx.kb().btn('🔄 Проверить', 'work').btn('💼 Вакансии', 'jobs'))

    kind, amount, text = roll_shift(job, claimed['shifts'] - 1)
    lines = [f'{job.emoji} {job.title} - смена завершена!', '', text]
    if kind == 'bonus':
        lines.append('🎉 Вам повезло - начальник выписал премию!')
    lines.append('')
    if amount > 0:
        async with ctx.db.transaction() as tx:
            net, tax = await accounts.apply_tax(tx, ctx.scope, amount)
            await accounts.change(tx, ctx.scope, ctx.user_id, net, 'rub', 'work', job.title)
        lines.append(f'💵 Заработано: {rub(net)}')
        if tax:
            lines.append(f'🏛 Налог в казну беседы: {rub(tax)}')
    elif amount < 0:
        async with ctx.db.transaction() as tx:
            cur = await tx.fetchval('SELECT rub FROM wallets WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
            fine = min(-amount, cur)
            if fine:
                await accounts.change(tx, ctx.scope, ctx.user_id, -fine, 'rub', 'fine', job.title)
        lines.append(f'💸 Потеряно: {rub(fine)}' if fine else '😕 За эту смену ничего не заработано')
    else:
        lines.append('😕 За эту смену ничего не заработано')

    balance = (await ctx.wallet())['rub']
    bonus = min(EXPERIENCE_MAX, claimed['shifts'] // EXPERIENCE_STEP)
    lines.append(f'💳 Баланс: {rub(balance)}')
    lines.append(f'⏳ Следующая смена через {dur(job.cooldown)}')
    lines.append(f'⭐ Смен: {claimed["shifts"]} (стаж даёт +{bonus}% к оплате)')
    await ctx.respond('\n'.join(lines), ctx.kb().btn('⚒ Ещё смену', 'work').btn('💼 Вакансии', 'jobs').btn('🏠 Меню', 'menu'))
