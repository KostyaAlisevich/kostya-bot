"""Inline-клавиатуры под сообщениями (кнопки-«callback»).

JSON собирается вручную, поэтому код не зависит от версии vkbottle.

Лимиты ВК для inline: не более 10 кнопок, не более 6 рядов, подпись до 40 символов, payload до 255 байт.
Кроме того, на телефоне подпись обрезается многоточием, если не помещается в кнопку. Поэтому раскладка
подбирается автоматически по ширине подписей (см. CAP): длинные подписи идут по одной или по две в ряд.
"""
import json
import logging

log = logging.getLogger('bot.kb')

MAX_BUTTONS = 10
MAX_ROWS = 6
MAX_PER_ROW = 4
COLORS = ('primary', 'secondary', 'positive', 'negative')

# Сколько «условных знаков» помещается в кнопку, если в ряду n кнопок (эмодзи считается за 2 знака).
# Значения подобраны по скриншотам клиента ВК: при трёх кнопках в ряду влезает ~7 знаков, при двух ~12.
CAP = {1: 28, 2: 11, 3: 7, 4: 5}


def label_width(text: str) -> int:
    """Ширина подписи в условных знаках: эмодзи и символы-картинки шире букв."""
    width = 0
    for ch in text:
        code = ord(ch)
        if ch in '\ufe0f\u200d':        # вариационный селектор и «склейка» ширины не добавляют
            continue
        wide = code >= 0x1F000 or 0x2600 <= code <= 0x27BF or 0x2B00 <= code <= 0x2BFF or 0x23E9 <= code <= 0x23FF
        width += 2 if wide else 1
    return width


def _fits(buttons: list[dict]) -> bool:
    n = len(buttons)
    return n <= MAX_PER_ROW and all(label_width(b['action']['label']) <= CAP[n] for b in buttons)


def layout(rows: list[list[dict]]) -> list[list[dict]]:
    """Разбивает ряды так, чтобы подписи влезали; затем, если рядов больше лимита, склеивает соседние."""
    out: list[list[dict]] = []
    for row in rows:
        current: list[dict] = []
        for button in row:
            if _fits(current + [button]):
                current.append(button)
            else:
                if current:
                    out.append(current)
                current = [button]
        if current:
            out.append(current)

    # слишком много рядов: пробуем объединять соседние, пока подписи помещаются
    while len(out) > MAX_ROWS:
        for i in range(len(out) - 1):
            if _fits(out[i] + out[i + 1]):
                out[i:i + 2] = [out[i] + out[i + 1]]
                break
        else:
            break
    return out


class KB:
    # Список проблем раскладки (используется в тестах и пишется в лог): ('overflow' | 'wide', подробности)
    problems: list[tuple[str, str]] = []

    def __init__(self, uid: int = 0):
        self.uid = uid
        self.rows: list[list[dict]] = [[]]
        self.overflow = False

    def btn(self, label: str, cmd: str, args: str = '', color: str = 'secondary', u: int | None = None) -> 'KB':
        """Кнопка, которая вызывает команду cmd (ключ из реестра) с аргументами args.

        u - кому разрешено нажимать: по умолчанию тому, для кого собрана клавиатура;
        u=0 - всем участникам беседы.
        """
        payload = {'c': cmd}
        if args:
            payload['a'] = args
        owner = self.uid if u is None else u
        if owner:
            payload['u'] = owner
        data = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
        if len(data.encode('utf-8')) > 255:
            raise ValueError(f'payload кнопки длиннее 255 байт: {data}')
        if color not in COLORS:
            color = 'secondary'
        self.rows[-1].append({
            'action': {'type': 'callback', 'label': label[:40], 'payload': data},
            'color': color,
        })
        return self

    def row(self) -> 'KB':
        if self.rows[-1]:
            self.rows.append([])
        return self

    def buttons(self) -> list[dict]:
        return [b for r in self.rows for b in r]

    def to_json(self) -> str | None:
        rows = layout([r for r in self.rows if r])
        if not rows:
            return None
        out, count, overflow = [], 0, False
        for row in rows[:MAX_ROWS]:
            kept = row[:max(0, MAX_BUTTONS - count)]
            if len(kept) < len(row):
                overflow = True
            if kept:
                out.append(kept)
                count += len(kept)
        if len(rows) > MAX_ROWS:
            overflow = True
        self.overflow = overflow
        if overflow:
            labels = [b['action']['label'] for b in self.buttons()]
            KB.problems.append(('overflow', ' | '.join(labels)))
            log.warning('клавиатура не помещается в лимиты ВК, часть кнопок отброшена: %s', labels)
        for row in out:
            for b in row:
                label = b['action']['label']
                if label_width(label) > CAP[1]:
                    KB.problems.append(('wide', label))
                    log.warning('подпись кнопки слишком длинная и будет обрезана: %s', label)
        return json.dumps({'inline': True, 'buttons': out}, ensure_ascii=False, separators=(',', ':'))


def home_row(kb: KB, cmd: str = 'menu', label: str = '🏠 Меню') -> KB:
    return kb.row().btn(label, cmd)
