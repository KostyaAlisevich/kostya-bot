import asyncio
import json
from sim import Sim, OWNER, CHAT_BASE
from app.data.clans import CLAN_ITEMS, CLAN_ITEMS_BY_KEY, UPGRADE_COST, max_members
from app.modules import clans
from app.services import accounts
from app.framework.keyboards import label_width

CHAT = CHAT_BASE + 91
H = 3600


class Fixed:
    """Подменный генератор: uniform() возвращает заданные значения (по умолчанию 1.0)."""
    def __init__(self, *vals):
        self.vals = list(vals)

    def uniform(self, a, b):
        return self.vals.pop(0) if self.vals else 1.0


async def reply_to(s, uid, text, peer=None):
    """Ответ бота именно тому, кто написал (а не уведомление другому игроку)."""
    peer = peer or uid
    events = await s.say(uid, text, peer=peer)
    mine = [e for e in events if e.peer == peer]
    assert mine, f'нет ответа на «{text}»'
    return mine[-1]


async def users(s, *ids, rub=100_000, scope=0):
    for u in ids:
        await s.say(u, '/start')
        await s.give(u, rub=rub, scope=scope)


async def mk_clan(s, name, owner, members=(), bank=0, level=1, trophies=0, items=None, scope=0, shield=0, last_war=0):
    cid = await s.db.fetchval(
        'INSERT INTO clans (scope, name, owner_id, bank, level, trophies, shield_until, last_war, created_at) '
        'VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 0) RETURNING id', scope, name, owner, bank, level, trophies, shield, last_war)
    await s.db.execute("INSERT INTO clan_members (scope, user_id, clan_id, role) VALUES ($1, $2, $3, 'leader')", scope, owner, cid)
    for m in members:
        await s.db.execute("INSERT INTO clan_members (scope, user_id, clan_id, role) VALUES ($1, $2, $3, 'member')", scope, m, cid)
    for key, qty in (items or {}).items():
        await s.db.execute('INSERT INTO clan_items (clan_id, item_key, qty) VALUES ($1, $2, $3)', cid, key, qty)
    return cid


async def main():
    # ===== расчёт мощи и каталог =====
    assert clans.power({}, 1, 3) == (15, 15)
    assert clans.power({'sword': 10, 'shield': 5}, 1, 3) == (95, 55)
    assert clans.power({'sword': 10, 'shield': 5}, 3, 3) == (int(95 * 1.2), int(55 * 1.2))
    assert clans.power({'peace24': 7, 'unknown': 5}, 1, 0) == (0, 0), 'щиты мира и неизвестные ключи мощи не дают'
    assert max_members(1) == 10 and max_members(5) == 30
    assert len({i.key for i in CLAN_ITEMS}) == len(CLAN_ITEMS) == 12
    assert {i.kind for i in CLAN_ITEMS} == {'attack', 'defense', 'shield'}
    assert all(label_width(f'{i.emoji} {i.title}') <= 28 for i in CLAN_ITEMS)
    print('OK  расчёт мощи (предметы, бойцы, уровень), каталог: нападение, защита, щиты мира')

    s = await Sim.create()
    await users(s, 1, 2, 3, 4, rub=5000)

    # ===== создание клана =====
    m = await s.last(1, '/клан')
    assert 'Кланы' in m.text and 'Создать клан стоит 20 000 ₽' in m.text
    assert m.labels() == ['➕ Создать клан', '🏆 Топ кланов', '🏠 Меню']
    assert 'Не хватает денег: создание клана стоит 20 000 ₽' in (await s.last(1, '/клан создать Волки')).text
    assert not await s.db.fetchrow('SELECT 1 FROM clans') and (await s.wallet(1))['rub'] == 5000
    await s.give(1, rub=100_000)
    m = await s.last(1, '/клан создать Волки')
    assert '🎉 Клан «Волки» создан' in m.text and 'Уровень: 1 из 5' in m.text and '👥 1 из 10' in m.text
    assert 'Казна: 0 ₽' in m.text and 'Атака: 5 · 🛡 Защита: 5' in m.text and 'Щита мира нет' in m.text and 'Ваша роль: 👑 Глава' in m.text
    assert (await s.wallet(1))['rub'] == 80_000
    assert m.labels() == ['🛒 Магазин', '⚔ В бой', '👥 Состав', '💰 Взнос', '⬆ Улучшить', '🏆 Топ', '🚪 Выйти', '🏠 Меню']
    await s.give(2, rub=100_000)
    assert 'уже есть' in (await s.last(2, '/клан создать волки')).text, 'названия различаются без учёта регистра'
    assert 'не короче 3' in (await s.last(2, '/клан создать Аб')).text
    assert 'уже состоите' in (await s.last(1, '/клан создать Другой')).text
    # создание диалогом: бот спрашивает название, ответ - следующее сообщение
    await s.give(3, rub=100_000)
    m = await s.last(3, '/клан'); m = await s.press(3, 'Создать клан')
    assert 'Отправьте название клана' in m.text
    m = await s.last(3, 'Драконы')
    assert 'Клан «Драконы» создан' in m.text
    print('OK  создание клана: оплата 20 000 ₽, карточка, повторное имя/короткое имя/второй клан, диалог')

    # ===== приглашения и роли =====
    s.vk.screen['petya'] = 2
    ev = await s.say(1, '/клан пригласить @petya')
    invite = [e for e in ev if e.peer == 2][-1]
    assert 'приглашают в клан «Волки»' in invite.text and invite.find('Принять')
    m = await s.last(2, '/клан')
    assert 'Вас пригласили в клан «Волки»' in m.text and m.find('Принять приглашение')
    m = await s.press(2, 'Принять', msg=invite)
    assert 'Вы вступили в клан' in m.text and '👥 2 из 10' in m.text
    assert 'нет приглашений' in (await s.last(4, '/клан принять')).text
    assert 'Приглашать могут глава и офицеры' in (await s.last(2, '/клан пригласить @4')).text
    assert 'Менять роли может только глава' in (await s.last(2, '/клан повысить @petya')).text
    assert 'теперь ⭐ офицер' in (await s.last(1, '/клан повысить @petya')).text
    assert 'Это действие нельзя применить к главе' in (await s.last(1, '/клан понизить @1')).text
    ev = await s.say(2, '/клан пригласить 4')                      # офицер может приглашать
    assert any(e.peer == 4 and 'приглашают' in e.text for e in ev)
    await s.last(4, '/клан принять')
    assert await s.db.fetchval("SELECT clan_id FROM clan_members WHERE user_id=4") == await s.db.fetchval("SELECT clan_id FROM clan_members WHERE user_id=1")
    assert 'уже состоит' in (await s.last(1, '/клан пригласить @3')).text
    assert 'нет в вашем клане' in (await s.last(1, '/клан повысить @3')).text
    # клан заполнен
    cid = await s.db.fetchval('SELECT id FROM clans WHERE name=$1', 'Волки')
    for u in range(200, 207):
        await s.db.execute("INSERT INTO clan_members (scope, user_id, clan_id) VALUES (0, $1, $2)", u, cid)
    await users(s, 5, rub=0)
    assert 'нет мест' in (await s.last(1, '/клан пригласить 5')).text
    await s.db.execute('DELETE FROM clan_members WHERE user_id >= 200')
    print('OK  приглашения: кнопка «Принять», права офицера, повышение, клан без мест')

    # ===== состав =====
    m = await s.last(1, '/клан состав')
    assert '3 из 10' in m.text and '👑 [id1|Юзер1]' in m.text and '⭐ [id2|Юзер2]' in m.text and '👤 [id4|Юзер4]' in m.text
    assert 'Управление: /клан повысить' in m.text
    assert 'Управление: /клан пригласить' in (await s.last(2, '/клан состав')).text and 'Управление' not in (await s.last(4, '/клан состав')).text
    print('OK  /клан состав: роли и подсказки по должности')

    # ===== казна: взнос и снятие =====
    m = await s.last(2, '/клан взнос')
    assert 'Взнос в казну клана' in m.text and m.labels()[:4] == ['💰 1 000', '💰 10 000', '💰 50%', '💰 Всё']
    m = await s.press(2, '1 000')
    assert 'Внесено в казну клана: 1 000 ₽' in m.text and 'Казна: 1 000 ₽' in m.text
    await s.last(2, '/клан взнос 4000')
    assert await s.db.fetchval('SELECT bank FROM clans WHERE id=$1', cid) == 5000
    assert await s.db.fetchval('SELECT donated FROM clan_members WHERE user_id=2') == 5000
    assert 'Недостаточно средств' in (await s.last(4, '/клан взнос 99999')).text
    assert 'Снимать деньги из казны может только глава' in (await s.last(2, '/клан снять 100')).text
    b0 = (await s.wallet(1))['rub']
    assert 'Из казны снято: 2 000 ₽' in (await s.last(1, '/клан снять 2000')).text
    assert (await s.wallet(1))['rub'] == b0 + 2000 and await s.db.fetchval('SELECT bank FROM clans WHERE id=$1', cid) == 3000
    assert 'только 3 000' in (await s.last(1, '/клан снять 99999')).text.replace('\xa0', ' ')
    print('OK  казна: взнос кнопкой и командой, учёт вкладов, снятие только главой')

    # ===== магазин клана =====
    await s.db.execute('UPDATE clans SET bank=300000 WHERE id=$1', cid)
    m = await s.last(2, '/клан'); m = await s.press(2, 'Магазин')
    assert 'Магазин клана | стр. 1/4' in m.text and 'Мечи - 4 000 ₽ (+8 атака), у вас: 0' in m.text
    assert m.labels() == ['⚔ Мечи', '🏹 Луки', '🎯 Арбалеты', '▶', '◀ К клану', '🏠 Меню']
    m = await s.press(2, 'Мечи')
    assert 'Мечи' in m.text and 'Цена: 4 000 ₽' in m.text and m.labels()[:3] == ['×1', '×5', '×10']
    m = await s.press(2, '×10')
    assert 'Куплено для клана: ⚔ Мечи ×10 за 40 000 ₽' in m.text and 'В казне осталось: 260 000 ₽' in m.text
    assert (await clans.stock(s.db, cid)) == {'sword': 10}
    m = await s.cb(2, 'clan_buy', 'shield 5')
    assert (await clans.stock(s.db, cid)) == {'sword': 10, 'shield': 5}
    m = await s.cb(4, 'clan_shop', 'i:sword')                     # рядовой боец видит карточку, но без кнопок покупки
    assert 'Покупать могут глава и офицеры' in m.text and not m.find('×1')
    assert 'Покупать могут' in (await s.cb(4, 'clan_buy', 'sword 1')).text
    assert (await clans.stock(s.db, cid))['sword'] == 10
    m = await s.last(1, '/клан инфо')
    assert 'Атака: 95 · 🛡 Защита: 55' in m.text            # 3 бойца: 15 + 80, 15 + 40
    # щиты мира складываются по времени
    m = await s.cb(2, 'clan_buy', 'peace24 7')                 # количество игнорируется: щит всегда один
    assert 'Щит мира 24 часа' in m.text and '−' not in m.text
    await s.cb(2, 'clan_buy', 'peace12 1')
    until = await s.db.fetchval('SELECT shield_until FROM clans WHERE id=$1', cid)
    assert abs(until - (accounts.now() + 36 * H)) < 5
    assert 'Щит мира: ещё 1 д 12 ч' in (await s.last(1, '/клан')).text
    # нехватка денег и лимит запаса
    await s.db.execute('UPDATE clans SET bank=1000 WHERE id=$1', cid)
    m = await s.cb(2, 'clan_buy', 'cannon 1')
    assert 'не хватает денег' in m.text and (await clans.stock(s.db, cid)).get('cannon') is None
    assert await s.db.fetchval('SELECT bank FROM clans WHERE id=$1', cid) == 1000
    await s.db.execute('UPDATE clans SET bank=10000000 WHERE id=$1', cid)
    await s.db.execute("UPDATE clan_items SET qty=9999 WHERE clan_id=$1 AND item_key='sword'", cid)
    assert 'Нельзя хранить больше' in (await s.cb(2, 'clan_buy', 'sword 5')).text
    assert await s.db.fetchval('SELECT bank FROM clans WHERE id=$1', cid) == 10000000, 'при ошибке запаса деньги не списываются'
    await s.db.execute("UPDATE clan_items SET qty=10 WHERE clan_id=$1 AND item_key='sword'", cid)
    # все страницы магазина и карточки
    for page in range(4):
        await s.cb(2, 'clan_shop', str(page))
    for it in CLAN_ITEMS:
        assert it.title in (await s.cb(2, 'clan_shop', f'i:{it.key}')).text
    print('OK  магазин клана: покупка ×10, права, щиты мира складываются, нехватка денег, лимит запаса, все страницы')

    # ===== улучшение =====
    await s.db.execute('UPDATE clans SET bank=1000 WHERE id=$1', cid)
    m = await s.last(2, '/клан улучшить')
    assert 'Улучшение клана до уровня 2' in m.text and '60 000 ₽' in m.text and 'Не хватает 59 000 ₽' in m.text and not m.find('Улучшить за')
    assert 'не хватает' in (await s.last(2, '/клан улучшить да')).text
    assert 'Улучшать клан могут' in (await s.last(4, '/клан улучшить')).text
    await s.db.execute('UPDATE clans SET bank=100000 WHERE id=$1', cid)
    m = await s.last(2, '/клан улучшить'); assert m.find('Улучшить за 60 000 ₽')
    m = await s.press(2, 'Улучшить за')
    assert 'улучшен до уровня 2' in m.text and 'Уровень: 2 из 5' in m.text and '3 из 15' in m.text and 'Казна: 40 000 ₽' in m.text
    assert 'Атака: 104' in m.text                                # (15 + 80) * 1.1
    await s.db.execute('UPDATE clans SET level=5 WHERE id=$1', cid)
    assert 'максимального уровня' in (await s.last(2, '/клан улучшить')).text
    await s.db.execute('UPDATE clans SET level=1, bank=0 WHERE id=$1', cid)
    print('OK  улучшение клана: цена из казны, +места, +10% мощи, максимальный уровень')

    # ===== исключение, передача власти, выход, роспуск =====
    assert 'не ниже' not in (await s.last(2, '/клан исключить @4')).text
    assert not await s.db.fetchrow('SELECT 1 FROM clan_members WHERE user_id=4')
    await s.say(4, '/клан принять')
    assert 'Исключать могут глава и офицеры' in (await s.last(4, '/клан исключить @2')).text
    assert 'не может просто выйти' in (await s.last(1, '/клан выйти')).text
    assert 'Исключить участника с той же' not in (await s.last(2, '/клан исключить @3')).text
    ev = await s.last(2, '/клан выйти')
    assert 'вышли из клана' in ev.text and not await s.db.fetchrow('SELECT 1 FROM clan_members WHERE user_id=2')
    s.vk.screen['petya'] = 2
    await s.say(1, '/клан пригласить @petya'); await s.say(2, '/клан принять'); await s.say(1, '/клан повысить @petya')
    assert 'Нельзя исключить участника с той же или более высокой ролью' in (await s.last(2, '/клан исключить @1')).text
    assert 'Передать власть может только глава' in (await s.last(2, '/клан лидер @4')).text
    m = await s.last(1, '/клан лидер @petya')
    assert 'Новый глава клана «Волки»: [id2|Юзер2]' in m.text
    assert await s.db.fetchval("SELECT role FROM clan_members WHERE user_id=1") == 'officer'
    assert await s.db.fetchval('SELECT owner_id FROM clans WHERE id=$1', cid) == 2
    await s.last(2, '/клан лидер @1')                              # вернуть
    # роспуск с подтверждением и возвратом казны
    await s.db.execute('UPDATE clans SET bank=7000 WHERE id=$1', cid)
    m = await s.last(1, '/клан распустить')
    assert 'Распустить клан «Волки»?' in m.text and m.find('Да, распустить') and await s.db.fetchval('SELECT 1 FROM clans WHERE id=$1', cid)
    b0 = (await s.wallet(1))['rub']
    m = await s.press(1, 'Да, распустить')
    assert 'распущен' in m.text and (await s.wallet(1))['rub'] == b0 + 7000
    assert not await s.db.fetchrow('SELECT 1 FROM clans WHERE id=$1', cid) and not await s.db.fetchrow('SELECT 1 FROM clan_members WHERE clan_id=$1', cid)
    assert not await s.db.fetchrow('SELECT 1 FROM clan_items WHERE clan_id=$1', cid)
    print('OK  исключение, передача власти, выход, роспуск с подтверждением и возвратом казны')

    # ===== войны =====
    await users(s, 11, 12, 13, 21, 31, 32, 41, 51, 52, rub=0)
    A = await mk_clan(s, 'Альфа', 11, (12, 13), bank=100_000, items={'sword': 100})
    B = await mk_clan(s, 'Бета', 21, (), bank=100_000, items={'shield': 20})
    now = accounts.now()
    assert 'Вы - ' not in (await s.last(11, '/война')).text
    m = await s.last(11, '/клан война')
    assert 'Противники | стр. 1/1' in m.text and 'Бета' in m.text and m.find('Бета')
    m = await s.press(11, 'Бета')                                  # карточка противника
    assert 'Клан «Бета»' in m.text and 'можно отбить до 10 000 ₽' in m.text and 'у вас есть преимущество' in m.text and m.find('Напасть')
    clans.RNG = Fixed(1.0, 1.0)
    ev = await s.say(11, '/клан война')                              # победа нападающего через кнопки
    m = ev[-1]; m = await s.press(11, 'Бета', msg=m); events_before = len(s.vk.events)
    await s.press(11, 'Напасть', msg=m)
    assert 'Война кланов' in m.text and '«Альфа» напал на «Бета»' in m.text and 'Победа клана «Альфа»' in m.text, m.text
    assert 'Добыча: 10 000 ₽' in m.text and 'Трофеи: «Альфа» +25, «Бета» −0' in m.text and 'Потери:' in m.text and 'щит мира на 4 ч' in m.text
    a = await s.db.fetchrow('SELECT * FROM clans WHERE id=$1', A); b = await s.db.fetchrow('SELECT * FROM clans WHERE id=$1', B)
    assert (a['bank'], a['trophies'], a['wins'], a['losses']) == (110_000, 25, 1, 0)
    assert (b['bank'], b['trophies'], b['wins'], b['losses']) == (90_000, 0, 0, 1)
    assert abs(b['shield_until'] - (now + 4 * H)) < 10 and a['shield_until'] == 0
    assert (await clans.stock(s.db, A))['sword'] == 97 and (await clans.stock(s.db, B))['shield'] == 18   # потери 3% и 10%
    war = await s.db.fetchrow('SELECT * FROM clan_wars')
    assert (war['attacker_id'], war['defender_id'], war['winner_id'], war['loot']) == (A, B, A, 10_000)
    dm = [e for e in s.vk.events[events_before:] if e.peer == 21]
    assert dm and 'На ваш клан «Бета» напал «Альфа»' in dm[0].text and 'Потеряно из казны: 10 000 ₽' in dm[0].text
    print('OK  война: победа нападающего - добыча 10%, трофеи, потери 3%/10%, щит защитнику, уведомление главе в личку')

    # ограничения
    assert 'под щитом мира' in (await s.last(11, '/война Бета')).text
    await s.db.execute('UPDATE clans SET shield_until=0 WHERE id=$1', B)
    assert 'отдыхают после боя' in (await s.last(11, '/война Бета')).text
    await s.db.execute('UPDATE clans SET last_war=$1 WHERE id=$2', now - 2 * H, A)
    assert 'недавно нападали' in (await s.last(11, '/война Бета')).text and 'через' in (await s.last(11, '/война Бета')).text
    assert 'только глава и офицеры' in (await s.last(12, '/война Бета')).text
    assert 'Нельзя напасть на свой клан' in (await s.last(11, '/война Альфа')).text
    assert 'не найден' in (await s.last(11, '/война Несуществующий')).text
    mk_solo = await mk_clan(s, 'Соло', 41, ())
    assert 'минимум 2 бойца' in (await s.last(41, '/война Бета')).text
    assert 'Для войны нужен клан' in (await s.last(1, '/война')).text, 'у игрока без клана войны нет'
    print('OK  ограничения войны: щит, отдых, повтор на тот же клан, роль, свой клан, неизвестный клан, мало бойцов')

    # победа защитника
    await s.db.execute('UPDATE clans SET shield_until=0 WHERE id=$1', B)
    C = await mk_clan(s, 'Гамма', 31, (32,), bank=50_000, items={'sword': 10})
    clans.RNG = Fixed(1.0, 1.0)
    m = await reply_to(s, 31, '/война Бета')
    assert 'Победа клана «Бета»' in m.text and 'Добыча: 2 500 ₽' in m.text and 'Трофеи: «Бета» +15, «Гамма» −0' in m.text, m.text
    b = await s.db.fetchrow('SELECT * FROM clans WHERE id=$1', B); c = await s.db.fetchrow('SELECT * FROM clans WHERE id=$1', C)
    assert (b['bank'], b['trophies'], b['wins']) == (92_500, 15, 1) and (c['bank'], c['trophies'], c['losses']) == (47_500, 0, 1)
    print('OK  война: победа защитника - 5% казны нападавшего, +15 трофеев')

    # исход боя зависит от случайного разброса 0.85-1.15 у обеих сторон
    T = await mk_clan(s, 'Тау', 91, (92,), bank=0, items={'sword': 12})       # атака 106 + 30% защиты 10 = 109
    U = await mk_clan(s, 'Ипсилон', 95, (), bank=0, items={'shield': 12})      # защита 101 + 30% атаки 5 = 102.5
    await users(s, 91, 92, 95, rub=0)
    async def duel(att_roll, def_roll):
        await s.db.execute('UPDATE clans SET last_war=0, shield_until=0 WHERE id IN ($1, $2)', T, U)
        await s.db.execute('DELETE FROM clan_wars WHERE attacker_id=$1', T)
        clans.RNG = Fixed(att_roll, def_roll)
        return await reply_to(s, 91, '/война Ипсилон')
    assert 'Победа клана «Тау»' in (await duel(1.0, 1.0)).text            # 109 против 102.5
    assert 'Победа клана «Ипсилон»' in (await duel(0.85, 1.15)).text      # 92.7 против 117.9
    assert 'Победа клана «Тау»' in (await duel(1.15, 0.85)).text          # 125.4 против 87.1
    print('OK  исход боя зависит от случайного разброса 0.85-1.15 (одни и те же клане побеждают и проигрывают)')

    # одновременные нападения: состоится ровно один бой
    D = await mk_clan(s, 'Дельта', 51, (52,), bank=1000, items={'sword': 500})
    E = await mk_clan(s, 'Эпсилон', 61, (), bank=1000)
    await users(s, 61, rub=0)
    clans.RNG = Fixed(1.0, 1.0, 1.0, 1.0, 1.0, 1.0)
    await asyncio.gather(*[s.say(51, '/война Эпсилон') for _ in range(3)])
    assert await s.db.fetchval('SELECT COUNT(*) FROM clan_wars WHERE attacker_id=$1', D) == 1
    print('OK  быстрые повторные нападения: бой состоялся один раз')

    # ===== рейтинг кланов =====
    m = await s.last(1, '/top клан')
    assert 'Топ кланов' in m.text and '«Альфа»' in m.text and '🏆' in m.text
    first_line = m.text.split('\n')[2]
    top_name = await s.db.fetchval('SELECT name FROM clans ORDER BY trophies DESC, wins DESC, id LIMIT 1')
    assert top_name in first_line, (first_line, top_name)
    print('OK  /top клан: рейтинг по трофеям')

    # ===== кланы в беседе отдельные =====
    await s.make_chat(CHAT, creator=10, members=(71, 72))
    await users(s, 71, 72, rub=100_000, scope=CHAT)
    m = await s.last(71, '/клан создать Альфа', peer=CHAT)
    assert 'Клан «Альфа» создан' in m.text, 'то же название в другой беседе допустимо'
    ev = await s.say(71, '/клан пригласить', peer=CHAT, reply_from=72)
    inv = ev[-1]
    await s.press(72, 'Принять', peer=CHAT, msg=inv)
    assert await s.db.fetchval('SELECT COUNT(*) FROM clan_members WHERE scope=$1', CHAT) == 2
    assert not await s.db.fetchrow('SELECT 1 FROM clan_members WHERE scope=0 AND user_id=71')
    # война в беседе: другого клана нет
    m = await s.last(71, '/клан война', peer=CHAT)
    assert 'Других кланов пока нет' in m.text
    # второй клан и бой в беседе - без личных уведомлений
    await users(s, 81, 82, rub=0, scope=CHAT)
    G = await mk_clan(s, 'Сигма', 81, (82,), bank=1000, scope=CHAT)
    await s.db.execute("INSERT INTO clan_items (clan_id, item_key, qty) SELECT id, 'sword', 50 FROM clans WHERE scope=$1 AND name='Альфа'", CHAT)
    clans.RNG = Fixed(1.0, 1.0)
    ev = await s.say(71, '/война Сигма', peer=CHAT)
    assert ev and ev[-1].peer == CHAT and 'Война кланов' in ev[-1].text
    assert not any(e.peer == 81 for e in ev), 'в беседе результат виден всем, личное уведомление не нужно'
    print('OK  кланы в беседе отдельные от личных; приглашение ответом; бой в беседе')

    # ===== обнуление аккаунта / экономики убирает из клана =====
    await s.set_role(OWNER, 8)
    m = await s.last(OWNER, '/обнулить @52'); await s.press(OWNER, 'Да, обнулить', msg=m)
    assert not await s.db.fetchrow('SELECT 1 FROM clan_members WHERE user_id=52'), 'боец убран из клана'
    m = await s.last(OWNER, '/обнулить @51'); await s.press(OWNER, 'Да, обнулить', msg=m)
    assert not await s.db.fetchrow('SELECT 1 FROM clans WHERE id=$1', D), 'клан обнулённого главы распускается'
    print('OK  /обнулить убирает игрока из клана, а клан главы распускает')

    clans.RNG = __import__('random').Random()
    print('\nВсе тесты clans пройдены')

asyncio.run(main())
