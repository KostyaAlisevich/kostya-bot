"""Статическая проверка requirements.txt: известные пересечения требований, которые ломают pip install."""
import re
from pathlib import Path

lines = [l.strip() for l in (Path(__file__).resolve().parents[1] / 'requirements.txt').read_text(encoding='utf-8').splitlines()]
pins = {}
for line in lines:
    if not line or line.startswith('#'):
        continue
    m = re.fullmatch(r'([A-Za-z0-9_.\-]+)==([0-9][^\s;]*)', line)
    assert m, f'ожидается формат пакет==версия: {line!r}'
    pins[m.group(1).lower().replace('_', '-')] = m.group(2)


def ver(v):
    return tuple(int(x) for x in re.findall(r'\d+', v)[:3])


assert 'asyncpg' in pins and 'vkbottle' in pins and 'async-timeout' in pins
# требования из логов pip (Python 3.10): asyncpg -> async-timeout>=4.0.3; aiohttp 3.11.x -> async-timeout>=4.0,<6.0
assert ver(pins['async-timeout']) >= (4, 0, 3), 'asyncpg требует async-timeout>=4.0.3'
assert (4, 0) <= ver(pins['async-timeout']) < (6, 0), 'aiohttp требует async-timeout от 4.0 до 6.0'
# все пакеты закреплены ровно один раз
assert len(pins) == len([l for l in lines if l and not l.startswith('#')])
print(f'OK  requirements.txt: {len(pins)} пакетов, известные конфликты (async-timeout <-> asyncpg/aiohttp) исключены')
