import asyncio
from sim import Sim, OWNER, CHAT_BASE
from app.services import accounts


async def main():
    s = await Sim.create()
    await s.say(1, '/start')

    # ===== банк =====
    m = await s.last(1, '/банк')
    assert 'На руках: 5 000 ₽' in m.text and 'Кредитов нет' in m.text and 'рейтинг: 600' in m.text and 'Лимит нового кредита: 60 000 ₽' in m.text
    print('OK  /банк')

    # ===== вклад =====
    m = await s.press(1, 'Вклад')
    assert 'На вкладе: 0 ₽' in m.text
    m = await s.press(1, '➕ 50%')
    assert 'Внесено на вклад: 2 500 ₽' in m.text
    w = await s.wallet(1)
    assert (w['rub'], w['deposit']) == (2500, 2500)
    m = await s.last(1, '/вклад положить 1000')
    assert (await s.wallet(1))['deposit'] == 3500
    m = await s.last(1, '/вклад 500')                  # без слова - тоже пополнение
    assert (await s.wallet(1))['deposit'] == 4000
    assert 'Недостаточно средств' in (await s.last(1, '/вклад положить 99999')).text
    print('OK  вклад: кнопки, команда, пополнение без слова «положить», нехватка денег')

    # проценты: 1% в сутки
    await s.db.execute('UPDATE wallets SET deposit_ts=$1 WHERE scope=0 AND user_id=1', accounts.now() - 2 * 86400)
    m = await s.last(1, '/вклад')
    w = await s.wallet(1)
    assert w['deposit'] == 4000 + int(4000 * 0.01 * 2), w['deposit']
    print('OK  проценты по вкладу за 2 суток:', w['deposit'])

    # снятие
    m = await s.last(1, '/вклад снять 1000')
    w = await s.wallet(1)
    assert 'Снято с вклада: 1 000 ₽' in m.text and w['deposit'] == 4080 - 1000
    assert 'только' in (await s.last(1, '/вклад снять 999999')).text
    m = await s.press(1, '➖ Всё')
    w = await s.wallet(1)
    assert w['deposit'] == 0 and w['rub'] == 2500 - 1000 - 500 + 4080, dict(w)   # всё вернулось на руки
    print('OK  снятие с вклада, лимиты')

    # лимит вклада
    await s.db.execute('UPDATE wallets SET rub=9000000, deposit=4900000, deposit_ts=$1 WHERE scope=0 AND user_id=1', accounts.now())
    m = await s.last(1, '/вклад положить все')
    assert (await s.wallet(1))['deposit'] == 5_000_000
    assert 'лимит вклада' in (await s.last(1, '/вклад положить 1000')).text
    print('OK  потолок вклада 5 000 000 ₽')

    # ===== кредит =====
    await s.say(2, '/start')
    m = await s.last(2, '/кредит')
    assert 'Доступно: от 1 000 ₽ до 60 000 ₽' in m.text and m.find('Взять 60 000 ₽')
    m = await s.press(2, 'Взять 60 000 ₽')
    w = await s.wallet(2)
    assert w['rub'] == 65000 and w['loan'] == 66000, dict(w)
    assert 'Кредит выдан' in m.text and 'Долг: 66 000 ₽' in m.text
    assert 'уже есть' in (await s.last(2, '/кредит взять 1000')).text
    print('OK  кредит: выдача с комиссией 10%, второй кредит запрещён')

    # погашение частями и полностью вовремя -> рейтинг +10
    m = await s.last(2, '/кредит погасить 6000')
    assert (await s.wallet(2))['loan'] == 60000
    m = await s.press(2, 'Погасить всё')                  # денег не хватает на весь долг - гасится то, что есть
    assert (await s.wallet(2))['loan'] == 1000 and (await s.wallet(2))['rub'] == 0
    await s.db.execute('UPDATE wallets SET rub=100000 WHERE scope=0 AND user_id=2')
    m = await s.last(2, '/кредит погасить все')
    w = await s.wallet(2)
    assert w['loan'] == 0 and w['credit_score'] == 610 and 'рейтинг повышен' in m.text, dict(w)
    assert 'нет кредитов' in (await s.last(2, '/кредит погасить 1')).text
    print('OK  погашение: частями, полностью вовремя - рейтинг +10')

    # нельзя взять больше лимита и меньше минимума
    assert 'Ваш лимит по кредиту: 62 000 ₽' in (await s.last(2, '/кредит взять 99999')).text
    assert 'Минимальный кредит' in (await s.last(2, '/кредит 500')).text
    assert 'Укажите сумму' in (await s.last(2, '/кредит взять abc')).text

    # просрочка: штраф 5% в сутки и минус к рейтингу
    await s.last(2, '/кредит взять 10000')
    w = await s.wallet(2); assert w['loan'] == 11000
    await s.db.execute('UPDATE wallets SET loan_due=$1 WHERE scope=0 AND user_id=2', accounts.now() - 2 * 86400 - 10)
    m = await s.last(2, '/банк')
    w = await s.wallet(2)
    expected = 11000; expected += expected * 5 // 100; expected += expected * 5 // 100
    assert w['loan'] == expected and w['credit_score'] == 610 - 30, dict(w)
    assert 'просрочен' in m.text
    # повторный вызов в тот же момент не начисляет штраф ещё раз
    await s.last(2, '/банк'); assert (await s.wallet(2))['loan'] == expected
    # погашение с просрочкой: рейтинг не растёт
    await s.db.execute('UPDATE wallets SET rub=100000 WHERE scope=0 AND user_id=2')
    m = await s.last(2, '/кредит погасить все')
    w = await s.wallet(2)
    assert w['loan'] == 0 and w['credit_score'] == 580 and 'с просрочкой' in m.text, dict(w)
    print('OK  просрочка: штраф 5%/сутки, рейтинг падает, повторный расчёт не удваивает штраф')

    # низкий рейтинг - нет кредитов
    await s.db.execute('UPDATE wallets SET credit_score=300 WHERE scope=0 AND user_id=2')
    m = await s.last(2, '/кредит')
    assert 'до 0 ₽' in m.text and not m.find('Взять')
    print('OK  при рейтинге 300 кредит недоступен')

    print('\nВсе тесты bank пройдены')

asyncio.run(main())
