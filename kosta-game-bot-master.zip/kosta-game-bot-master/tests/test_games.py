import asyncio
import json
import random
from sim import Sim, OWNER, CHAT_BASE
from app.modules import games
from app.services import accounts


class Scripted:
    """Подменный генератор случайных чисел с заранее заданными результатами."""
    def __init__(self, choices=(), ints=(), deck=None, slot_reels=None):
        self.choices_q, self.ints_q, self.deck, self.reels = list(choices), list(ints), deck, slot_reels

    def choice(self, seq):
        return self.choices_q.pop(0)

    def randint(self, a, b):
        return self.ints_q.pop(0)

    def choices(self, population, weights=None, k=1):
        return list(self.reels)

    def shuffle(self, lst):
        lst[:] = list(reversed(self.deck))       # deck - порядок раздачи (первая карта - первая в списке)


def card(rank, suit=0):
    return games.RANKS.index(rank) + 13 * suit


async def main():
    s = await Sim.create()
    await s.say(1, '/start')
    bal = lambda: s.wallet(1)

    # ===== меню и ставки =====
    m = await s.last(1, '/игры')
    assert len(m.buttons()) == 7 and 'Блэкджек' in m.text
    m = await s.press(1, 'Монетка')
    assert 'Выберите ставку' in m.text and m.find('1 000 ₽') and m.find('Всё')
    for cmd in ('монетка', 'кости', 'слоты', 'рулетка', 'кнб', 'блэкджек'):
        assert 'Выберите ставку' in (await s.last(1, f'/{cmd}')).text, cmd
    assert 'Минимальная ставка' in (await s.last(1, '/монетка 5')).text
    assert 'Максимальная ставка' in (await s.last(1, '/монетка 2000000')).text
    await s.give(1, rub=100)
    assert 'Недостаточно средств' in (await s.last(1, '/кости 500')).text
    assert (await bal())['rub'] == 100
    assert 'Минимальная ставка' in (await s.last(1, '/слоты abc')).text
    print('OK  меню игр, выбор ставки, лимиты ставок, нехватка денег')

    # ===== монетка =====
    await s.give(1, rub=10_000)
    games.RNG = Scripted(choices=['орёл'])
    m = await s.last(1, '/монетка 1000 орёл')
    assert '+950 ₽' in m.text and (await bal())['rub'] == 10_950           # ×1.95
    games.RNG = Scripted(choices=['орёл'])
    m = await s.last(1, '/монетка 1000 решка')
    assert 'Проигрыш: −1 000 ₽' in m.text and (await bal())['rub'] == 9_950
    m = await s.last(1, '/монетка 500')                                     # без стороны - кнопки
    assert m.find('Орёл') and m.find('Решка')
    games.RNG = Scripted(choices=['решка'])
    m = await s.press(1, 'Решка')
    assert 'Выигрыш' in m.text and (await bal())['rub'] == 9_950 + 475
    games.RNG = Scripted(choices=['орёл'])
    m = await s.press(1, 'Ещё раз')
    assert 'Проигрыш' in m.text, 'кнопка «Ещё раз» повторяет ту же ставку и сторону'
    await s.give(1, rub=777)
    games.RNG = Scripted(choices=['орёл'])
    m = await s.last(1, '/монетка все орел')
    assert (await bal())['rub'] == 777 * 195 // 100, 'ставка «все» - весь баланс'
    print('OK  монетка: выигрыш ×1.95, проигрыш, выбор стороны кнопкой, «Ещё раз»')

    # ===== кости =====
    await s.give(1, rub=10_000)
    games.RNG = Scripted(ints=[6, 5, 2, 3])
    m = await s.last(1, '/кости 1000'); assert '+950 ₽' in m.text and '⚅ ⚄ = 11' in m.text and '⚁ ⚂ = 5' in m.text
    games.RNG = Scripted(ints=[1, 1, 6, 6])
    m = await s.last(1, '/dice 1000'); assert 'Проигрыш' in m.text
    games.RNG = Scripted(ints=[3, 4, 2, 5])
    m = await s.last(1, '/кубики 1000'); assert 'Ставка возвращена' in m.text
    assert (await bal())['rub'] == 10_000 + 950 - 1000
    print('OK  кости: победа, поражение, ничья (возврат ставки)')

    # ===== слоты: выплаты и теоретический возврат =====
    await s.give(1, rub=10_000)
    games.RNG = Scripted(slot_reels=['💎', '💎', '💎'])
    m = await s.last(1, '/слоты 100'); assert 'ДЖЕКПОТ' in m.text and '+49 900 ₽' in m.text
    games.RNG = Scripted(slot_reels=['🍒', '🍒', '🔔'])
    m = await s.last(1, '/казино 100'); assert 'возврат 70%' in m.text and 'Проигрыш: −30 ₽' in m.text
    games.RNG = Scripted(slot_reels=['🍒', '🍋', '🔔'])
    m = await s.last(1, '/slots 100'); assert 'Совпадений нет' in m.text
    total = 0.0
    symbols = [(sy, w / 100) for sy, w, _ in games.SLOT_SYMBOLS]
    for a, pa in symbols:
        for b, pb in symbols:
            for c, pc in symbols:
                total += pa * pb * pc * games.slot_payout(1000, [a, b, c])[0] / 1000
    assert 0.90 <= total <= 0.97, total
    print(f'OK  слоты: джекпот, пара, пусто; теоретический возврат (RTP) = {total:.3f}')

    # ===== рулетка =====
    await s.give(1, rub=100_000)
    games.RNG = Scripted(ints=[17])        # 17 - чёрное, нечётное
    m = await s.last(1, '/рулетка 100 чёрное'); assert 'Выпало: ⚫ 17' in m.text and '+100 ₽' in m.text
    games.RNG = Scripted(ints=[17]); m = await s.last(1, '/рулетка 100 красное'); assert 'Проигрыш' in m.text
    games.RNG = Scripted(ints=[17]); m = await s.last(1, '/рулетка 100 нечёт'); assert '+100 ₽' in m.text
    games.RNG = Scripted(ints=[17]); m = await s.last(1, '/рулетка 100 чет'); assert 'Проигрыш' in m.text
    games.RNG = Scripted(ints=[17]); m = await s.last(1, '/рулетка 100 17'); assert '+3 500 ₽' in m.text       # ×36
    games.RNG = Scripted(ints=[0]); m = await s.last(1, '/рулетка 100 зеро'); assert 'Выпало: 🟢 0' in m.text and '+3 500 ₽' in m.text
    games.RNG = Scripted(ints=[0]); m = await s.last(1, '/рулетка 100 красное'); assert 'Проигрыш' in m.text, 'на зеро цвета проигрывают'
    m = await s.last(1, '/рулетка 100')
    assert m.find('Красное') and m.find('Зеро') and len(m.buttons()) == 6
    games.RNG = Scripted(ints=[1]); m = await s.press(1, 'Красное'); assert 'Выигрыш' in m.text
    for choice in ('красное', 'чёрное', 'чёт', 'нечёт', 'зеро', '17'):
        ev = sum(games.roulette_outcome(choice, n, 3700) for n in range(37)) / 37 / 3700
        assert abs(ev - 36 / 37) < 0.001, (choice, ev)
    print('OK  рулетка: цвета, чёт/нечёт, число ×36, зеро, кнопки; возврат 97,3% для всех ставок')

    # ===== камень-ножницы-бумага =====
    await s.give(1, rub=100_000)
    outcomes = {('камень', 'ножницы'): 'Вы победили', ('камень', 'бумага'): 'Бот победил', ('камень', 'камень'): 'Ничья',
                ('ножницы', 'бумага'): 'Вы победили', ('бумага', 'камень'): 'Вы победили', ('бумага', 'ножницы'): 'Бот победил'}
    for (mine, theirs), word in outcomes.items():
        games.RNG = Scripted(choices=[theirs])
        m = await s.last(1, f'/кнб 1000 {mine}')
        assert word in m.text, (mine, theirs, m.text)
    games.RNG = Scripted(choices=['ножницы'])
    b0 = (await bal())['rub']; m = await s.last(1, '/rps 1000 к'); assert (await bal())['rub'] == b0 + 900       # ×1.9
    m = await s.last(1, '/кнб 1000')
    assert m.find('Камень') and m.find('Ножницы') and m.find('Бумага')
    print('OK  КНБ: все исходы, выплата ×1.9, выбор кнопками')

    # ===== блэкджек =====
    await s.give(1, rub=100_000)
    A, K, Q, J, T = card('A'), card('K'), card('Q'), card('J'), card('10')

    # блэкджек с раздачи: порядок раздачи: игрок, игрок, дилер, дилер
    games.RNG = Scripted(deck=[A, K, card('7'), card('9')])
    b0 = (await bal())['rub']
    m = await s.last(1, '/блэкджек 1000')
    assert 'Блэкджек! Выплата 3:2' in m.text and (await bal())['rub'] == b0 + 1500, m.text
    assert not await s.db.fetchrow("SELECT 1 FROM game_sessions WHERE user_id=1")
    print('OK  блэкджек с раздачи платит 3:2')

    # взять карту, затем остановиться; дилер добирает до 17
    games.RNG = Scripted(deck=[card('5'), card('6'), card('10'), card('6'), card('9'), card('5'), card('2')])
    # игрок 5+6=11, дилер 10+6=16; игрок берёт 9 -> 20; хватит; дилер берёт 5 -> 21?! 10+6+5=21 -> игрок проигрывает
    m = await s.last(1, '/блэкджек 1000')
    assert 'Дилер: 10♠ 🂠' in m.text or 'Дилер: 10♠' in m.text, m.text
    assert m.find('Взять') and m.find('Хватит') and m.find('Удвоить')
    assert await s.db.fetchrow("SELECT 1 FROM game_sessions WHERE user_id=1"), 'партия сохраняется в базе'
    b_start = (await bal())['rub']
    m = await s.press(1, 'Взять')
    assert 'Вы: 5♠ 6♠ 9♠ = 20' in m.text and not m.find('Удвоить')
    # «/блэкджек» без аргументов продолжает партию
    m2 = await s.last(1, '/блэкджек')
    assert 'незавершённая партия' in m2.text
    m = await s.press(1, 'Хватит')
    assert 'Дилер: 10♠ 6♠ 5♠ = 21' in m.text and 'Проигрыш' in m.text, m.text
    assert (await bal())['rub'] == b_start and not await s.db.fetchrow("SELECT 1 FROM game_sessions WHERE user_id=1")
    print('OK  блэкджек: взять, продолжить партию командой, дилер добирает, расчёт')

    # перебор
    games.RNG = Scripted(deck=[card('10'), card('6'), card('9'), card('8'), card('K')])
    await s.last(1, '/блэкджек 1000')
    m = await s.press(1, 'Взять')
    assert 'Перебор' in m.text and 'Проигрыш: −1 000 ₽' in m.text
    print('OK  перебор')

    # победа, ничья
    games.RNG = Scripted(deck=[K, card('9'), card('10'), card('7')])
    await s.last(1, '/блэкджек 1000'); b0 = (await bal())['rub']
    m = await s.press(1, 'Хватит'); assert 'Вы победили' in m.text and (await bal())['rub'] == b0 + 2000
    games.RNG = Scripted(deck=[K, card('8'), card('10'), card('8')])
    await s.last(1, '/блэкджек 1000'); b0 = (await bal())['rub']
    m = await s.press(1, 'Хватит'); assert 'Ничья' in m.text and (await bal())['rub'] == b0 + 1000
    print('OK  победа ×2, ничья - возврат ставки')

    # удвоение
    games.RNG = Scripted(deck=[card('5'), card('6'), card('10'), card('7'), card('10')])
    await s.last(1, '/блэкджек 1000'); b0 = (await bal())['rub']
    m = await s.press(1, 'Удвоить')
    assert 'Вы: 5♠ 6♠ 10♠ = 21' in m.text and 'Выигрыш: +2 000 ₽' in m.text, m.text
    assert (await bal())['rub'] == b0 - 1000 + 4000, 'ставка удвоена: списано ещё 1000, выплата 2×2000'
    # на втором ходу удвоить нельзя
    games.RNG = Scripted(deck=[card('2'), card('3'), card('10'), card('7'), card('4'), card('3'), card('2'), card('5'), card('6')])
    await s.last(1, '/блэкджек 1000'); await s.press(1, 'Взять')
    assert 'Удвоить' not in ' '.join(s.latest_msg_with(1, 'Хватит').labels())
    await s.last(1, '/блэкджек hit') ; await s.last(1, '/блэкджек stand')
    # нехватка денег на удвоение
    await s.give(1, rub=1000)
    games.RNG = Scripted(deck=[card('5'), card('6'), card('10'), card('7'), card('10')])
    await s.last(1, '/блэкджек 1000')
    assert (await bal())['rub'] == 0
    m = await s.press(1, 'Удвоить'); assert 'Недостаточно средств для удвоения' in m.text
    m = await s.press(1, 'Хватит')
    print('OK  удвоение: ставка ×2, только на первой раздаче, нужны деньги')

    # устаревшая партия засчитывается автоматически
    await s.give(1, rub=10_000)
    games.RNG = Scripted(deck=[K, Q, card('10'), card('8')])
    await s.last(1, '/блэкджек 1000'); b0 = (await bal())['rub']
    await s.db.execute("UPDATE game_sessions SET ts=$1 WHERE user_id=1", accounts.now() - 7200)
    m = await s.last(1, '/блэкджек')
    assert 'Вы победили' in m.text and (await bal())['rub'] == b0 + 2000
    # без партии кнопки старой партии не ломают бота
    m = await s.last(1, '/блэкджек hit'); assert 'уже завершена' in m.text
    # в беседе - своя партия
    CH = CHAT_BASE + 3
    await s.make_chat(CH, creator=10, members=(1,)); await s.give(1, rub=5000, scope=CH)
    games.RNG = Scripted(deck=[card('5'), card('6'), card('10'), card('7')])
    await s.last(1, '/блэкджек 500', peer=CH)
    assert await s.db.fetchrow("SELECT 1 FROM game_sessions WHERE scope=$1 AND user_id=1", CH)
    assert not await s.db.fetchrow("SELECT 1 FROM game_sessions WHERE scope=0 AND user_id=1")
    print('OK  брошенная партия засчитывается через час; партии в беседе отдельные')

    games.RNG = random.Random(1)
    print('\nВсе тесты games пройдены')

asyncio.run(main())
