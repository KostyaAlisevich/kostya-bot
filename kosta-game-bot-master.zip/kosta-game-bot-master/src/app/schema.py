"""Схема базы данных. Каждый элемент SCHEMA - один SQL-запрос (CREATE ... IF NOT EXISTS).

Соглашения: время - секунды Unix (BIGINT), флаги - SMALLINT 0/1, деньги - целые числа
(рубли; доллары и евро - в центах). scope = 0 для личных сообщений сообщества,
иначе peer_id беседы: у каждой беседы своя отдельная экономика.
"""

SCHEMA: list[str] = [
    # ---------------- Пользователи и беседы ----------------
    """CREATE TABLE IF NOT EXISTS users (
        id          BIGINT PRIMARY KEY,
        name        TEXT NOT NULL DEFAULT '',
        role        INT NOT NULL DEFAULT 0,
        banned      SMALLINT NOT NULL DEFAULT 0,
        ban_reason  TEXT NOT NULL DEFAULT '',
        dm_ok       SMALLINT NOT NULL DEFAULT 0,
        kb_cleared  SMALLINT NOT NULL DEFAULT 0,
        created_at  BIGINT NOT NULL DEFAULT 0,
        last_seen   BIGINT NOT NULL DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS chats (
        peer_id      BIGINT PRIMARY KEY,
        title        TEXT NOT NULL DEFAULT '',
        activated    SMALLINT NOT NULL DEFAULT 0,
        activated_by BIGINT NOT NULL DEFAULT 0,
        rules        TEXT NOT NULL DEFAULT '',
        greeting     TEXT NOT NULL DEFAULT '',
        treasury     BIGINT NOT NULL DEFAULT 0,
        tax          INT NOT NULL DEFAULT 0,
        warn_limit   INT NOT NULL DEFAULT 3,
        created_at   BIGINT NOT NULL DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS chat_members (
        peer_id     BIGINT NOT NULL,
        user_id     BIGINT NOT NULL,
        role        INT NOT NULL DEFAULT 0,
        warns       INT NOT NULL DEFAULT 0,
        muted_until BIGINT NOT NULL DEFAULT 0,
        banned      SMALLINT NOT NULL DEFAULT 0,
        msgs        BIGINT NOT NULL DEFAULT 0,
        last_msg    BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (peer_id, user_id)
    )""",
    """CREATE TABLE IF NOT EXISTS chat_roles (
        peer_id BIGINT NOT NULL,
        level   INT NOT NULL,
        name    TEXT NOT NULL,
        PRIMARY KEY (peer_id, level)
    )""",

    # ---------------- Экономика (отдельная для каждого scope) ----------------
    """CREATE TABLE IF NOT EXISTS wallets (
        scope        BIGINT NOT NULL,
        user_id      BIGINT NOT NULL,
        rub          BIGINT NOT NULL DEFAULT 0,
        usd          BIGINT NOT NULL DEFAULT 0,
        eur          BIGINT NOT NULL DEFAULT 0,
        deposit      BIGINT NOT NULL DEFAULT 0,
        deposit_ts   BIGINT NOT NULL DEFAULT 0,
        loan         BIGINT NOT NULL DEFAULT 0,
        loan_due     BIGINT NOT NULL DEFAULT 0,
        loan_pen_ts  BIGINT NOT NULL DEFAULT 0,
        credit_score INT NOT NULL DEFAULT 600,
        job          TEXT NOT NULL DEFAULT '',
        work_next    BIGINT NOT NULL DEFAULT 0,
        shifts       INT NOT NULL DEFAULT 0,
        created_at   BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (scope, user_id)
    )""",
    """CREATE TABLE IF NOT EXISTS transactions (
        id       BIGSERIAL PRIMARY KEY,
        scope    BIGINT NOT NULL,
        user_id  BIGINT NOT NULL,
        kind     TEXT NOT NULL DEFAULT '',
        currency TEXT NOT NULL DEFAULT 'rub',
        amount   BIGINT NOT NULL,
        balance  BIGINT NOT NULL DEFAULT 0,
        note     TEXT NOT NULL DEFAULT '',
        ts       BIGINT NOT NULL
    )""",
    "CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions (scope, user_id, id)",
    """CREATE TABLE IF NOT EXISTS edu_progress (
        scope       BIGINT NOT NULL,
        user_id     BIGINT NOT NULL,
        edu_key     TEXT NOT NULL,
        lessons     INT NOT NULL DEFAULT 0,
        next_at     BIGINT NOT NULL DEFAULT 0,
        done        SMALLINT NOT NULL DEFAULT 0,
        finished_at BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (scope, user_id, edu_key)
    )""",
    """CREATE TABLE IF NOT EXISTS owned_assets (
        scope        BIGINT NOT NULL,
        user_id      BIGINT NOT NULL,
        item_key     TEXT NOT NULL,
        bought_at    BIGINT NOT NULL,
        collected_at BIGINT NOT NULL,
        PRIMARY KEY (scope, user_id, item_key)
    )""",
    """CREATE TABLE IF NOT EXISTS holdings (
        scope    BIGINT NOT NULL,
        user_id  BIGINT NOT NULL,
        symbol   TEXT NOT NULL,
        qty      DOUBLE PRECISION NOT NULL DEFAULT 0,
        invested BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (scope, user_id, symbol)
    )""",
    """CREATE TABLE IF NOT EXISTS families (
        id         BIGSERIAL PRIMARY KEY,
        scope      BIGINT NOT NULL,
        name       TEXT NOT NULL,
        owner_id   BIGINT NOT NULL,
        budget     BIGINT NOT NULL DEFAULT 0,
        created_at BIGINT NOT NULL DEFAULT 0
    )""",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_families_name ON families (scope, name)",
    """CREATE TABLE IF NOT EXISTS family_members (
        scope     BIGINT NOT NULL,
        user_id   BIGINT NOT NULL,
        family_id BIGINT NOT NULL,
        PRIMARY KEY (scope, user_id)
    )""",
    """CREATE TABLE IF NOT EXISTS family_invites (
        scope     BIGINT NOT NULL,
        user_id   BIGINT NOT NULL,
        family_id BIGINT NOT NULL,
        ts        BIGINT NOT NULL,
        PRIMARY KEY (scope, user_id)
    )""",
    """CREATE TABLE IF NOT EXISTS game_sessions (
        scope   BIGINT NOT NULL,
        user_id BIGINT NOT NULL,
        game    TEXT NOT NULL,
        data    TEXT NOT NULL DEFAULT '',
        bet     BIGINT NOT NULL DEFAULT 0,
        ts      BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (scope, user_id, game)
    )""",

    # ---------------- Рынок (общий для всех scope) ----------------
    """CREATE TABLE IF NOT EXISTS market_prices (
        symbol  TEXT PRIMARY KEY,
        kind    TEXT NOT NULL,
        price   DOUBLE PRECISION NOT NULL,
        base    DOUBLE PRECISION NOT NULL,
        updated BIGINT NOT NULL DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS market_history (
        id     BIGSERIAL PRIMARY KEY,
        symbol TEXT NOT NULL,
        ts     BIGINT NOT NULL,
        price  DOUBLE PRECISION NOT NULL
    )""",
    "CREATE INDEX IF NOT EXISTS idx_market_history ON market_history (symbol, ts)",
    """CREATE TABLE IF NOT EXISTS market_news (
        id     BIGSERIAL PRIMARY KEY,
        ts     BIGINT NOT NULL,
        symbol TEXT NOT NULL DEFAULT '',
        pct    DOUBLE PRECISION NOT NULL DEFAULT 0,
        text   TEXT NOT NULL
    )""",

    # ---------------- Промокоды и поддержка ----------------
    """CREATE TABLE IF NOT EXISTS promo_codes (
        code       TEXT PRIMARY KEY,
        amount     BIGINT NOT NULL,
        max_uses   INT NOT NULL DEFAULT 0,
        uses       INT NOT NULL DEFAULT 0,
        expires_at BIGINT NOT NULL DEFAULT 0,
        created_by BIGINT NOT NULL DEFAULT 0,
        created_at BIGINT NOT NULL DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS promo_uses (
        code    TEXT NOT NULL,
        user_id BIGINT NOT NULL,
        scope   BIGINT NOT NULL DEFAULT 0,
        ts      BIGINT NOT NULL DEFAULT 0,
        PRIMARY KEY (code, user_id)
    )""",
    """CREATE TABLE IF NOT EXISTS tickets (
        id         BIGSERIAL PRIMARY KEY,
        user_id    BIGINT NOT NULL,
        peer_id    BIGINT NOT NULL DEFAULT 0,
        text       TEXT NOT NULL,
        status     TEXT NOT NULL DEFAULT 'open',
        created_at BIGINT NOT NULL DEFAULT 0,
        closed_by  BIGINT NOT NULL DEFAULT 0,
        closed_at  BIGINT NOT NULL DEFAULT 0
    )""",
    "CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets (status, id)",
    """CREATE TABLE IF NOT EXISTS ticket_replies (
        id        BIGSERIAL PRIMARY KEY,
        ticket_id BIGINT NOT NULL,
        staff_id  BIGINT NOT NULL,
        text      TEXT NOT NULL,
        ts        BIGINT NOT NULL DEFAULT 0
    )""",
]
