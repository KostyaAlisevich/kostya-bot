"""Тонкий слой над VK API. Всё общение с ВК идёт только через него:
остальной код не зависит от vkbottle, поэтому его можно проверять на заглушке."""
import json
import logging

from .config import CHAT_BASE

try:
    from vkbottle import VKAPIError
except ImportError:  # pragma: no cover - в тестах vkbottle может отсутствовать
    class VKAPIError(Exception):
        pass

log = logging.getLogger('bot.vk')

# Пустая «нижняя» клавиатура: убирает старые кнопки внизу экрана
EMPTY_REPLY_KEYBOARD = json.dumps({'buttons': [], 'one_time': True})


class VK:
    def __init__(self, api, group_id: int = 0):
        self.api = api
        self._group_id = group_id

    async def send(self, peer_id: int, text: str, keyboard: str | None = None) -> bool:
        params = dict(peer_id=peer_id, message=text[:4000], random_id=0, disable_mentions=True)
        if keyboard:
            params['keyboard'] = keyboard
        try:
            await self.api.messages.send(**params)
            return True
        except Exception as e:  # noqa: BLE001
            log.warning('send to %s failed: %s', peer_id, e)
            return False

    async def clear_reply_keyboard(self, peer_id: int, text: str) -> bool:
        """Отправляет сообщение, которое убирает старую клавиатуру внизу экрана."""
        try:
            await self.api.messages.send(
                peer_id=peer_id, message=text, random_id=0, keyboard=EMPTY_REPLY_KEYBOARD,
                disable_mentions=True,
            )
            return True
        except Exception as e:  # noqa: BLE001
            log.warning('clear keyboard for %s failed: %s', peer_id, e)
            return False

    async def edit(self, peer_id: int, cmid: int, text: str, keyboard: str | None = None) -> bool:
        params = dict(peer_id=peer_id, conversation_message_id=cmid, message=text[:4000], disable_mentions=True)
        if keyboard:
            params['keyboard'] = keyboard
        try:
            await self.api.messages.edit(**params)
            return True
        except Exception as e:  # noqa: BLE001
            reason = str(e).lower()
            if 'not' in reason and ('chang' in reason or 'modif' in reason):
                return True  # содержимое не изменилось - это не ошибка
            log.warning('edit %s/%s failed: %s', peer_id, cmid, e)
            return False

    async def event_answer(self, event_id: str, user_id: int, peer_id: int, text: str | None = None) -> None:
        params = dict(event_id=event_id, user_id=user_id, peer_id=peer_id)
        if text:
            params['event_data'] = json.dumps({'type': 'show_snackbar', 'text': text[:90]}, ensure_ascii=False)
        try:
            await self.api.messages.send_message_event_answer(**params)
        except Exception as e:  # noqa: BLE001
            log.warning('event answer failed: %s', e)

    async def delete(self, peer_id: int, cmid: int) -> bool:
        try:
            await self.api.messages.delete(peer_id=peer_id, cmids=[cmid], delete_for_all=True)
            return True
        except Exception as e:  # noqa: BLE001
            log.warning('delete %s/%s failed: %s', peer_id, cmid, e)
            return False

    async def kick(self, peer_id: int, user_id: int) -> bool:
        try:
            await self.api.messages.remove_chat_user(chat_id=peer_id - CHAT_BASE, member_id=user_id)
            return True
        except Exception as e:  # noqa: BLE001
            log.warning('kick %s from %s failed: %s', user_id, peer_id, e)
            return False

    async def members(self, peer_id: int) -> list[dict]:
        """Участники беседы: [{'id', 'admin', 'owner'}]. Если у бота нет доступа - VKAPIError."""
        try:
            res = await self.api.messages.get_conversation_members(peer_id=peer_id)
            return [
                {'id': m.member_id, 'admin': bool(m.is_admin), 'owner': bool(m.is_owner)}
                for m in res.items
            ]
        except VKAPIError:
            raise
        except Exception as e:  # noqa: BLE001
            log.exception('get_conversation_members failed')
            raise VKAPIError(str(e)) from e

    async def names(self, ids: list[int]) -> dict[int, str]:
        ids = [i for i in ids if i > 0]
        if not ids:
            return {}
        try:
            users = await self.api.users.get(user_ids=ids[:1000])
        except Exception as e:  # noqa: BLE001
            log.warning('users.get failed: %s', e)
            return {}
        return {u.id: f'{u.first_name} {u.last_name}'.strip() for u in users}

    async def resolve(self, screen_name: str) -> int | None:
        try:
            users = await self.api.users.get(user_ids=[screen_name])
        except Exception:  # noqa: BLE001 - имя не найдено или API недоступно
            return None
        return users[0].id if users else None

    async def group_id(self) -> int:
        if not self._group_id:
            try:
                res = await self.api.groups.get_by_id()
                groups = getattr(res, 'groups', res)
                first = groups[0] if isinstance(groups, (list, tuple)) else groups
                self._group_id = int(first.id)
            except Exception as e:  # noqa: BLE001
                log.warning('cannot detect group id: %s', e)
        return self._group_id
