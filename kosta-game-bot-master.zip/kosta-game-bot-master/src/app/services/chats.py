"""Беседы: настройки, участники, роли."""
from ..roles import DEFAULT_CHAT_ROLES
from .accounts import now


async def get_chat(db, peer_id: int):
    await db.execute(
        'INSERT INTO chats (peer_id, created_at) VALUES ($1, $2) ON CONFLICT (peer_id) DO NOTHING',
        peer_id, now(),
    )
    return await db.fetchrow('SELECT * FROM chats WHERE peer_id=$1', peer_id)


async def get_member(db, peer_id: int, uid: int):
    await db.execute(
        'INSERT INTO chat_members (peer_id, user_id) VALUES ($1, $2) ON CONFLICT (peer_id, user_id) DO NOTHING',
        peer_id, uid,
    )
    return await db.fetchrow('SELECT * FROM chat_members WHERE peer_id=$1 AND user_id=$2', peer_id, uid)


async def member_level(db, peer_id: int, uid: int) -> int:
    row = await db.fetchrow('SELECT role FROM chat_members WHERE peer_id=$1 AND user_id=$2', peer_id, uid)
    return row['role'] if row else 0


async def set_member_role(db, peer_id: int, uid: int, level: int) -> None:
    await get_member(db, peer_id, uid)
    await db.execute('UPDATE chat_members SET role=$3 WHERE peer_id=$1 AND user_id=$2', peer_id, uid, level)


async def custom_roles(db, peer_id: int) -> dict[int, str]:
    rows = await db.fetch('SELECT level, name FROM chat_roles WHERE peer_id=$1', peer_id)
    return {r['level']: r['name'] for r in rows}


async def role_name(db, peer_id: int, level: int) -> str:
    custom = await custom_roles(db, peer_id)
    names = {**DEFAULT_CHAT_ROLES, **custom}
    if level in names:
        return names[level]
    if level <= 0:
        return 'Участник'
    # ближайшая нижняя роль для нестандартных уровней
    lower = [lv for lv in names if lv <= level]
    return f'{names[max(lower)]}+' if lower else f'Роль {level}'
