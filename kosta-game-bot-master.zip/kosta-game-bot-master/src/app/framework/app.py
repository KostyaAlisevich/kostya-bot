import time
from collections import defaultdict, deque

from .pending import PendingStore
from .registry import Registry


class RateLimiter:
    """Простая защита от флуда: не более limit действий за window секунд на пользователя."""

    def __init__(self, limit: int = 10, window: float = 6.0):
        self.limit, self.window = limit, window
        self._hits: dict[int, deque] = defaultdict(deque)

    def allow(self, uid: int) -> bool:
        now = time.monotonic()
        hits = self._hits[uid]
        while hits and now - hits[0] > self.window:
            hits.popleft()
        if len(hits) >= self.limit:
            return False
        hits.append(now)
        return True


class App:
    """Общий объект приложения: база, ВК, реестр команд и вспомогательные хранилища."""

    def __init__(self, db, vk, registry: Registry, admin_id: int = 0, limiter: RateLimiter | None = None):
        self.db = db
        self.vk = vk
        self.registry = registry
        self.admin_id = admin_id
        self.limiter = limiter
        self.pending = PendingStore()
        self.names: dict[int, str] = {}
        self.ban_notified: dict[int, float] = {}
        self.hint_notified: dict[int, float] = {}
        self.drafts: dict[int, tuple[str, float]] = {}   # черновики рассылок: {id отправителя: (текст, время)}
        self.tasks: set = set()                            # фоновые задачи (рассылки)
