"""Кланы: предметы клановой казны (нападение, защита, щиты мира) и параметры уровней."""
from dataclasses import dataclass


@dataclass(frozen=True)
class ClanItem:
    key: str
    emoji: str
    title: str
    price: int
    kind: str                 # 'attack' | 'defense' | 'shield'
    power: int = 0            # сколько очков атаки/защиты даёт одна штука
    shield_hours: int = 0     # для щитов мира: на сколько часов защищают от нападений
    description: str = ''


CLAN_ITEMS: tuple[ClanItem, ...] = (
    # --- нападение ---
    ClanItem('sword', '⚔', 'Мечи', 4_000, 'attack', 8, description='Надёжное оружие ближнего боя.'),
    ClanItem('bow', '🏹', 'Луки', 9_000, 'attack', 20, description='Бьют издалека, пока враг не подошёл.'),
    ClanItem('crossbow', '🎯', 'Арбалеты', 20_000, 'attack', 46, description='Пробивают любые доспехи.'),
    ClanItem('cannon', '💣', 'Пушки', 60_000, 'attack', 150, description='Разносят стены в щепки.'),
    ClanItem('dragon', '🐉', 'Боевые драконы', 250_000, 'attack', 700, description='Страх и ужас любого врага.'),
    # --- защита ---
    ClanItem('shield', '🛡', 'Щиты', 4_000, 'defense', 8, description='Закрывают бойцов от стрел.'),
    ClanItem('wall', '🧱', 'Стены', 12_000, 'defense', 28, description='Крепкая каменная кладка.'),
    ClanItem('tower', '🏰', 'Башни', 40_000, 'defense', 100, description='Лучники сверху, враги снизу.'),
    ClanItem('moat', '💧', 'Рвы с водой', 90_000, 'defense', 240, description='До стен ещё надо добраться.'),
    ClanItem('golem', '🗿', 'Каменные големы', 220_000, 'defense', 600, description='Живая стена, которую не пробить.'),
    # --- щиты мира: на время запрещают нападать на клан ---
    ClanItem('peace12', '🕊', 'Щит мира 12 часов', 30_000, 'shield', shield_hours=12,
             description='Никто не сможет напасть на клан 12 часов.'),
    ClanItem('peace24', '🔰', 'Щит мира 24 часа', 50_000, 'shield', shield_hours=24,
             description='Никто не сможет напасть на клан сутки.'),
)
CLAN_ITEMS_BY_KEY: dict[str, ClanItem] = {i.key: i for i in CLAN_ITEMS}

# --- параметры клана ---
CREATE_COST = 20_000
MIN_NAME, MAX_NAME = 3, 20
MAX_LEVEL = 5
UPGRADE_COST = {2: 60_000, 3: 150_000, 4: 400_000, 5: 1_000_000}   # цена перехода на этот уровень (из казны клана)
BASE_MEMBERS, MEMBERS_PER_LEVEL = 10, 5
LEVEL_POWER_BONUS = 0.10          # каждый уровень клана даёт +10% к мощи
MEMBER_POWER = 5                  # каждый участник добавляет 5 очков атаки и защиты
MAX_STACK = 10_000

# --- войны ---
WAR_COOLDOWN = 3600               # пауза между нападениями одного клана
PAIR_COOLDOWN = 6 * 3600          # повторно напасть на тот же клан можно через это время
DEFENDER_SHIELD = 4 * 3600        # после нападения защитник получает щит
MIN_ATTACKERS = 2                 # в клане-нападающем должно быть минимум столько участников
WIN_LOOT_PCT, WIN_LOOT_MAX = 10, 100_000      # добыча победившего нападающего: % казны врага (но не больше)
DEF_LOOT_PCT, DEF_LOOT_MAX = 5, 50_000        # добыча победившего защитника
WIN_TROPHIES, LOSE_TROPHIES = 25, 15
DEF_WIN_TROPHIES, DEF_LOSE_TROPHIES = 15, 10
LOSS_WINNER_PCT, LOSS_LOSER_PCT = 3, 10       # потери предметов


def max_members(level: int) -> int:
    return BASE_MEMBERS + MEMBERS_PER_LEVEL * (level - 1)
