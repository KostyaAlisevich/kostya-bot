"""Точка входа: подключает бота к ВК (vkbottle), базе PostgreSQL и запускает обновление цен на бирже."""
import asyncio
import json
import logging
import sys

from vkbottle import Bot, GroupEventType, GroupTypes
from vkbottle.bot import Message

from app import config
from app.db import Database, check_dsn, init_schema
from app.framework.app import App, RateLimiter
from app.framework.dispatcher import handle_event, handle_message
from app.framework.events import ButtonEvent, Incoming
from app.framework.registry import registry
from app.modules import load_all
from app.services import market_engine
from app.vk import VK

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
log = logging.getLogger('bot')

if not config.TOKEN:
    sys.exit('Не задана переменная TOKEN (токен сообщества ВК). Добавьте её во вкладке Variables.')
_dsn_problem = check_dsn(config.DATABASE_URL)
if _dsn_problem:
    sys.exit(f'Неверная переменная DATABASE_URL: {_dsn_problem}')

bot = Bot(token=config.TOKEN)
app: App | None = None


def to_incoming(message: Message) -> Incoming:
    """Превращает сообщение vkbottle в нейтральную структуру для диспетчера."""
    action = None
    if getattr(message, 'action', None) is not None:
        kind = message.action.type
        action = {'type': getattr(kind, 'value', str(kind)), 'member_id': message.action.member_id}
    payload = None
    if message.payload:
        try:
            payload = json.loads(message.payload)
        except (TypeError, ValueError):
            payload = None
    reply_from = message.reply_message.from_id if getattr(message, 'reply_message', None) else None
    fwd = [m.from_id for m in (getattr(message, 'fwd_messages', None) or [])]
    return Incoming(
        peer_id=message.peer_id,
        from_id=message.from_id,
        text=message.text or '',
        cmid=getattr(message, 'conversation_message_id', None),
        reply_from=reply_from,
        fwd_from=fwd,
        action=action,
        payload=payload,
    )


@bot.on.message()
async def on_message(message: Message):
    await handle_message(app, to_incoming(message))


@bot.on.raw_event(GroupEventType.MESSAGE_EVENT, dataclass=GroupTypes.MessageEvent)
async def on_button(event: GroupTypes.MessageEvent):
    obj = event.object
    await handle_event(app, ButtonEvent(
        peer_id=obj.peer_id,
        user_id=obj.user_id,
        cmid=getattr(obj, 'conversation_message_id', None),
        event_id=obj.event_id,
        payload=obj.payload if isinstance(obj.payload, dict) else {},
    ))


async def price_loop() -> None:
    """Раз в несколько минут двигает цены акций, криптовалют и курсы валют."""
    while True:
        try:
            await market_engine.tick(app.db)
        except Exception:  # noqa: BLE001
            log.exception('price tick failed')
        await asyncio.sleep(config.PRICE_TICK_SECONDS)


async def startup() -> None:
    global app
    db = Database(config.DATABASE_URL)
    await db.connect()
    await init_schema(db)
    app = App(db, VK(bot.api, config.GROUP_ID), registry, admin_id=config.ADMIN_ID, limiter=RateLimiter())
    await load_all(app)
    if config.ADMIN_ID:
        await db.execute('UPDATE users SET role=8 WHERE id=$1', config.ADMIN_ID)
    asyncio.create_task(price_loop())
    log.info('Бот запущен. Команд: %s, база подключена.', len(registry.commands))


async def shutdown() -> None:
    if app is not None:
        await app.db.close()
    log.info('Бот остановлен')


bot.loop_wrapper.on_startup.append(startup())
bot.loop_wrapper.on_shutdown.append(shutdown())

if __name__ == '__main__':
    bot.run_forever()
