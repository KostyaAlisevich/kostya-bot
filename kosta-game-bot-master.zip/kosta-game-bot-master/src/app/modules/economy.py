"""Экономика: кошелёк, курсы, обмен валют, переводы, рейтинг богачей, история операций."""
import time

from ..data.jobs import JOBS_BY_KEY
from ..framework.registry import registry
from ..services import accounts, banking, market_engine, wealth
from ..util.fmt import SEP, arrow, fnum, money, mention, num, pct, rub
from ..util.money import CUR_NAMES, parse_currency, parse_money

CUR_SYMBOL = {'rub': '₽', 'usd': '$', 'eur': '€'}
KIND_LABELS = {
    'transfer_in': '📥 Перевод получен', 'transfer_out': '📤 Перевод отправлен',
    'exchange': '💱 Обмен валют', 'work': '💼 Зарплата', 'study': '🎓 Учёба', 'asset_buy': '🛒 Покупка',
    'collect': '💰 Доходы', 'deposit': '🏦 Вклад', 'withdraw': '🏦 Снятие с вклада',
    'loan': '💳 Кредит', 'repay': '💳 Погашение кредита', 'buy': '📈 Покупка на бирже',
    'sell': '📉 Продажа на бирже', 'game': '🎮 Игра', 'promo': '🎁 Промокод', 'family': '👨‍👩‍👧 Семья',
    'treasury': '🏛 Казна', 'admin': '🛠 Администрация', 'fine': '⚠ Штраф',
}
SPREAD = 0.01   # разница между курсами покупки и продажи валюты


def _msk(ts: int) -> str:
    t = time.gmtime(ts + 3 * 3600)
    return f'{t.tm_mday:02d}.{t.tm_mon:02d} {t.tm_hour:02d}:{t.tm_min:02d}'


# ---------------------------------------------------------------------------
# /кошелёк
# ---------------------------------------------------------------------------

@registry.command('wallet', names=['кошелёк', 'эко', 'eco', 'wallet', 'финансы', 'баланс', 'balance'],
                  desc='финансы и меню экономики', section='economy')
async def cmd_wallet(ctx):
    w = await banking.refresh(ctx.db, ctx.scope, ctx.user_id)
    place = 'беседа' if ctx.is_chat else 'личные сообщения'
    job = JOBS_BY_KEY.get(w['job'])
    diplomas = await ctx.db.fetchval(
        'SELECT COUNT(*) FROM edu_progress WHERE scope=$1 AND user_id=$2 AND done=1', ctx.scope, ctx.user_id)
    family = await ctx.db.fetchrow(
        'SELECT f.name FROM family_members m JOIN families f ON f.id = m.family_id '
        'WHERE m.scope=$1 AND m.user_id=$2', ctx.scope, ctx.user_id)
    capital = await wealth.net_worth(ctx.db, ctx.scope, ctx.user_id)

    lines = [
        f'💰 Кошелёк\n{SEP}',
        f'👤 {await ctx.mention()}',
        f'📍 Экономика: {place}',
        '',
        f'₽ Рубли: {rub(w["rub"])}',
        f'💵 Доллары: {money("usd", w["usd"])}',
        f'💶 Евро: {money("eur", w["eur"])}',
    ]
    if w['deposit']:
        lines.append(f'🏦 Вклад: {rub(w["deposit"])}')
    if w['loan']:
        lines.append(f'💳 Долг по кредиту: {rub(w["loan"])}')
    lines += [
        '',
        f'💼 Работа: {job.emoji + " " + job.title if job else "не работаете"}',
        f'🎓 Дипломов: {diplomas}',
        f'👨‍👩‍👧 Семья: {family["name"] if family else "нет"}',
        f'💎 Капитал: {rub(capital)}',
    ]
    kb = (ctx.kb()
          .btn('💱 Обмен', 'exchange').btn('📤 Передать', 'send').btn('🧾 Операции', 'ops').row()
          .btn('🏆 Форбс', 'forbes').btn('💼 Работа', 'jobs').btn('🏦 Банк', 'bank').row()
          .btn('🏠 Меню', 'menu'))
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# /экономика
# ---------------------------------------------------------------------------

@registry.command('economy', names=['экономика', 'экопомощь', 'economy'], desc='справка по экономике', section='economy')
async def cmd_economy(ctx):
    text = (
        f'📚 Экономика бота\n{SEP}\n'
        '₽ Основная валюта - рубли. Есть также доллары и евро (меняются по курсу).\n'
        '📍 В личных сообщениях и в каждой беседе - своя отдельная экономика и свои кошельки.\n\n'
        '💼 Зарабатывайте на работе: сначала простые профессии, затем - по дипломам.\n'
        '🎓 Учитесь: каждое образование открывает новые, более высокооплачиваемые работы.\n'
        '🏢 Покупайте бизнесы, сдавайте дома в аренду, майните - и собирайте доход командой /собрать.\n'
        '🏦 Кладите деньги на вклад (1% в сутки) или берите кредиты (рейтинг влияет на лимит).\n'
        '📈 Торгуйте акциями и криптовалютой: цены меняются каждые несколько минут, бывают новости.\n'
        '👨‍👩‍👧 Создавайте семью с общим бюджетом.\n'
        '🏆 Лучшие попадают в /форбс.\n'
        '🎮 Играйте в игры и пользуйтесь промокодами.\n\n'
        'Полный список команд: /help'
    )
    kb = (ctx.kb()
          .btn('💰 Кошелёк', 'wallet').btn('💼 Работа', 'jobs').btn('🎓 Учёба', 'study').row()
          .btn('🏢 Бизнес', 'biz').btn('🏦 Банк', 'bank').btn('📈 Рынок', 'market').row()
          .btn('🏆 Форбс', 'forbes').btn('❓ Все команды', 'help'))
    await ctx.respond(text, kb)


# ---------------------------------------------------------------------------
# /курс
# ---------------------------------------------------------------------------

@registry.command('rates', names=['курс', 'курсы', 'rates'], desc='курсы валют и криптовалют', section='economy')
async def cmd_rates(ctx):
    px = await market_engine.prices(ctx.db)
    ch = await market_engine.changes(ctx.db)
    lines = [f'💱 Курсы валют\n{SEP}']
    for sym, emoji, name in (('USD', '💵', 'Доллар'), ('EUR', '💶', 'Евро')):
        rate = px[sym]
        lines.append(
            f'{emoji} {name}: {fnum(rate)} ₽ {arrow(ch[sym])} {pct(ch[sym])}\n'
            f'   покупка {fnum(rate * (1 + SPREAD))} · продажа {fnum(rate * (1 - SPREAD))}')
    lines += ['', '🪙 Криптовалюта (в рублях)']
    from ..data.market import CRYPTO
    for tk in CRYPTO:
        lines.append(f'{tk.emoji} {tk.symbol}: {fnum(px[tk.symbol])} ₽ {arrow(ch[tk.symbol])} {pct(ch[tk.symbol])}')
    lines.append('\nИзменение указано за сутки. Курсы виртуальные, обновляются каждые несколько минут.')
    kb = (ctx.kb().btn('💱 Обмен', 'exchange', color='primary').btn('📈 Рынок', 'market').btn('🪙 Крипта', 'crypto').row()
          .btn('🏠 Меню', 'menu'))
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# /обмен
# ---------------------------------------------------------------------------

async def convert(db, scope: int, uid: int, src: str, dst: str, amount_minor: int):
    """Обмен валюты в одной транзакции. Возвращает (получено_в_минорных_единицах, курс) или None, если не хватило денег."""
    rates = await market_engine.fx_rates(db)
    if src == 'rub':
        ask = rates[dst] * (1 + SPREAD)
        got = int(amount_minor * 100 / ask)            # центы
        rate = ask
    elif dst == 'rub':
        bid = rates[src] * (1 - SPREAD)
        got = int(amount_minor / 100 * bid)            # рубли
        rate = bid
    else:                                              # доллары <-> евро через рубли
        bid = rates[src] * (1 - SPREAD)
        ask = rates[dst] * (1 + SPREAD)
        got = int(amount_minor / 100 * bid * 100 / ask)
        rate = bid / ask
    if got <= 0:
        return 0, rate
    async with db.transaction() as tx:
        ok = await accounts.change(tx, scope, uid, -amount_minor, src, 'exchange', f'{src}->{dst}')
        if ok is None:
            return None
        await accounts.change(tx, scope, uid, got, dst, 'exchange', f'{src}->{dst}')
    return got, rate


@registry.command('exchange', names=['обмен', 'обменять', 'exchange'], desc='обмен валют', section='economy',
                  usage='<сумма> <из> <в>')
async def cmd_exchange(ctx):
    w = await ctx.wallet()
    argv = ctx.argv
    balances = {'rub': w['rub'], 'usd': w['usd'], 'eur': w['eur']}
    parsed = parse_money(argv, balances) if argv else None
    if parsed is not None:
        minor, src, rest = parsed
        dst = parse_currency(rest[0]) if rest else None
        if dst is None or dst == src:
            return await ctx.respond('❗ Укажите, во что менять. Пример: /обмен 1000 руб usd')
        result = await convert(ctx.db, ctx.scope, ctx.user_id, src, dst, minor)
        if result is None:
            return await ctx.respond(f'❗ Недостаточно средств. У вас {money(src, balances[src])}')
        got, rate = result
        if got <= 0:
            return await ctx.respond('❗ Сумма слишком мала для обмена')
        kb = ctx.kb().btn('💱 Ещё обмен', 'exchange').btn('💰 Кошелёк', 'wallet').btn('🏠 Меню', 'menu')
        return await ctx.respond(
            f'✅ Обмен выполнен\n{SEP}\n'
            f'Отдали: {money(src, minor)}\nПолучили: {money(dst, got)}\n'
            f'Курс: {fnum(rate, 4)}', kb)

    px = await market_engine.prices(ctx.db)
    text = (
        f'💱 Обмен валют\n{SEP}\n'
        f'💵 USD: {fnum(px["USD"])} ₽ · 💶 EUR: {fnum(px["EUR"])} ₽\n'
        f'Комиссия: разница курсов покупки и продажи ({int(SPREAD * 100)}%)\n\n'
        f'₽ {rub(w["rub"])} · 💵 {money("usd", w["usd"])} · 💶 {money("eur", w["eur"])}\n\n'
        'Точная сумма: /обмен <сумма> <из> <в>\nПример: /обмен 5000 руб usd, /обмен все usd руб'
    )
    kb = (ctx.kb()
          .btn('₽→$ 1 000', 'exchange', '1000 rub usd').btn('₽→$ 10 000', 'exchange', '10000 rub usd').row()
          .btn('$→₽ всё', 'exchange', 'все usd rub').btn('₽→€ 1 000', 'exchange', '1000 rub eur').row()
          .btn('€→₽ всё', 'exchange', 'все eur rub').btn('💰 Кошелёк', 'wallet').btn('🏠 Меню', 'menu'))
    await ctx.respond(text, kb)


# ---------------------------------------------------------------------------
# /передать
# ---------------------------------------------------------------------------

@registry.command('send', names=['передать', 'отправить', 'send', 'перевод'], desc='перевод рублей или долларов',
                  section='economy', usage='<кому> <сумма>')
async def cmd_send(ctx):
    target, rest = await ctx.target()
    w = await ctx.wallet()
    balances = {'rub': w['rub'], 'usd': w['usd'], 'eur': w['eur']}
    parsed = parse_money(rest, balances) if rest else None
    usage = ('📤 Перевод\nФормат: /передать <кому> <сумма> [валюта]\n'
             'Кому: @имя, ссылка, id или ответом на сообщение.\n'
             'Примеры: /передать @ivan 500, /передать @ivan 10$, ответом на сообщение: /передать 1000')
    if target is None or parsed is None:
        if ctx.via_button or not ctx.args:
            return await ctx.respond(usage, ctx.kb().btn('🏠 Меню', 'menu'))
        return await ctx.respond('❗ Не удалось разобрать команду.\n' + usage)
    minor, cur, _ = parsed
    if target == ctx.user_id:
        return await ctx.respond('❗ Нельзя переводить деньги самому себе')

    await accounts.ensure_wallet(ctx.db, ctx.scope, target)
    async with ctx.db.transaction() as tx:
        ok = await accounts.change(tx, ctx.scope, ctx.user_id, -minor, cur, 'transfer_out', f'-> {target}')
        if ok is None:
            return await ctx.respond(f'❗ Недостаточно средств. У вас {money(cur, balances[cur])}')
        await accounts.change(tx, ctx.scope, target, minor, cur, 'transfer_in', f'<- {ctx.user_id}')

    text = f'✅ {await ctx.mention()} перевёл(а) {await ctx.mention(target)}: {money(cur, minor)}'
    await ctx.respond(text)
    if not ctx.is_chat:  # в личных сообщениях получателю нужно сообщить отдельно
        await ctx.app.vk.send(target, f'💸 Вам перевели {money(cur, minor)} от {await ctx.mention()}')


# ---------------------------------------------------------------------------
# /форбс
# ---------------------------------------------------------------------------

@registry.command('forbes', names=['форбс', 'forbes', 'богачи'], desc='самые богатые участники и семьи',
                  section='economy')
async def cmd_forbes(ctx):
    wm = await wealth.wealth_map(ctx.db, ctx.scope)
    top = sorted(wm.items(), key=lambda kv: kv[1], reverse=True)[:10]
    place = 'этой беседы' if ctx.is_chat else 'личных сообщений'
    lines = [f'🏆 Форбс: богатейшие {place}\n{SEP}']
    medals = ['🥇', '🥈', '🥉']
    if not top:
        lines.append('Пока никого нет. Станьте первым!')
    for i, (uid, value) in enumerate(top):
        mark = medals[i] if i < 3 else f'{i + 1}.'
        lines.append(f'{mark} {mention(uid, await accounts.display_name(ctx.app, uid))} - {rub(value)}')
    my = wm.get(ctx.user_id)
    if my is not None and ctx.user_id not in {u for u, _ in top}:
        place_no = 1 + sum(1 for v in wm.values() if v > my)
        lines.append(f'…\n{place_no}. Вы - {rub(my)}')

    fam_rows = await ctx.db.fetch(
        'SELECT f.id, f.name, f.budget, m.user_id FROM families f '
        'LEFT JOIN family_members m ON m.family_id = f.id WHERE f.scope=$1', ctx.scope)
    families: dict[int, dict] = {}
    for r in fam_rows:
        fam = families.setdefault(r['id'], {'name': r['name'], 'sum': r['budget'], 'n': 0})
        if r['user_id'] is not None:
            fam['sum'] += wm.get(r['user_id'], 0)
            fam['n'] += 1
    if families:
        lines += ['', '👨‍👩‍👧 Богатейшие семьи']
        for i, fam in enumerate(sorted(families.values(), key=lambda f: f['sum'], reverse=True)[:5], 1):
            lines.append(f'{i}. «{fam["name"]}» - {rub(fam["sum"])} ({fam["n"]} чел.)')

    kb = ctx.kb().btn('💰 Кошелёк', 'wallet').btn('👨‍👩‍👧 Семья', 'family').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# /операции
# ---------------------------------------------------------------------------

PAGE = 8


@registry.command('ops', names=['операции', 'ops', 'транзакции'], desc='история ваших операций', section='economy')
async def cmd_ops(ctx):
    argv = ctx.argv
    page = int(argv[0]) if argv and argv[0].isdigit() else 0
    total = await ctx.db.fetchval(
        'SELECT COUNT(*) FROM transactions WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
    pages = max(1, (total + PAGE - 1) // PAGE)
    page = max(0, min(page, pages - 1))
    rows = await ctx.db.fetch(
        'SELECT * FROM transactions WHERE scope=$1 AND user_id=$2 ORDER BY id DESC LIMIT $3 OFFSET $4',
        ctx.scope, ctx.user_id, PAGE, page * PAGE)
    lines = [f'🧾 Ваши операции | стр. {page + 1}/{pages}\n{SEP}']
    if not rows:
        lines.append('Операций пока нет.')
    for r in rows:
        sign = '+' if r['amount'] > 0 else '−'
        amount = money(r['currency'], abs(r['amount']))
        lines.append(f'{sign}{amount} · {KIND_LABELS.get(r["kind"], r["kind"] or "Операция")} · {_msk(r["ts"])}')
    kb = ctx.kb()
    if page > 0:
        kb.btn('◀', 'ops', str(page - 1))
    if page < pages - 1:
        kb.btn('▶', 'ops', str(page + 1))
    kb.btn('💰 Кошелёк', 'wallet').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)
