"""SQLite с интерфейсом Database (asyncpg-подобным): для проверки SQL в песочнице без PostgreSQL."""
import re
import sqlite3
from contextlib import asynccontextmanager

_PARAM = re.compile(r'\$(\d+)')


def translate(sql: str) -> str:
    sql = sql.replace('BIGSERIAL PRIMARY KEY', 'INTEGER PRIMARY KEY AUTOINCREMENT')
    sql = sql.replace('DOUBLE PRECISION', 'REAL')
    sql = re.sub(r'\s+FOR UPDATE\b', '', sql)
    return _PARAM.sub(lambda m: '?' + m.group(1), sql)


class _Conn:
    def __init__(self, con: sqlite3.Connection):
        self.con = con

    def _run(self, sql, args):
        cur = self.con.execute(translate(sql), args)
        return cur

    async def fetch(self, sql, *args):
        cur = self._run(sql, args)
        rows = cur.fetchall()
        return [dict(r) for r in rows]

    async def fetchrow(self, sql, *args):
        cur = self._run(sql, args)
        row = cur.fetchone()
        return dict(row) if row is not None else None

    async def fetchval(self, sql, *args):
        cur = self._run(sql, args)
        row = cur.fetchone()
        return None if row is None else row[0]

    async def execute(self, sql, *args):
        cur = self._run(sql, args)
        verb = sql.strip().split()[0].upper()
        return f'{verb} {max(cur.rowcount, 0)}'


class SqliteDatabase(_Conn):
    def __init__(self):
        con = sqlite3.connect(':memory:', isolation_level=None)
        con.row_factory = sqlite3.Row
        super().__init__(con)
        self._in_tx = False

    async def connect(self):
        pass

    async def close(self):
        self.con.close()

    @asynccontextmanager
    async def transaction(self):
        assert not self._in_tx, 'вложенные транзакции не поддерживаются - передавайте conn вниз по коду'
        self.con.execute('BEGIN')
        self._in_tx = True
        try:
            yield _Conn(self.con)
        except BaseException:
            self.con.execute('ROLLBACK')
            raise
        else:
            self.con.execute('COMMIT')
        finally:
            self._in_tx = False
