"""Вклады и кредиты: проценты начисляются «лениво» при каждом обращении к кошельку."""
from . import accounts

DEPOSIT_RATE_DAILY = 0.01        # 1% в сутки
DEPOSIT_CAP = 5_000_000          # максимум на вкладе
LOAN_FEE_PCT = 10                # комиссия за кредит
LOAN_TERM = 48 * 3600            # срок кредита
OVERDUE_PCT = 5                  # штраф за каждые сутки просрочки (на всю сумму долга)
OVERDUE_SCORE = 15               # минус к рейтингу за сутки просрочки
SCORE_MIN, SCORE_MAX = 300, 850
LOAN_MIN = 1_000


def credit_limit(score: int) -> int:
    return max(0, score - SCORE_MIN) * 200


def score_label(score: int) -> str:
    if score >= 750:
        return 'отличный'
    if score >= 650:
        return 'хороший'
    if score >= 500:
        return 'средний'
    return 'низкий'


async def refresh(db, scope: int, uid: int):
    """Начисляет проценты по вкладу и штрафы за просрочку. Возвращает актуальную строку кошелька."""
    w = await accounts.ensure_wallet(db, scope, uid)
    t = accounts.now()

    if w['deposit'] > 0 and w['deposit_ts'] > 0:
        interest = int(w['deposit'] * DEPOSIT_RATE_DAILY * (t - w['deposit_ts']) / 86400)
        if interest > 0:
            # условие deposit_ts = старое значение защищает от двойного начисления при параллельных запросах
            await db.execute(
                'UPDATE wallets SET deposit = deposit + $3, deposit_ts = $4 '
                'WHERE scope=$1 AND user_id=$2 AND deposit_ts = $5', scope, uid, interest, t, w['deposit_ts'])

    if w['loan'] > 0 and t > w['loan_due']:
        base = max(w['loan_due'], w['loan_pen_ts'])
        days = (t - base) // 86400
        if days > 0:
            loan = w['loan']
            for _ in range(min(days, 60)):
                loan += loan * OVERDUE_PCT // 100
            score = max(SCORE_MIN, w['credit_score'] - OVERDUE_SCORE * days)
            await db.execute(
                'UPDATE wallets SET loan=$3, credit_score=$4, loan_pen_ts=$5 '
                'WHERE scope=$1 AND user_id=$2 AND loan_pen_ts = $6',
                scope, uid, loan, score, base + days * 86400, w['loan_pen_ts'])

    return await db.fetchrow('SELECT * FROM wallets WHERE scope=$1 AND user_id=$2', scope, uid)
