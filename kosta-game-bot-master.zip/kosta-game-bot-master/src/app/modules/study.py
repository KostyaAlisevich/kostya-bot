"""Учёба: записаться на курс, проходить занятия, получить диплом (он открывает работы)."""
from ..data.education import EDU_BY_KEY, EDUCATIONS
from ..data.jobs import JOBS
from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, dur, rub
from ..util.pages import find_ref, paginate

PAGE_SIZE = 4


class _Stop(Exception):
    """Откат транзакции."""


async def diplomas(db, scope: int, uid: int) -> set[str]:
    rows = await db.fetch('SELECT edu_key FROM edu_progress WHERE scope=$1 AND user_id=$2 AND done=1', scope, uid)
    return {r['edu_key'] for r in rows}


def unlocked_jobs(edu_key: str) -> list:
    return [j for j in JOBS if j.edu == edu_key]


def _status(edu, done: set, progress: dict) -> tuple[str, str]:
    """Значок и пояснение статуса курса."""
    if edu.key in done:
        return '✅', 'диплом получен'
    if edu.key in progress:
        return '📖', f'идёт: {progress[edu.key]["lessons"]}/{edu.lessons} занятий'
    missing = [EDU_BY_KEY[r].title for r in edu.requires if r not in done]
    if missing:
        return '🔒', 'нужно: ' + ', '.join(missing)
    return '🔓', f'{rub(edu.cost)}, {edu.lessons} занятий'


async def _load(ctx):
    rows = await ctx.db.fetch('SELECT * FROM edu_progress WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
    done = {r['edu_key'] for r in rows if r['done']}
    progress = {r['edu_key']: r for r in rows if not r['done']}
    return done, progress


@registry.command('study', names=['учёба', 'образование', 'study'], desc='курсы и образование', section='work',
                  usage='[номер]')
async def cmd_study(ctx):
    await ctx.wallet()
    done, progress = await _load(ctx)
    arg = ctx.args.strip()
    if arg.startswith('c:'):
        return await _card(ctx, arg[2:], done, progress)

    page = int(arg) if arg.isdigit() else 0
    items, page, total = paginate(EDUCATIONS, page, PAGE_SIZE)
    lines = [f'🎓 Образование | стр. {page + 1}/{total}\n{SEP}',
             f'Дипломов: {len(done)} из {len(EDUCATIONS)}']
    if progress:
        key, row = next(iter(progress.items()))
        e = EDU_BY_KEY[key]
        left = max(0, row['next_at'] - accounts.now())
        lines.append(f'📖 Сейчас: {e.emoji} {e.title} - {row["lessons"]}/{e.lessons}'
                     + (f' (след. занятие через {dur(left)})' if left else ' (занятие доступно)'))
    lines.append('')
    for e in items:
        icon, note = _status(e, done, progress)
        lines.append(f'{icon} {e.emoji} {e.title}\n    {note}')
    lines.append('\nВыберите курс кнопкой или: /учиться <название>')

    kb = ctx.kb()
    for i, e in enumerate(items):
        if i and i % 2 == 0:
            kb.row()
        kb.btn(f'{e.emoji} {e.title}', 'study', f'c:{e.key}', color='primary' if e.key in progress else 'secondary')
    kb.row()
    if page > 0:
        kb.btn('◀', 'study', str(page - 1))
    if page < total - 1:
        kb.btn('▶', 'study', str(page + 1))
    kb.btn('💼 Работа', 'jobs').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


async def _card(ctx, key: str, done: set, progress: dict):
    e = EDU_BY_KEY.get(key)
    if e is None:
        return await ctx.respond('❗ Курс не найден', ctx.kb().btn('🎓 К списку', 'study'))
    icon, note = _status(e, done, progress)
    jobs = unlocked_jobs(e.key)
    lines = [
        f'{e.emoji} {e.title}\n{SEP}', e.description, '',
        f'{icon} Статус: {note}',
        f'💵 Стоимость: {rub(e.cost)}',
        f'📖 Занятий: {e.lessons} (перерыв между ними {dur(e.cooldown)})',
    ]
    if e.requires:
        lines.append('📋 Нужны дипломы: ' + ', '.join(
            f'{"✅" if r in done else "❌"} {EDU_BY_KEY[r].title}' for r in e.requires))
    if jobs:
        lines.append('💼 Открывает работы: ' + ', '.join(f'{j.emoji} {j.title}' for j in jobs))
    kb = ctx.kb()
    if e.key in done:
        pass
    elif e.key in progress:
        kb.btn('📖 Пройти занятие', 'learn', e.key, color='positive')
    elif all(r in done for r in e.requires):
        kb.btn(f'✍ Записаться за {rub(e.cost)}', 'learn', e.key, color='positive')
    kb.row().btn('🎓 К списку', 'study').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


@registry.command('learn', names=['учиться', 'learn'], desc='записаться на курс или пройти занятие', section='work',
                  usage='<курс>')
async def cmd_learn(ctx):
    await ctx.wallet()
    done, progress = await _load(ctx)
    ref = ctx.args.strip()
    if not ref:
        if len(progress) == 1:
            ref = next(iter(progress))
        else:
            return await cmd_study(ctx)
    edu = find_ref(list(EDUCATIONS), ref)
    if edu is None:
        return await ctx.respond('❗ Курс не найден. Список курсов: /учеба', ctx.kb().btn('🎓 Курсы', 'study'))

    if edu.key in done:
        return await ctx.respond(f'✅ Диплом «{edu.title}» у вас уже есть', ctx.kb().btn('💼 Работа', 'jobs'))

    if edu.key not in progress:
        return await _enroll(ctx, edu, done, progress)
    await _lesson(ctx, edu, progress[edu.key])


async def _enroll(ctx, edu, done: set, progress: dict):
    missing = [EDU_BY_KEY[r].title for r in edu.requires if r not in done]
    if missing:
        return await ctx.respond('🔒 Сначала получите: ' + ', '.join(missing), ctx.kb().btn('🎓 Курсы', 'study'))
    if progress:
        cur = EDU_BY_KEY[next(iter(progress))]
        return await ctx.respond(f'📖 Сначала закончите текущий курс «{cur.title}»',
                                 ctx.kb().btn('📖 Пройти занятие', 'learn', cur.key).btn('🎓 Курсы', 'study'))
    try:
        async with ctx.db.transaction() as tx:
            inserted = await tx.fetchrow(
                'INSERT INTO edu_progress (scope, user_id, edu_key) VALUES ($1, $2, $3) '
                'ON CONFLICT (scope, user_id, edu_key) DO NOTHING RETURNING lessons',
                ctx.scope, ctx.user_id, edu.key)
            if inserted is None:
                raise _Stop('already')
            paid = await accounts.change(tx, ctx.scope, ctx.user_id, -edu.cost, 'rub', 'study', edu.title)
            if paid is None:
                raise _Stop('money')
    except _Stop as stop:
        if str(stop) == 'money':
            w = await ctx.wallet()
            return await ctx.respond(f'❗ Не хватает денег: курс стоит {rub(edu.cost)}, у вас {rub(w["rub"])}',
                                     ctx.kb().btn('💼 Работа', 'jobs').btn('🎓 Курсы', 'study'))
        return await ctx.respond('📖 Вы уже записаны на этот курс')
    kb = ctx.kb().btn('📖 Пройти занятие', 'learn', edu.key, color='positive').btn('🎓 Курсы', 'study')
    await ctx.respond(
        f'✅ Вы записались на курс «{edu.title}» за {rub(edu.cost)}\n'
        f'Занятий: {edu.lessons}. Первое занятие доступно прямо сейчас!', kb)


async def _lesson(ctx, edu, row):
    t = accounts.now()
    claimed = await ctx.db.fetchrow(
        'UPDATE edu_progress SET lessons = lessons + 1, next_at = $4 '
        'WHERE scope=$1 AND user_id=$2 AND edu_key=$3 AND done=0 AND next_at <= $5 RETURNING lessons',
        ctx.scope, ctx.user_id, edu.key, t + edu.cooldown, t)
    if claimed is None:
        left = max(1, row['next_at'] - t)
        return await ctx.respond(
            f'⏳ Следующее занятие по курсу «{edu.title}» будет доступно через {dur(left)}',
            ctx.kb().btn('🎓 Курсы', 'study').btn('💼 Работа', 'jobs'))
    lessons = claimed['lessons']
    if lessons < edu.lessons:
        return await ctx.respond(
            f'📖 Занятие пройдено: {lessons}/{edu.lessons}\n'
            f'Следующее через {dur(edu.cooldown)}.',
            ctx.kb().btn('🎓 Курсы', 'study').btn('🏠 Меню', 'menu'))
    await ctx.db.execute(
        'UPDATE edu_progress SET done=1, finished_at=$4 WHERE scope=$1 AND user_id=$2 AND edu_key=$3',
        ctx.scope, ctx.user_id, edu.key, t)
    jobs = unlocked_jobs(edu.key)
    text = f'🎓 Поздравляем! Вы получили диплом «{edu.title}»!'
    if jobs:
        text += '\n💼 Теперь вам доступны работы:\n' + '\n'.join(f'{j.emoji} {j.title}' for j in jobs)
    await ctx.respond(text, ctx.kb().btn('💼 Вакансии', 'jobs', color='positive').btn('🎓 Курсы', 'study'))
