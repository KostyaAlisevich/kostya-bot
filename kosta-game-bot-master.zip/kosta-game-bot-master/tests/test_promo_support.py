import asyncio
from sim import Sim, OWNER, CHAT_BASE
from app.services import accounts

CHAT = CHAT_BASE + 31


async def main():
    s = await Sim.create()
    for u in (1, 2, 3, 4, 5):
        await s.say(u, '/start')

    # ===== создание промокодов (администрация) =====
    await s.set_role(4, 4); await s.set_role(5, 3)
    assert 'Недостаточно прав' in (await s.last(1, '/промосоздать START 1000')).text
    assert 'Недостаточно прав' in (await s.last(5, '/промосоздать START 1000')).text, 'нужна должность 4+'
    m = await s.last(4, '/промосоздать start 1000 2 24')
    assert 'Промокод создан' in m.text and 'Код: START' in m.text and 'Активаций: 2' in m.text and 'Срок: 1 д' in m.text
    assert 'уже существует' in (await s.last(4, '/промосоздать START 5')).text
    m = await s.last(4, '/promocreate авто 500')
    code_auto = m.text.split('Код: ')[1].split('\n')[0]
    assert len(code_auto) == 8 and 'без ограничений' in m.text and 'бессрочно' in m.text
    for bad in ('/промосоздать', '/промосоздать X 100', '/промосоздать ABC abc', '/промосоздать ABC 0', '/промосоздать ABC 999999999999'):
        m = await s.last(4, bad)
        assert 'Формат' in m.text or 'Код:' in m.text or 'Сумма' in m.text or 'Новый промокод' in m.text, (bad, m.text)
    print('OK  создание промокодов: права 4+, автокод, лимиты, дубликаты, валидация')

    # создание через кнопку: бот спрашивает, следующее сообщение - ответ
    m = await s.last(4, '/промосоздать')
    assert 'Отправьте: КОД СУММА' in m.text
    m = await s.last(4, 'VIP 7777 5')
    assert 'Код: VIP' in m.text and 'Награда: 7 777 ₽' in m.text
    print('OK  создание промокода диалогом (ввод следующим сообщением)')

    # ===== активация =====
    m = await s.last(1, '/промокод start')
    assert 'Промокод активирован' in m.text and '+1 000 ₽' in m.text and '6 000 ₽' in m.text
    assert (await s.wallet(1))['rub'] == 6000
    assert 'уже активировали' in (await s.last(1, '/промо START')).text
    assert (await s.wallet(1))['rub'] == 6000
    m = await s.last(2, '/promo START'); assert 'Промокод активирован' in m.text
    m = await s.last(3, '/код start'); assert 'максимальное число раз' in m.text and (await s.wallet(3))['rub'] == 5000
    assert 'нет' in (await s.last(3, '/промо NOPE')).text
    assert 'буквы, цифры' in (await s.last(3, '/промо a!')).text
    print('OK  активация: начисление, повторная, лимит активаций, неверный код')

    # диалог: меню -> «Промокод» -> следующее сообщение
    m = await s.last(3, '/промо')
    assert 'Отправьте промокод следующим сообщением' in m.text
    m = await s.last(3, code_auto.lower())
    assert 'Промокод активирован' in m.text and (await s.wallet(3))['rub'] == 5500
    # новая команда отменяет ожидание
    await s.last(2, '/промо'); m = await s.last(2, '/кошелёк')
    assert 'Кошелёк' in m.text
    ev = await s.say(2, 'какой-то текст')
    assert not any('Промокод' in e.text for e in ev), 'ожидание ввода сброшено командой: текст не принят как промокод'
    print('OK  диалог ввода промокода, отмена ожидания другой командой')

    # срок действия
    await s.set_role(4, 4)
    await s.last(4, '/промосоздать OLD 100 0 1')
    await s.db.execute("UPDATE promo_codes SET expires_at=$1 WHERE code='OLD'", accounts.now() - 5)
    assert 'истёк' in (await s.last(1, '/промо OLD')).text
    print('OK  истёкший промокод')

    # промокод в беседе зачисляется в кошелёк беседы
    await s.make_chat(CHAT, creator=10, members=(1,))
    m = await s.last(1, '/промо VIP', peer=CHAT)
    assert 'Промокод активирован' in m.text
    assert (await s.wallet(1, CHAT))['rub'] == 5000 + 7777
    assert 'уже активировали' in (await s.last(1, '/промо VIP')).text, 'один код - один раз на человека, даже в другом чате'
    print('OK  в беседе начисляется в кошелёк беседы; повтор в другом месте невозможен')

    # ===== список и удаление =====
    m = await s.last(5, '/промолист')          # должность 3 может смотреть
    assert 'START · 1 000 ₽ · 2/2 · 🚫 исчерпан' in m.text and 'VIP' in m.text and 'OLD' in m.text and '⌛ истёк' in m.text
    assert not m.find('Создать'), 'создавать/удалять может только 4+'
    m = await s.last(4, '/промолист'); assert m.find('Создать') and m.find('Удалить')
    assert 'удалён' in (await s.last(4, '/промоудалить old')).text
    assert 'не найден' in (await s.last(4, '/промоудалить old')).text
    assert 'OLD' not in (await s.last(4, '/промолист')).text
    print('OK  /промолист (3+), создание и удаление (4+)')

    # ===== поддержка: пользователь =====
    for staff, role in ((6, 1), (7, 2), (8, 8)):
        await s.say(staff, '/start'); await s.set_role(staff, role)
    await s.say(9, '/start')   # обычный
    m = await s.last(1, '/поддержка')
    assert 'следующим сообщением' in m.text
    ev = await s.say(1, 'Не приходит награда за работу, помогите пожалуйста')
    assert 'обращение №1 отправлено' in ev[0].text
    notified = {e.peer: e for e in ev if e.peer != 1}
    assert set(notified) == {6, 7, 8, OWNER} or set(notified) >= {6, 7, 8}, notified.keys()
    assert all('Новое обращение №1' in e.text and e.find('Ответить') for e in notified.values())
    assert 9 not in notified and 1 not in notified, 'обычным пользователям тикеты не приходят'
    assert 'подробнее' in (await s.last(1, '/поддержка нет')).text
    assert 'Не так быстро' in (await s.last(1, '/поддержка Ещё один вопрос по экономике')).text
    await s.db.execute('UPDATE tickets SET created_at=created_at-100')
    await s.say(1, '/поддержка Второй вопрос про банк, как взять кредит?')
    await s.db.execute('UPDATE tickets SET created_at=created_at-100')
    await s.say(1, '/support Третий вопрос про курсы и образование')
    await s.db.execute('UPDATE tickets SET created_at=created_at-100')
    assert 'уже 3 открытых' in (await s.last(1, '/вопрос Четвёртый вопрос про всё подряд')).text
    print('OK  обращение: пользователь пишет, все сотрудники получают уведомление, защита от спама')

    # ===== поддержка: сотрудники =====
    assert 'Недостаточно прав' in (await s.last(9, '/тикеты')).text
    m = await s.last(6, '/тикеты')              # агент поддержки (1)
    assert 'открытых: 3' in m.text and '№1' in m.text and 'Не приходит награда' in m.text
    assert m.find('№1') and m.find('№3')
    m = await s.press(6, '№1')
    assert 'Обращение №1' in m.text and 'От: [id1|Юзер1]' in m.text and m.find('Ответить') and m.find('Закрыть')

    # ответ кнопкой + следующее сообщение
    m = await s.press(6, 'Ответить')
    assert 'Ответ на обращение №1' in m.text
    ev = await s.say(6, 'Здравствуйте! Награда зачисляется после смены, проверьте /кошелёк.')
    to_user = [e for e in ev if e.peer == 1]
    assert to_user and 'Ответ поддержки на обращение №1' in to_user[0].text and 'Награда зачисляется' in to_user[0].text
    assert '[id6|Юзер6] (Агент поддержки)' in to_user[0].text
    assert (await s.db.fetchrow('SELECT status FROM tickets WHERE id=1'))['status'] == 'answered'
    m = await s.last(7, '/тикеты')              # старший агент видит, что №1 уже отвечен, и новые идут первыми
    assert m.text.index('№2') < m.text.index('№1')
    assert '💬 отвечен' in m.text
    print('OK  сотрудники видят очередь, открывают обращение, отвечают кнопкой; пользователь получает ответ')

    # ответ командой другим сотрудником
    ev = await s.say(7, '/ответ 1 Дополнение от старшего агента: рейтинг обновится сразу.')
    assert any(e.peer == 1 and 'Дополнение' in e.text and 'Старший Агент Поддержки' in e.text for e in ev)
    assert 'Формат' in (await s.last(7, '/ответ 1')).text and 'Формат' in (await s.last(7, '/ответ')).text
    assert 'не найдено' in (await s.last(7, '/ответ 99 текст ответа')).text
    m = await s.cb(7, 'ticket_view', '1')
    assert 'Награда зачисляется' in m.text and 'Дополнение' in m.text, 'история ответов сохраняется'

    # закрытие
    ev = await s.say(6, '/закрыть 1')
    assert any(e.peer == 1 and 'закрыто' in e.text for e in ev)
    assert 'уже закрыто' in (await s.last(6, '/закрыть 1')).text
    assert 'закрыто' in (await s.last(6, '/ответ 1 ещё ответ')).text
    assert '№1' not in (await s.last(6, '/тикеты')).text
    print('OK  ответ командой, история ответов, закрытие, закрытое нельзя дополнять')

    # доставка невозможна
    s.vk.blocked.add(2)
    await s.db.execute('UPDATE tickets SET created_at=created_at-100')
    ev = await s.say(2, '/поддержка Вопрос от пользователя с закрытыми сообщениями')
    tid = (await s.db.fetchval('SELECT MAX(id) FROM tickets'))
    m = await s.last(6, f'/ответ {tid} Ответ, который не сможет дойти')
    assert 'Не удалось доставить' in m.text and 'Ответ сохранён' in m.text
    print('OK  если пользователю нельзя написать - сотрудник предупреждён')

    # вопрос из беседы
    await s.db.execute('UPDATE tickets SET created_at=created_at-100')
    ev = await s.say(3, '/поддержка Вопрос из беседы про казну', peer=CHAT)
    assert 'отправлено в поддержку' in ev[0].text and ev[0].peer == CHAT
    assert (await s.db.fetchrow('SELECT peer_id FROM tickets ORDER BY id DESC LIMIT 1'))['peer_id'] == CHAT
    print('OK  вопрос можно задать и из беседы, ответ придёт в личные сообщения')

    print('\nВсе тесты promo/support пройдены')

asyncio.run(main())
