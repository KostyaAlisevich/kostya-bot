"""Тикеры биржи и курсов валют. Цены виртуальные: в игре они случайно блуждают вокруг базовой цены."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Ticker:
    symbol: str
    kind: str          # 'stock' | 'crypto' | 'fx'
    name: str
    emoji: str
    base: float        # базовая цена, ₽ (для fx - курс одной единицы валюты в рублях)
    vol: float         # волатильность за один шаг цены (доля, например 0.0025 = 0,25%)


STOCKS: tuple[Ticker, ...] = (
    Ticker('NFTX', 'stock', 'НефтьГаз', '🛢', 280.0, 0.0025),
    Ticker('GRNB', 'stock', 'ГринБанк', '🏦', 320.0, 0.0022),
    Ticker('SRCH', 'stock', 'ПоискИнк', '🔎', 4200.0, 0.0030),
    Ticker('TCHN', 'stock', 'ТехноМир', '🖥', 1500.0, 0.0030),
    Ticker('AUTO', 'stock', 'АвтоЗавод', '🚙', 95.0, 0.0028),
    Ticker('PHRM', 'stock', 'ФармаЛайф', '💊', 780.0, 0.0024),
    Ticker('GOLD', 'stock', 'ГолдМайн', '🥇', 2200.0, 0.0026),
    Ticker('TELC', 'stock', 'ТелеКом', '📡', 60.0, 0.0020),
)
CRYPTO: tuple[Ticker, ...] = (
    Ticker('BTC', 'crypto', 'Bitcoin', '🟠', 6_000_000.0, 0.0060),
    Ticker('ETH', 'crypto', 'Ethereum', '🔷', 300_000.0, 0.0070),
    Ticker('TON', 'crypto', 'Toncoin', '💎', 500.0, 0.0080),
    Ticker('SOL', 'crypto', 'Solana', '🟣', 15_000.0, 0.0085),
    Ticker('DOGE', 'crypto', 'Dogecoin', '🐕', 12.0, 0.0100),
)
FX: tuple[Ticker, ...] = (
    Ticker('USD', 'fx', 'Доллар США', '💵', 90.0, 0.0006),
    Ticker('EUR', 'fx', 'Евро', '💶', 98.0, 0.0006),
)

TICKERS: tuple[Ticker, ...] = STOCKS + CRYPTO + FX
TICKERS_BY_SYMBOL: dict[str, Ticker] = {t.symbol: t for t in TICKERS}
TRADABLE: tuple[Ticker, ...] = STOCKS + CRYPTO   # то, что можно купить и продать на бирже

# Новости: шаблон и знак влияния на цену
NEWS_UP = (
    '{name}: компания представила прорывной продукт',
    '{name}: квартальная прибыль превзошла ожидания',
    '{name}: крупный инвестор нарастил долю',
    '{name}: подписан выгодный контракт',
)
NEWS_DOWN = (
    '{name}: отчётность разочаровала рынок',
    '{name}: регуляторы начали проверку',
    '{name}: крупный акционер распродаёт бумаги',
    '{name}: сбой в работе и жалобы клиентов',
)
NEWS_UP_CRYPTO = (
    '{name}: растёт интерес институциональных инвесторов',
    '{name}: сеть обновилась, комиссии упали',
)
NEWS_DOWN_CRYPTO = (
    '{name}: громкий взлом биржи пошатнул доверие',
    '{name}: ужесточение регулирования испугало трейдеров',
)
