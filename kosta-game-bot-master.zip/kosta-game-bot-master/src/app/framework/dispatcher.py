"""Диспетчер: принимает сообщения и нажатия кнопок, проверяет бан, права и вызывает команды."""
import logging
import re
import time

from ..config import CHAT_BASE
from ..roles import staff_name
from ..services import accounts, chats
from .context import Ctx
from .keyboards import KB
from .events import ButtonEvent, Incoming

log = logging.getLogger('bot.dispatch')

_BOT_MENTION = re.compile(r'^\s*\[club\d+\|[^\]]*\]\s*[,:]?\s*', re.IGNORECASE)
PREFIXES = '/!'

BANNED_TEXT = '🚫 Ваш аккаунт заблокирован в боте.\nПричина: {reason}\nЕсли это ошибка, обратитесь к руководству бота.'
ERROR_TEXT = '⚠ Что-то пошло не так. Попробуйте ещё раз чуть позже.'


def parse_command(registry, text: str, is_chat: bool):
    """Возвращает (команда | None, строка аргументов). В беседах нужен префикс / или !,
    в личных сообщениях команды можно писать и без него."""
    t = _BOT_MENTION.sub('', text or '').strip()
    if not t:
        return None, ''
    if t[0] in PREFIXES:
        t = t[1:].lstrip()
    elif is_chat:
        return None, ''
    if not t:
        return None, ''
    parts = re.split(r'\s+', t, maxsplit=1)
    head = parts[0].split('@')[0]
    rest = parts[1] if len(parts) > 1 else ''
    cmd = registry.find(head)
    return (cmd, rest) if cmd else (None, '')


async def _deny(ctx: Ctx, text: str):
    kb = ctx.kb().btn('❓ Помощь', 'help')
    await ctx.respond(text, kb)


async def run_command(app, cmd, ctx: Ctx) -> None:
    """Проверяет место и права, затем вызывает обработчик команды."""
    if cmd.where == 'chat' and not ctx.is_chat:
        return await ctx.respond('💬 Эта команда работает только в беседах. Добавьте бота в беседу и напишите /start')
    if cmd.where == 'dm' and ctx.is_chat:
        return await ctx.respond('📩 Эта команда работает только в личных сообщениях с ботом')
    if cmd.staff and await ctx.role() < cmd.staff:
        return await _deny(ctx, f'🚫 Недостаточно прав. Нужна должность: {staff_name(cmd.staff)} или выше')
    if cmd.level and await ctx.chat_level() < cmd.level:
        where = 'в беседе' if ctx.is_chat else 'в боте'
        return await _deny(ctx, f'🚫 Недостаточно прав. Нужна роль {cmd.level}+ {where}')
    try:
        await cmd.handler(ctx)
    except Exception:  # noqa: BLE001 - пользователю показываем мягкую ошибку, детали - в лог
        log.exception('command %s failed (user=%s peer=%s args=%r)', cmd.key, ctx.user_id, ctx.peer_id, ctx.args)
        await ctx.send(ERROR_TEXT)


async def handle_message(app, inc: Incoming) -> None:
    if inc.from_id <= 0:  # сообщения от сообществ и служебные
        return
    is_chat = inc.peer_id >= CHAT_BASE

    if app.limiter is not None and not app.limiter.allow(inc.from_id):
        return

    user = await accounts.register_user(app, inc.from_id, dm=not is_chat)
    if user['banned']:
        if not is_chat:
            last = app.ban_notified.get(inc.from_id, 0)
            if time.time() - last > 600:
                app.ban_notified[inc.from_id] = time.time()
                await app.vk.send(inc.peer_id, BANNED_TEXT.format(reason=user['ban_reason'] or 'не указана'))
        return

    if inc.action:
        if is_chat:
            for hook in app.registry.chat_events:
                if await hook(app, inc):
                    break
        return

    text = inc.text or ''
    if inc.payload and isinstance(inc.payload, dict) and inc.payload.get('command') == 'start':
        text = '/start'

    chat = None
    if is_chat:
        chat = await chats.get_chat(app.db, inc.peer_id)
        for hook in app.registry.pre_message:
            if await hook(app, inc, chat):
                return
    elif not user['kb_cleared']:
        await app.vk.clear_reply_keyboard(
            inc.peer_id, '🔄 Интерфейс обновлён: теперь все кнопки находятся под сообщениями бота.')
        await app.db.execute('UPDATE users SET kb_cleared=1 WHERE id=$1', inc.from_id)

    cmd, args = parse_command(app.registry, text, is_chat)

    ctx = Ctx(app, inc.peer_id, inc.from_id, args, cmid=inc.cmid, reply_from=inc.reply_from,
              fwd_from=inc.fwd_from, user_row=user)

    if cmd is None:
        pending = app.pending.pop(inc.peer_id, inc.from_id)
        if pending is not None and text.strip():
            handler = app.registry.pendings.get(pending.kind)
            if handler is not None:
                ctx.args = text.strip()
                try:
                    await handler(ctx, pending.data)
                except Exception:  # noqa: BLE001
                    log.exception('pending %s failed', pending.kind)
                    await ctx.send(ERROR_TEXT)
                return
        if not is_chat and text.strip():
            last = app.hint_notified.get(inc.from_id, 0)
            if time.time() - last > 30:
                app.hint_notified[inc.from_id] = time.time()
                kb = ctx.kb().btn('🏠 Меню', 'menu', color='primary').btn('❓ Помощь', 'help')
                await ctx.send('🤔 Не понял вас. Откройте меню или список команд:', kb)
        return

    app.pending.clear(inc.peer_id, inc.from_id)  # новая команда отменяет незавершённый ввод

    if is_chat and not chat['activated'] and cmd.key != 'start':
        return await _inactive_hint(app, ctx)
    await run_command(app, cmd, ctx)


async def _inactive_hint(app, ctx: Ctx) -> None:
    last = app.hint_notified.get(ctx.peer_id, 0)
    if time.time() - last > 120:
        app.hint_notified[ctx.peer_id] = time.time()
        kb = ctx.kb().btn('▶ Активировать бота', 'start', u=0, color='positive')
        await ctx.send(
            '⭐ Бот ещё не активирован в этой беседе.\n'
            'Выдайте боту права администратора и нажмите кнопку (или напишите /start).', kb)


async def handle_event(app, ev: ButtonEvent) -> None:
    """Нажатие inline-кнопки: payload {"c": команда, "a": аргументы, "u": кому можно нажимать}."""
    vk = app.vk
    payload = ev.payload if isinstance(ev.payload, dict) else {}
    cmd = app.registry.commands.get(payload.get('c', ''))
    owner = payload.get('u', 0)

    async def answer(text=None):
        await vk.event_answer(ev.event_id, ev.user_id, ev.peer_id, text)

    if cmd is None:
        return await answer('Эта кнопка устарела')
    if owner and owner != ev.user_id:
        return await answer('Эта кнопка предназначена не для вас')
    if app.limiter is not None and not app.limiter.allow(ev.user_id):
        return await answer('Не так быстро 🙂')

    is_chat = ev.peer_id >= CHAT_BASE
    user = await accounts.register_user(app, ev.user_id, dm=not is_chat)
    if user['banned']:
        return await answer('Ваш аккаунт заблокирован')
    if is_chat:
        chat = await chats.get_chat(app.db, ev.peer_id)
        if not chat['activated'] and cmd.key != 'start':
            return await answer('Бот не активирован в этой беседе')

    await answer()  # убираем «часики» на кнопке сразу
    app.pending.clear(ev.peer_id, ev.user_id)
    ctx = Ctx(app, ev.peer_id, ev.user_id, payload.get('a', ''), cmid=ev.cmid, via_button=True, user_row=user)
    await run_command(app, cmd, ctx)
