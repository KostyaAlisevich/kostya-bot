"""Администрирование бота: панель, пользователи, баны, должности, статистика, рассылка."""
import asyncio
import logging
import time

from ..framework.registry import registry
from ..roles import MAX_STAFF, STAFF, staff_name, staff_title
from ..services import accounts, wealth
from ..util.fmt import SEP, clip, dur, mention, num, rub

log = logging.getLogger('bot.admin')

BROADCAST_MIN_ROLE = 8
BROADCAST_BATCH = 20            # сообщений за «пачку» (лимит ВК - около 20 в секунду)
BROADCAST_DELAY = 1.0           # пауза между пачками, секунд
BROADCAST_LIMIT = 3500
DRAFT_TTL = 900

WIPE_TABLES = ('wallets', 'owned_assets', 'holdings', 'edu_progress', 'game_sessions', 'family_invites', 'transactions')


# ---------------------------------------------------------------------------
# Панель
# ---------------------------------------------------------------------------

@registry.command('admin', names=['админ', 'admin', 'панель', 'panel'], desc='панель сотрудника', section='staff', staff=1)
async def cmd_admin(ctx):
    role = await ctx.role()
    open_tickets = await ctx.db.fetchval("SELECT COUNT(*) FROM tickets WHERE status IN ('open', 'answered')")
    lines = [f'🛠 Панель сотрудника\n{SEP}', f'Ваша должность: {staff_title(role)}', f'📋 Открытых обращений: {open_tickets}', '',
             'Доступные команды: /help → кнопка вашей должности.']
    kb = ctx.kb().btn('📋 Тикеты', 'tickets', color='primary')
    if role >= 2:
        kb.btn('🔎 Пользователь', 'uinfo', color='primary')
    if role >= 3:
        kb.btn('🎁 Промокоды', 'promo_list')
    kb.row()
    if role >= 5:
        kb.btn('👥 Персонал', 'staff_list')
    if role >= 6:
        kb.btn('📊 Статистика', 'stats')
    if role >= BROADCAST_MIN_ROLE:
        kb.btn('📢 Рассылка', 'broadcast', color='positive')
    kb.row().btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# Информация о пользователе
# ---------------------------------------------------------------------------

async def _find_user(ctx, token_ctx=None):
    """Пользователь бота из аргументов команды. None - уже ответили."""
    target, _ = await ctx.target(register=False)
    if target is None:
        await ctx.respond('❗ Укажите пользователя: @имя, ссылка, id или ответом на сообщение.')
        return None
    row = await accounts.get_user(ctx.db, target)
    if row is None:
        await ctx.respond('❗ Этот пользователь ещё не пользовался ботом.')
        return None
    return row


@registry.command('uinfo', names=['инфо', 'info', 'юзер', 'user'], desc='информация о пользователе', section='staff',
                  staff=2, usage='<кому>')
async def cmd_uinfo(ctx):
    if not ctx.args.strip() and not ctx.reply_from:
        return await ctx.ask('admin_info', '🔎 Отправьте пользователя: @имя, ссылку или id', ctx.kb().btn('❌ Отмена', 'admin'))
    user = await _find_user(ctx)
    if user is None:
        return
    uid, now = user['id'], accounts.now()
    dm_wallet = await ctx.db.fetchrow('SELECT rub FROM wallets WHERE scope=0 AND user_id=$1', uid)
    capital = await wealth.net_worth(ctx.db, 0, uid) if dm_wallet else 0
    worlds = await ctx.db.fetchval('SELECT COUNT(*) FROM wallets WHERE user_id=$1', uid)
    tickets = await ctx.db.fetchval('SELECT COUNT(*) FROM tickets WHERE user_id=$1', uid)
    lines = [
        f'🔎 Пользователь\n{SEP}',
        f'{mention(uid, user["name"])} · id{uid}',
        f'🎖 Должность: {staff_title(user["role"])}',
        '🚫 Заблокирован: ' + (f'да ({user["ban_reason"] or "причина не указана"})' if user['banned'] else 'нет'),
        f'📅 В боте: {dur(now - user["created_at"])} · был(а) {dur(now - user["last_seen"])} назад',
        f'✉ Личные сообщения с ботом: {"да" if user["dm_ok"] else "нет"}',
        f'💰 Кошелёк (ЛС): {rub(dm_wallet["rub"]) if dm_wallet else "—"} · капитал {rub(capital)}',
        f'🌍 Экономик (ЛС и беседы): {worlds} · обращений: {tickets}',
    ]
    kb = ctx.kb()
    if user['banned']:
        kb.btn('♻ Разблокировать', 'gunban', str(uid), color='positive')
    elif await ctx.role() >= 3:
        kb.btn('🚫 Заблокировать', 'gban', str(uid), color='negative')
    kb.btn('🛠 Панель', 'admin')
    await ctx.respond('\n'.join(lines), kb)


@registry.pending('admin_info')
async def pending_info(ctx, data):
    if await ctx.role() >= 2:
        await cmd_uinfo(ctx)


# ---------------------------------------------------------------------------
# Блокировка аккаунта в боте
# ---------------------------------------------------------------------------

async def _guard(ctx, user) -> bool:
    """Нельзя действовать на себя и на тех, чья должность не ниже вашей."""
    if user['id'] == ctx.user_id:
        await ctx.respond('❗ Нельзя применять это к себе')
        return False
    if user['role'] >= await ctx.role():
        await ctx.respond('🚫 Должность этого пользователя не ниже вашей - действие недоступно')
        return False
    return True


@registry.command('gban', names=['гбан', 'gban', 'заблокировать'], desc='заблокировать аккаунт в боте', section='staff',
                  staff=3, usage='<кому> [причина]')
async def cmd_gban(ctx):
    arg = ctx.args.strip()
    if ctx.via_button and arg.isdigit():
        user, reason = await accounts.get_user(ctx.db, int(arg)), ''
        if user is None:
            return await ctx.respond('❗ Пользователь не найден')
    else:
        user = await _find_user(ctx)
        if user is None:
            return
        _, rest = await ctx.target(register=False)
        reason = ' '.join(rest)
    if not await _guard(ctx, user):
        return
    if user['banned']:
        return await ctx.respond('ℹ Этот пользователь уже заблокирован')
    await ctx.db.execute('UPDATE users SET banned=1, ban_reason=$2 WHERE id=$1', user['id'], reason[:200])
    await ctx.respond(f'🚫 {mention(user["id"], user["name"])} заблокирован(а) в боте'
                      + (f'\nПричина: {reason}' if reason else '')
                      + '\nОн не сможет пользоваться ботом ни в личке, ни в беседах.',
                      ctx.kb().btn('♻ Разблокировать', 'gunban', str(user['id'])))
    await ctx.app.vk.send(user['id'], '🚫 Ваш аккаунт заблокирован в боте.' + (f'\nПричина: {reason}' if reason else ''))


@registry.command('gunban', names=['гразбан', 'gunban', 'разблокировать'], desc='разблокировать аккаунт', section='staff',
                  staff=3, usage='<кому>')
async def cmd_gunban(ctx):
    arg = ctx.args.strip()
    user = await accounts.get_user(ctx.db, int(arg)) if (ctx.via_button and arg.isdigit()) else await _find_user(ctx)
    if user is None:
        return
    if not user['banned']:
        return await ctx.respond('ℹ Этот пользователь не заблокирован')
    await ctx.db.execute("UPDATE users SET banned=0, ban_reason='' WHERE id=$1", user['id'])
    await ctx.respond(f'✅ {mention(user["id"], user["name"])} разблокирован(а)')
    await ctx.app.vk.send(user['id'], '✅ Ваш аккаунт разблокирован. Добро пожаловать обратно! Напишите /меню')


# ---------------------------------------------------------------------------
# Обнуление аккаунта
# ---------------------------------------------------------------------------

async def wipe_user(db, uid: int) -> None:
    """Удаляет всю игровую экономику пользователя во всех мирах (личке и беседах)."""
    for table in WIPE_TABLES:
        await db.execute(f'DELETE FROM {table} WHERE user_id=$1', uid)
    owned = await db.fetch('SELECT id FROM families WHERE owner_id=$1', uid)
    for fam in owned:
        await db.execute('DELETE FROM family_members WHERE family_id=$1', fam['id'])
        await db.execute('DELETE FROM family_invites WHERE family_id=$1', fam['id'])
        await db.execute('DELETE FROM families WHERE id=$1', fam['id'])
    await db.execute('DELETE FROM family_members WHERE user_id=$1', uid)
    await db.execute('DELETE FROM promo_uses WHERE user_id=$1', uid)


@registry.command('wipe', names=['обнулить', 'wipe'], desc='обнулить аккаунт пользователя', section='staff', staff=4,
                  usage='<кому>')
async def cmd_wipe(ctx):
    user = await _find_user(ctx)
    if user is None or not await _guard(ctx, user):
        return
    kb = ctx.kb().btn('✅ Да, обнулить', 'wipe_do', str(user['id']), color='negative').btn('❌ Отмена', 'admin')
    await ctx.respond(f'⚠ Обнулить аккаунт {mention(user["id"], user["name"])}?\n'
                      'Будут удалены деньги, имущество, бумаги, дипломы и семьи во всех экономиках (личка и беседы). '
                      'Должность и блокировка сохранятся. Это необратимо.', kb)


@registry.command('wipe_do', desc='подтверждение обнуления', section='staff', staff=4, hidden=True)
async def cmd_wipe_do(ctx):
    arg = ctx.args.strip()
    user = await accounts.get_user(ctx.db, int(arg)) if arg.isdigit() else None
    if user is None or not await _guard(ctx, user):
        return
    async with ctx.db.transaction() as tx:
        await wipe_user(tx, user['id'])
    await ctx.respond(f'🧹 Аккаунт {mention(user["id"], user["name"])} обнулён.')


# ---------------------------------------------------------------------------
# Должности
# ---------------------------------------------------------------------------

@registry.command('setgrole', names=['должность', 'setrole', 'grole'], desc='выдать должность в боте', section='staff',
                  staff=5, usage='<кому> <0-8>')
async def cmd_setgrole(ctx):
    target, rest = await ctx.target(register=False)
    if target is None or not rest or not rest[0].isdigit():
        lines = ['❗ Формат: /должность <кому> <номер>', 'Должности:'] + [f'{k} - {v}' for k, v in STAFF.items()]
        return await ctx.respond('\n'.join(lines))
    new_role = int(rest[0])
    user = await accounts.get_user(ctx.db, target)
    if user is None:
        return await ctx.respond('❗ Этот пользователь ещё не пользовался ботом.')
    my_role = await ctx.role()
    is_owner = ctx.user_id == ctx.app.admin_id
    if new_role not in STAFF:
        return await ctx.respond('❗ Должность от 0 до 8')
    if target == ctx.user_id:
        return await ctx.respond('❗ Нельзя менять свою должность')
    if target == ctx.app.admin_id:
        return await ctx.respond('🚫 Должность основателя изменить нельзя')
    if user['role'] >= my_role and not is_owner:
        return await ctx.respond('🚫 Должность этого пользователя не ниже вашей')
    if new_role >= my_role and not is_owner:
        return await ctx.respond(f'🚫 Выдать можно только должность ниже вашей (до {my_role - 1})')
    if user['role'] == new_role:
        return await ctx.respond('ℹ У пользователя уже эта должность')
    await ctx.db.execute('UPDATE users SET role=$2 WHERE id=$1', target, new_role)
    mark = '⏫' if new_role > user['role'] else '⏬'
    await ctx.respond(f'✅ {mention(target, user["name"])}: {staff_name(user["role"])} → {staff_name(new_role)}')
    await ctx.app.vk.send(target, f'{mark} {mention(ctx.user_id, await ctx.name())} изменил(а) вашу должность в боте: '
                                  f'{staff_title(new_role)}\nКоманды вашей должности: /help')


@registry.command('staff_list', names=['должности', 'персонал'], desc='сотрудники бота', section='staff', staff=1)
async def cmd_staff_list(ctx):
    rows = await ctx.db.fetch('SELECT id, name, role FROM users WHERE role > 0 ORDER BY role DESC, id LIMIT 60')
    lines = [f'👥 Сотрудники бота\n{SEP}']
    current = None
    for r in rows:
        if r['role'] != current:
            current = r['role']
            lines.append(f'\n{staff_title(current)}')
        lines.append(f'• {mention(r["id"], r["name"])}')
    if not rows:
        lines.append('Пока никого.')
    await ctx.respond('\n'.join(lines), ctx.kb().btn('🛠 Панель', 'admin'))


# ---------------------------------------------------------------------------
# Статистика
# ---------------------------------------------------------------------------

@registry.command('stats', names=['статистика', 'stats'], desc='статистика бота', section='staff', staff=6)
async def cmd_stats(ctx):
    db = ctx.db
    now = accounts.now()
    q = db.fetchval
    users = await q('SELECT COUNT(*) FROM users')
    banned = await q('SELECT COUNT(*) FROM users WHERE banned=1')
    reachable = await q('SELECT COUNT(*) FROM users WHERE dm_ok=1 AND banned=0')
    active_day = await q('SELECT COUNT(*) FROM users WHERE last_seen > $1', now - 86400)
    staff_n = await q('SELECT COUNT(*) FROM users WHERE role > 0')
    chats_all = await q('SELECT COUNT(*) FROM chats')
    chats_on = await q('SELECT COUNT(*) FROM chats WHERE activated=1')
    wallets = await q('SELECT COUNT(*) FROM wallets')
    money = await q('SELECT CAST(COALESCE(SUM(rub), 0) AS BIGINT) FROM wallets')
    tx_day = await q('SELECT COUNT(*) FROM transactions WHERE ts > $1', now - 86400)
    tickets = await q("SELECT COUNT(*) FROM tickets WHERE status IN ('open', 'answered')")
    promos = await q('SELECT COUNT(*) FROM promo_codes')
    lines = [
        f'📊 Статистика бота\n{SEP}',
        f'👥 Пользователей: {num(users)} (за сутки: {num(active_day)}, заблокировано: {num(banned)})',
        f'✉ Доступны для рассылки: {num(reachable)}',
        f'🎖 Сотрудников: {num(staff_n)}',
        f'💬 Бесед: {num(chats_all)} (активных: {num(chats_on)})',
        f'💰 Кошельков: {num(wallets)} · рублей в обороте: {rub(money)}',
        f'🧾 Операций за сутки: {num(tx_day)}',
        f'📋 Открытых обращений: {num(tickets)} · промокодов: {num(promos)}',
    ]
    await ctx.respond('\n'.join(lines), ctx.kb().btn('🔄 Обновить', 'stats').btn('🛠 Панель', 'admin'))


# ---------------------------------------------------------------------------
# Рассылка от основателя
# ---------------------------------------------------------------------------

def broadcast_text(app, sender_id: int, text: str) -> str:
    """Текст рассылки с подписью; слово «Основателя» - кликабельная ссылка на профиль основателя."""
    founder = app.admin_id or sender_id
    return f'{text}\n\n📢 Это рассылка от {mention(founder, "Основателя")}'


async def recipients(db) -> list[int]:
    rows = await db.fetch('SELECT id FROM users WHERE dm_ok=1 AND banned=0 ORDER BY id')
    return [r['id'] for r in rows]


@registry.command('broadcast', names=['рассылка', 'broadcast'], desc='рассылка всем пользователям от основателя',
                  section='staff', staff=BROADCAST_MIN_ROLE, usage='<текст>')
async def cmd_broadcast(ctx):
    text = ctx.args.strip()
    if not text:
        return await ctx.ask(
            'broadcast_text',
            f'📢 Рассылка\n{SEP}\nОтправьте текст рассылки следующим сообщением. Я покажу предпросмотр, и вы подтвердите отправку.\n'
            'Сообщение получат все зарегистрированные в боте пользователи.',
            ctx.kb().btn('❌ Отмена', 'admin'))
    await _preview(ctx, text)


@registry.pending('broadcast_text')
async def pending_broadcast(ctx, data):
    if await ctx.role() >= BROADCAST_MIN_ROLE and ctx.args.strip():
        await _preview(ctx, ctx.args)


async def _preview(ctx, text: str):
    text = text.strip()
    if len(text) > BROADCAST_LIMIT:
        return await ctx.respond(f'❗ Слишком длинный текст: максимум {BROADCAST_LIMIT} символов')
    count = len(await recipients(ctx.db))
    ctx.app.drafts[ctx.user_id] = (text, time.time())
    kb = (ctx.kb().btn(f'✅ Отправить ({count})', 'broadcast_send', color='positive')
          .btn('❌ Отмена', 'broadcast_cancel', color='negative'))
    await ctx.respond(f'📢 Предпросмотр рассылки\n{SEP}\n{broadcast_text(ctx.app, ctx.user_id, text)}\n{SEP}\n'
                      f'Получателей: {count}. Отправить?', kb)


@registry.command('broadcast_cancel', desc='отмена рассылки', section='staff', staff=BROADCAST_MIN_ROLE, hidden=True)
async def cmd_broadcast_cancel(ctx):
    ctx.app.drafts.pop(ctx.user_id, None)
    await ctx.respond('❌ Рассылка отменена', ctx.kb().btn('🛠 Панель', 'admin'))


@registry.command('broadcast_send', desc='отправка рассылки', section='staff', staff=BROADCAST_MIN_ROLE, hidden=True)
async def cmd_broadcast_send(ctx):
    draft = ctx.app.drafts.pop(ctx.user_id, None)
    if draft is None or time.time() - draft[1] > DRAFT_TTL:
        return await ctx.respond('⌛ Черновик устарел. Введите текст заново: /рассылка',
                                 ctx.kb().btn('📢 Заново', 'broadcast'))
    text = broadcast_text(ctx.app, ctx.user_id, draft[0])
    ids = await recipients(ctx.db)
    await ctx.respond(f'🚀 Рассылка запущена: получателей {len(ids)}. Я сообщу, когда всё будет отправлено.')
    task = asyncio.create_task(_run_broadcast(ctx.app, ctx.user_id, ctx.peer_id, text, ids))
    ctx.app.tasks.add(task)
    task.add_done_callback(ctx.app.tasks.discard)


async def _run_broadcast(app, sender: int, report_peer: int, text: str, ids: list[int]) -> None:
    delivered = failed = 0
    started = time.time()
    try:
        for i in range(0, len(ids), BROADCAST_BATCH):
            batch = ids[i:i + BROADCAST_BATCH]
            results = await asyncio.gather(*[app.vk.send(uid, text) for uid in batch], return_exceptions=True)
            for res in results:
                if res is True:
                    delivered += 1
                else:
                    failed += 1
            if i + BROADCAST_BATCH < len(ids) and BROADCAST_DELAY:
                await asyncio.sleep(BROADCAST_DELAY)
    except Exception:  # noqa: BLE001
        log.exception('broadcast crashed')
    await app.vk.send(
        report_peer,
        f'✅ Рассылка завершена за {dur(time.time() - started)}\nДоставлено: {delivered}\nНе доставлено: {failed}\n'
        f'(не доставлено - тем, кто закрыл личные сообщения сообществу)')
