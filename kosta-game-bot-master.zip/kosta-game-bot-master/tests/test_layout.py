"""Раскладка кнопок: подписи не обрезаются, лимиты ВК соблюдены на всех экранах бота."""
import asyncio

import crawl_layout
from app.data.assets import ITEMS
from app.data.clans import CLAN_ITEMS
from app.data.education import EDUCATIONS
from app.data.jobs import JOBS
from app.data.market import TRADABLE
from app.framework.keyboards import CAP, label_width

# --- подписи из каталогов: одна кнопка в ряду (до 28 знаков), у предметов добавляется «✅ » = 3 знака ---
for item in ITEMS:
    assert label_width(f'✅ {item.title}') <= CAP[1] and label_width(f'{item.emoji} {item.title}') <= CAP[1], item.title
for job in JOBS:
    assert label_width(f'{job.emoji} {job.title}') <= CAP[1], job.title
for edu in EDUCATIONS:
    assert label_width(f'{edu.emoji} {edu.title}') <= CAP[1], edu.title
for it in CLAN_ITEMS:
    assert label_width(f'{it.emoji} {it.title}') <= CAP[1], it.title
for tk in TRADABLE:
    assert label_width(f'{tk.emoji} {tk.symbol}') <= CAP[2]
print('OK  подписи всех каталогов (имущество, работы, образование, предметы клана) помещаются в кнопку')

# --- обход всех экранов: нажимаем все достижимые кнопки ---
problems, presses = asyncio.run(crawl_layout.crawl())
assert not problems, '\n'.join(f'{k}: {v}' for k, v in list(problems.items())[:5])
assert presses > 800
print(f'OK  обход бота: нажато {presses} кнопок, ни одной обрезанной подписи, лимиты ВК (10 кнопок, 6 рядов) не нарушены')
