"""Общая очистка данных игрока (используется при обнулении экономики и аккаунта)."""


async def dissolve_clan(db, clan_id: int) -> None:
    await db.execute('DELETE FROM clan_members WHERE clan_id=$1', clan_id)
    await db.execute('DELETE FROM clan_invites WHERE clan_id=$1', clan_id)
    await db.execute('DELETE FROM clan_items WHERE clan_id=$1', clan_id)
    await db.execute('DELETE FROM clans WHERE id=$1', clan_id)


async def leave_clans(db, uid: int, scope: int | None = None) -> None:
    """Убирает игрока из кланов (в одном scope или во всех). Если он глава - клан распускается."""
    if scope is None:
        rows = await db.fetch('SELECT clan_id, role FROM clan_members WHERE user_id=$1', uid)
        await db.execute('DELETE FROM clan_invites WHERE user_id=$1', uid)
    else:
        rows = await db.fetch('SELECT clan_id, role FROM clan_members WHERE user_id=$1 AND scope=$2', uid, scope)
        await db.execute('DELETE FROM clan_invites WHERE user_id=$1 AND scope=$2', uid, scope)
    for r in rows:
        if r['role'] == 'leader':
            await dissolve_clan(db, r['clan_id'])
        elif scope is None:
            await db.execute('DELETE FROM clan_members WHERE user_id=$1 AND clan_id=$2', uid, r['clan_id'])
        else:
            await db.execute('DELETE FROM clan_members WHERE user_id=$1 AND clan_id=$2 AND scope=$3', uid, r['clan_id'], scope)
