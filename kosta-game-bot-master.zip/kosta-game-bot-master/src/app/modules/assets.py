"""Бизнес и имущество: магазин, покупки и сбор доходов (бизнесы, аренда домов, майнинг)."""
from ..data.assets import (
    BUSINESS_CATEGORIES, CATEGORIES, CATEGORIES_BY_KEY, INCOME_KIND, ITEMS_BY_CATEGORY, ITEMS_BY_KEY,
    PROPERTY_CATEGORIES,
)
from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, dur, rub
from ..util.pages import paginate

PAGE_SIZE = 4
KIND_TITLES = {'business': '🏢 Бизнесы', 'rent': '🏠 Аренда', 'mining': '⛏ Майнинг'}


class _Stop(Exception):
    pass


def accrued(item, collected_at: int, now: int) -> int:
    return item.income_per_hour * max(0, now - collected_at) // 3600


async def get_owned(db, scope: int, uid: int) -> dict[str, int]:
    """{ключ предмета: момент последнего сбора}."""
    rows = await db.fetch('SELECT item_key, collected_at FROM owned_assets WHERE scope=$1 AND user_id=$2', scope, uid)
    return {r['item_key']: r['collected_at'] for r in rows if r['item_key'] in ITEMS_BY_KEY}


async def buy_item(db, scope: int, uid: int, item) -> str:
    """'ok' | 'already' | 'money'. Запись и списание денег - в одной транзакции."""
    t = accounts.now()
    try:
        async with db.transaction() as tx:
            ins = await tx.fetchrow(
                'INSERT INTO owned_assets (scope, user_id, item_key, bought_at, collected_at) '
                'VALUES ($1, $2, $3, $4, $4) ON CONFLICT (scope, user_id, item_key) DO NOTHING RETURNING item_key',
                scope, uid, item.key, t)
            if ins is None:
                return 'already'
            if await accounts.change(tx, scope, uid, -item.price, 'rub', 'asset_buy', item.title) is None:
                raise _Stop
    except _Stop:
        return 'money'
    return 'ok'


async def collect_income(db, scope: int, uid: int) -> dict[str, int]:
    """Забирает накопленный доход. Возвращает {'business': ₽, 'rent': ₽, 'mining': ₽, 'tax': ₽, 'net': ₽}."""
    t = accounts.now()
    owned = await get_owned(db, scope, uid)
    gross = {'business': 0, 'rent': 0, 'mining': 0}
    for key, collected_at in owned.items():
        item = ITEMS_BY_KEY[key]
        if not item.income_per_hour:
            continue
        amount = accrued(item, collected_at, t)
        if amount <= 0:
            continue  # время не трогаем: доли секунды не теряются
        claimed = await db.fetchrow(
            'UPDATE owned_assets SET collected_at=$4 WHERE scope=$1 AND user_id=$2 AND item_key=$3 '
            'AND collected_at=$5 RETURNING item_key', scope, uid, key, t, collected_at)
        if claimed is not None:
            gross[INCOME_KIND[item.category]] += amount
    total = sum(gross.values())
    result = dict(gross, tax=0, net=0)
    if total:
        async with db.transaction() as tx:
            net, tax = await accounts.apply_tax(tx, scope, total)
            await accounts.change(tx, scope, uid, net, 'rub', 'collect', 'доходы')
        result.update(tax=tax, net=net)
    return result


def _income_per_hour(owned: dict) -> dict[str, int]:
    out = {'business': 0, 'rent': 0, 'mining': 0}
    for key in owned:
        item = ITEMS_BY_KEY[key]
        if item.income_per_hour:
            out[INCOME_KIND[item.category]] += item.income_per_hour
    return out


def _ready(owned: dict, now: int) -> int:
    return sum(accrued(ITEMS_BY_KEY[k], ts, now) for k, ts in owned.items())


# ---------------------------------------------------------------------------
# /бизнес
# ---------------------------------------------------------------------------

@registry.command('biz', names=['бизнес', 'бизнесы', 'biz', 'business'], desc='бизнесы', section='business')
async def cmd_biz(ctx):
    await ctx.wallet()
    owned = await get_owned(ctx.db, ctx.scope, ctx.user_id)
    now = accounts.now()
    per_hour = _income_per_hour(owned)
    lines = [f'🏢 Бизнес\n{SEP}']
    mine = [k for k in owned if ITEMS_BY_KEY[k].category in BUSINESS_CATEGORIES]
    if mine:
        for key in mine:
            item = ITEMS_BY_KEY[key]
            lines.append(f'{item.emoji} {item.title} - накоплено {rub(accrued(item, owned[key], now))} '
                         f'({rub(item.income_per_hour)}/ч)')
    else:
        lines.append('У вас пока нет бизнесов и майнинг-ферм. Купите первый - это пассивный доход!')
    lines += ['',
              f'📈 Доход в час: бизнесы {rub(per_hour["business"])} · аренда {rub(per_hour["rent"])} · '
              f'майнинг {rub(per_hour["mining"])}',
              f'💰 Готово к сбору: {rub(_ready(owned, now))}']
    kb = (ctx.kb()
          .btn('🏢 Бизнесы', 'shop', 'business', color='primary').btn('💻 Майнинг', 'shop', 'gpu').row()
          .btn('💰 Собрать', 'collect', color='positive').btn('🏠 Имущество', 'prop').btn('🏠 Меню', 'menu'))
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# /имущество
# ---------------------------------------------------------------------------

@registry.command('prop', names=['имущество', 'property'], desc='имущество', section='business')
async def cmd_prop(ctx):
    await ctx.wallet()
    owned = await get_owned(ctx.db, ctx.scope, ctx.user_id)
    now = accounts.now()
    value = sum(ITEMS_BY_KEY[k].price for k in owned)
    lines = [f'🎒 Моё имущество\n{SEP}', f'💎 Общая стоимость: {rub(value)}', '']
    if not owned:
        lines.append('Пока ничего нет. Загляните в разделы кнопками ниже.')
    for cat in CATEGORIES:
        items = [i for i in ITEMS_BY_CATEGORY[cat.key] if i.key in owned]
        if not items:
            continue
        lines.append(f'{cat.emoji} {cat.title}:')
        for i in items:
            extra = f' - накоплено {rub(accrued(i, owned[i.key], now))}' if i.income_per_hour else ''
            lines.append(f'{i.emoji} {i.title}{extra}')
        lines.append('')
    if _ready(owned, now):
        lines.append(f'💰 Готово к сбору: {rub(_ready(owned, now))}')
    kb = (ctx.kb()
          .btn('🏠 Дома', 'shop', 'house').btn('✈ Самолёты', 'shop', 'plane').btn('🚁 Вертолёты', 'shop', 'helicopter').row()
          .btn('🚗 Машины', 'shop', 'car').btn('⛵ Лодки', 'shop', 'boat').btn('💰 Собрать', 'collect', color='positive').row()
          .btn('🏢 Бизнес', 'biz').btn('🏠 Меню', 'menu'))
    await ctx.respond('\n'.join(lines).rstrip(), kb)


# ---------------------------------------------------------------------------
# /собрать
# ---------------------------------------------------------------------------

@registry.command('collect', names=['собрать', 'collect'], desc='забрать доходы бизнесов, аренды и майнинга',
                  section='business')
async def cmd_collect(ctx):
    await ctx.wallet()
    owned = await get_owned(ctx.db, ctx.scope, ctx.user_id)
    kb = ctx.kb().btn('🏢 Бизнес', 'biz').btn('🏠 Меню', 'menu')
    if not any(ITEMS_BY_KEY[k].income_per_hour for k in owned):
        return await ctx.respond('ℹ У вас нет источников дохода. Купите бизнес, дом для аренды или майнинг-карту.',
                                 ctx.kb().btn('🏢 Бизнесы', 'shop', 'business', color='primary').btn('🏠 Меню', 'menu'))
    res = await collect_income(ctx.db, ctx.scope, ctx.user_id)
    if not (res['business'] or res['rent'] or res['mining']):
        return await ctx.respond('😕 Пока нечего собирать: доход ещё не накопился.', kb.btn('🔄 Проверить', 'collect'))
    lines = [f'💰 Доходы собраны\n{SEP}']
    for kind in ('business', 'rent', 'mining'):
        if res[kind]:
            lines.append(f'{KIND_TITLES[kind]}: +{rub(res[kind])}')
    if res['tax']:
        lines.append(f'🏛 Налог в казну беседы: −{rub(res["tax"])}')
    lines.append(f'✅ Получено: {rub(res["net"])}')
    lines.append(f'💳 Баланс: {rub((await ctx.wallet())["rub"])}')
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# Магазин (служебные команды для кнопок)
# ---------------------------------------------------------------------------

def _back_cmd(category: str) -> tuple[str, str]:
    return ('biz', '🏢 Бизнес') if category in BUSINESS_CATEGORIES else ('prop', '🎒 Имущество')


@registry.command('shop', desc='магазин имущества', hidden=True)
async def cmd_shop(ctx):
    argv = ctx.argv
    if not argv or argv[0] not in CATEGORIES_BY_KEY:
        return await cmd_biz(ctx)
    cat = CATEGORIES_BY_KEY[argv[0]]
    page = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else 0
    owned = await get_owned(ctx.db, ctx.scope, ctx.user_id)
    items, page, total = paginate(ITEMS_BY_CATEGORY[cat.key], page, PAGE_SIZE)
    lines = [f'{cat.emoji} {cat.title} | стр. {page + 1}/{total}\n{SEP}', cat.intro, '']
    for it in items:
        mark = ' ✅ куплено' if it.key in owned else ''
        lines.append(f'{it.emoji} {it.title} - {rub(it.price)}{mark}')
        if it.income_per_hour:
            lines.append(f'    📈 {rub(it.income_per_hour)} в час')
    wallet = await ctx.wallet()
    lines.append(f'\n💳 Ваш баланс: {rub(wallet["rub"])}')
    kb = ctx.kb()
    for i, it in enumerate(items):
        if i and i % 2 == 0:
            kb.row()
        label = f'✅ {it.title}' if it.key in owned else f'{it.emoji} {it.title}'
        kb.btn(label, 'asset', it.key)
    kb.row()
    if page > 0:
        kb.btn('◀', 'shop', f'{cat.key} {page - 1}')
    if page < total - 1:
        kb.btn('▶', 'shop', f'{cat.key} {page + 1}')
    back, label = _back_cmd(cat.key)
    kb.btn(label, back)
    await ctx.respond('\n'.join(lines), kb)


@registry.command('asset', desc='карточка предмета', hidden=True)
async def cmd_asset(ctx):
    item = ITEMS_BY_KEY.get(ctx.args.strip())
    if item is None:
        return await cmd_biz(ctx)
    wallet = await ctx.wallet()
    owned = await get_owned(ctx.db, ctx.scope, ctx.user_id)
    lines = [f'{item.emoji} {item.title}\n{SEP}', item.description, '', f'💵 Цена: {rub(item.price)}']
    if item.income_per_hour:
        label = {'rent': 'Аренда', 'mining': 'Майнинг'}.get(INCOME_KIND[item.category], 'Доход')
        payback = -(-item.price // item.income_per_hour)
        lines.append(f'📈 {label}: {rub(item.income_per_hour)} в час')
        lines.append(f'⏳ Окупится примерно за {dur(payback * 3600)}')
    lines.append(f'💳 Ваш баланс: {rub(wallet["rub"])}')
    lines.append('')
    if item.key in owned:
        lines.append('✅ Это у вас уже есть')
    elif wallet['rub'] < item.price:
        lines.append(f'❗ Не хватает {rub(item.price - wallet["rub"])}')
    kb = ctx.kb()
    if item.key not in owned:
        kb.btn(f'✅ Купить за {rub(item.price)}', 'abuy', item.key, color='positive').row()
    kb.btn('◀ К списку', 'shop', item.category).btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines).rstrip(), kb)


@registry.command('abuy', desc='покупка предмета', hidden=True)
async def cmd_abuy(ctx):
    item = ITEMS_BY_KEY.get(ctx.args.strip())
    if item is None:
        return await cmd_biz(ctx)
    await ctx.wallet()
    status = await buy_item(ctx.db, ctx.scope, ctx.user_id, item)
    if status == 'ok':
        extra = '\n📈 Доход копится каждый час - забирайте его командой /собрать.' if item.income_per_hour else ''
        kb = ctx.kb().btn('◀ К списку', 'shop', item.category).btn('💰 Собрать', 'collect').btn('🏠 Меню', 'menu')
        return await ctx.respond(f'🥳 Вы приобрели {item.emoji} {item.title} за {rub(item.price)}!{extra}', kb)
    if status == 'already':
        return await cmd_asset(ctx)
    wallet = await ctx.wallet()
    await ctx.respond(
        f'❗ Недостаточно средств: нужно {rub(item.price)}, у вас {rub(wallet["rub"])}',
        ctx.kb().btn('💼 Заработать', 'jobs').btn('◀ К списку', 'shop', item.category))
