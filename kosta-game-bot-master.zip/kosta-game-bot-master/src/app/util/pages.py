import math


def paginate(items, page: int, size: int = 4):
    """Возвращает (элементы страницы, номер страницы с поправкой на границы, всего страниц)."""
    total = max(1, math.ceil(len(items) / size))
    page = min(max(page, 0), total - 1)
    return items[page * size:(page + 1) * size], page, total


def find_ref(items, ref: str, key_attr: str = 'key', title_attr: str = 'title'):
    """Находит элемент по номеру в списке (1..N), ключу или началу названия (без учёта регистра и ё)."""
    ref = (ref or '').strip().lower().replace('ё', 'е')
    if not ref:
        return None
    if ref.isdigit() and 1 <= int(ref) <= len(items):
        return items[int(ref) - 1]
    for item in items:
        if getattr(item, key_attr).lower() == ref:
            return item
    matches = [i for i in items if getattr(i, title_attr).lower().replace('ё', 'е').startswith(ref)]
    if not matches:
        matches = [i for i in items if ref in getattr(i, title_attr).lower().replace('ё', 'е')]
    return matches[0] if len(matches) == 1 else None
