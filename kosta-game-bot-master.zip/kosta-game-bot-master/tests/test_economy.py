import asyncio
from sim import Sim, OWNER, CHAT_BASE

CHAT = CHAT_BASE + 7


async def main():
    s = await Sim.create()
    await s.say(1, '/start'); await s.say(2, '/start')

    # ===== кошелёк =====
    m = await s.last(1, '/кошелёк')
    assert '5 000 ₽' in m.text and '$0.00' in m.text and 'не работаете' in m.text and 'Капитал: 5 000 ₽' in m.text
    for alias in ('/эко', '/eco', '/wallet', '/финансы', '/баланс', '/кошелек'):
        assert 'Кошелёк' in (await s.last(1, alias)).text, alias
    print('OK  кошелёк и все псевдонимы (/эко /eco /wallet /финансы /кошелек)')

    # ===== курс и справка =====
    m = await s.last(1, '/курс')
    assert 'Доллар: 90 ₽' in m.text and 'BTC' in m.text and m.find('Обмен')
    for alias in ('/курсы', '/rates'):
        assert 'Курсы валют' in (await s.last(1, alias)).text
    assert 'Экономика бота' in (await s.last(1, '/экономика')).text
    assert 'Экономика бота' in (await s.last(1, '/экопомощь')).text
    print('OK  /курс, /курсы, /rates, /экономика, /экопомощь')

    # ===== обмен: кнопками =====
    m = await s.last(1, '/обмен')
    assert 'Обмен валют' in m.text and len(m.buttons()) == 7
    r = await s.press(1, '₽→$ 1 000')
    assert 'Обмен выполнен' in r.text and '$11.00' in r.text, r.text      # 1000 / (90*1.01) = 11.00
    w = await s.wallet(1)
    assert (w['rub'], w['usd']) == (4000, 1100), dict(w)
    # обратно: все доллары -> рубли по курсу продажи (90*0.99=89.1): 11 * 89.1 = 980
    r = await s.last(1, '/обмен все usd руб')
    w = await s.wallet(1)
    assert (w['usd'], w['rub']) == (0, 4000 + 980), dict(w)
    print('OK  обмен: кнопка ₽→$, обратный обмен по курсу продажи со спредом 1%')

    # обмен текстом, евро, ошибки
    await s.say(1, '/обмен 2000 руб eur')
    w = await s.wallet(1)
    assert w['eur'] == int(2000 * 100 / (98 * 1.01)) and w['rub'] == 4980 - 2000
    m = await s.last(1, '/обмен 100 евро usd')
    assert 'Обмен выполнен' in m.text or 'Недостаточно' in m.text
    assert 'Недостаточно средств' in (await s.last(1, '/обмен 999999 руб usd')).text
    assert 'во что менять' in (await s.last(1, '/обмен 100 руб')).text.lower() or 'Укажите' in (await s.last(1, '/обмен 100 руб')).text
    assert 'слишком мала' in (await s.last(1, '/обмен 0.01 usd руб')).text
    print('OK  обмен текстом, евро, недостаточно средств, слишком маленькая сумма')

    # ===== переводы (личные сообщения) =====
    s.vk.screen['ivan'] = 2
    await s.db.execute('UPDATE wallets SET rub=5000 WHERE scope=0 AND user_id=1')
    ev = await s.say(1, '/передать @ivan 500')
    assert 'перевёл(а)' in ev[0].text and '500 ₽' in ev[0].text
    assert any(e.peer == 2 and 'Вам перевели 500 ₽' in e.text for e in ev), 'получатель в личке получает уведомление'
    assert (await s.wallet(1))['rub'] == 4500 and (await s.wallet(2))['rub'] == 5500
    await s.say(1, '/отправить 2 100'); assert (await s.wallet(2))['rub'] == 5600      # по id (одна цифра - считается id)
    await s.say(1, '/send https://vk.com/ivan 10$')                                    # доллары: нет долларов
    assert (await s.wallet(2))['usd'] == 0
    await s.db.execute('UPDATE wallets SET usd=5000 WHERE scope=0 AND user_id=1')
    await s.say(1, '/send https://vk.com/ivan 10$')
    assert (await s.wallet(1))['usd'] == 4000 and (await s.wallet(2))['usd'] == 1000
    for bad, text in (('/передать @ivan 99999999', 'Недостаточно средств'), ('/передать @1 5', 'самому себе'),
                      ('/передать @ivan', 'Не удалось разобрать'), ('/передать @nobody 5', 'Не удалось разобрать')):
        assert text in (await s.last(1, bad)).text, bad
    print('OK  переводы по @имени/id/ссылке, рубли и доллары, уведомление получателю, ошибки')

    # ===== беседа: отдельная экономика, перевод ответом =====
    await s.make_chat(CHAT, creator=10, members=(1, 2))
    await s.say(1, '/кошелёк', peer=CHAT)
    assert (await s.wallet(1, CHAT))['rub'] == 5000, 'в беседе свой кошелёк со стартовой суммой'
    dm_before = (await s.wallet(1))['rub']
    ev = await s.say(1, '/передать 700', peer=CHAT, reply_from=2)
    assert 'перевёл(а)' in ev[-1].text
    assert (await s.wallet(1, CHAT))['rub'] == 4300 and (await s.wallet(2, CHAT))['rub'] == 5700
    assert (await s.wallet(1))['rub'] == dm_before, 'перевод в беседе не затрагивает личный кошелёк'
    assert not any(e.peer == 2 for e in ev), 'в беседе получателю в личку не пишем'
    m = await s.last(1, '/кошелёк', peer=CHAT)
    assert '4 300 ₽' in m.text and 'Экономика: беседа' in m.text
    print('OK  в беседе отдельный кошелёк; перевод ответом на сообщение; личный баланс не меняется')

    # автоматическая регистрация получателя, который ещё не писал боту
    ev = await s.say(1, '/передать 77777777 100', peer=CHAT)
    assert 'перевёл(а)' in ev[-1].text and (await s.wallet(77777777, CHAT))['rub'] == 5100
    s.vk.auto_users = False
    assert 'Не удалось разобрать' in (await s.last(1, '/передать 88888888 100', peer=CHAT)).text
    s.vk.auto_users = True
    print('OK  получатель, которого нет в базе, регистрируется автоматически (если это реальный аккаунт ВК)')

    # ===== операции =====
    m = await s.last(1, '/операции')
    assert 'Ваши операции' in m.text and 'Перевод отправлен' in m.text and 'Обмен валют' in m.text
    for i in range(10):
        await s.say(1, '/передать @ivan 1')
    m = await s.last(1, '/ops')
    assert 'стр. 1/' in m.text and m.find('▶')
    m2 = await s.press(1, '▶')
    assert 'стр. 2/' in m2.text and m2.find('◀') and m2 is m
    print('OK  /операции: список и страницы')

    # ===== форбс =====
    await s.db.execute('UPDATE wallets SET rub=10000000 WHERE scope=0 AND user_id=2')
    m = await s.last(1, '/форбс')
    assert 'Форбс' in m.text and '🥇 [id2|Юзер2]' in m.text and '10' in m.text
    assert '[id1|Юзер1]' in m.text
    print('OK  /форбс: рейтинг богачей')

    print('\nВсе тесты economy пройдены')

asyncio.run(main())
