"""Обход всех экранов бота кнопками: собирает нарушения раскладки (обрезаемые подписи, >10 кнопок, >6 рядов).

Запуск: python tests/crawl_layout.py            - печатает список проблем
В тестах: crawl() возвращает список проблем (должен быть пустым).
"""
import asyncio
import json
import sys

import sim
from sim import CHAT_BASE, OWNER, Sim
from app.framework.keyboards import CAP, KB, label_width
from app.framework.registry import registry

CHAT = CHAT_BASE + 77


async def crawl(max_presses: int = 4000, verbose: bool = False):
    problems: dict[str, str] = {}

    def collect(m):
        if not m.kb:
            return
        rows = m.kb['buttons']
        total = sum(len(r) for r in rows)
        if len(rows) > 6 or total > 10:
            problems[f'размер: {total} кнопок, {len(rows)} рядов'] = ' | '.join(m.labels())
        for row in rows:
            for b in row:
                label = b['action']['label']
                if label_width(label) > CAP[len(row)]:
                    problems[f'обрезка: «{label}» ({len(row)} в ряду)'] = ' | '.join(m.labels())

    sim.check_kb = collect
    Sim.strict_kb = False
    s = await Sim.create()
    for uid in (OWNER, 2, 3):
        await s.say(uid, '/start')
    await s.give(OWNER, rub=10**9); await s.give(2, rub=10**7); await s.give(3, rub=10**7)
    await s.make_chat(CHAT, creator=OWNER, members=(2, 3))
    for peer in (OWNER, CHAT):
        await s.give(OWNER, rub=10**9, scope=0 if peer == OWNER else CHAT)

    seen_payloads: set = set()
    queue: list = []

    def enqueue(uid, peer, msg):
        if msg is not None and msg.kb:
            queue.append((uid, peer, msg))

    # стартовые экраны: все команды без аргументов в личке и в беседе
    for cmd in list(registry.commands.values()):
        for uid, peer in ((OWNER, OWNER), (OWNER, CHAT), (2, CHAT)):
            if cmd.names:
                events = await s.say(uid, f'/{cmd.names[0]}', peer=peer)
            else:
                events = [await s.cb(uid, cmd.key, '', peer=peer)]
            for kind, detail in KB.problems:
                problems[f'{kind}: {detail[:60]}'] = detail
            for e in events:
                enqueue(uid, peer, e)

    presses = 0
    while queue and presses < max_presses:
        uid, peer, msg = queue.pop(0)
        for b in msg.buttons():
            key = (uid, peer, b['action']['payload'])
            if key in seen_payloads:
                continue
            seen_payloads.add(key)
            presses += 1
            payload = json.loads(b['action']['payload'])
            if payload.get('u') not in (None, 0, uid):
                continue
            result = await s.cb(uid, payload['c'], payload.get('a', ''), peer=peer)
            for kind, detail in KB.problems:
                problems[f'{kind}: {detail[:60]}'] = detail
            enqueue(uid, peer, result)
            if presses >= max_presses:
                break
    if verbose:
        print(f'нажато кнопок: {presses}, экранов с проблемами: {len(problems)}')
    return problems, presses


if __name__ == '__main__':
    problems, presses = asyncio.run(crawl(verbose=True))
    for k, v in sorted(problems.items()):
        print(f'- {k}\n    {v}')
    sys.exit(1 if problems else 0)
