"""Семья: общий бюджет, приглашения, состав."""
from ..framework.registry import registry
from ..services import accounts, wealth
from ..util.fmt import SEP, mention, rub
from ..util.money import _value

FAMILY_COST = 5_000
MAX_MEMBERS = 10
MAX_NAME = 24


class _Stop(Exception):
    pass


async def get_family(db, scope: int, uid: int):
    return await db.fetchrow(
        'SELECT f.* FROM family_members m JOIN families f ON f.id = m.family_id '
        'WHERE m.scope=$1 AND m.user_id=$2', scope, uid)


async def family_members(db, family_id: int) -> list[int]:
    rows = await db.fetch('SELECT user_id FROM family_members WHERE family_id=$1 ORDER BY user_id', family_id)
    return [r['user_id'] for r in rows]


def _clean_name(raw: str) -> str:
    name = ' '.join(raw.replace('[', '').replace(']', '').replace('|', '').replace('«', '').replace('»', '').split())
    return name[:MAX_NAME]


# ---------------------------------------------------------------------------
# /семья
# ---------------------------------------------------------------------------

@registry.command('family', names=['семья', 'family'], desc='семья и общий бюджет', section='family',
                  usage='[создать|пригласить|выйти ...]')
async def cmd_family(ctx):
    argv = ctx.argv
    sub = argv[0].lower().replace('ё', 'е') if argv else ''
    await ctx.wallet()
    if sub in ('создать', 'create'):
        return await _create(ctx, ' '.join(argv[1:]))
    if sub in ('принять', 'accept'):
        return await _accept(ctx)
    if sub in ('выйти', 'leave'):
        return await _leave(ctx)
    if sub in ('распустить', 'disband'):
        return await _disband(ctx)
    if sub in ('пригласить', 'invite'):
        ctx.args = ' '.join(argv[1:])
        return await _invite(ctx)
    if sub in ('исключить', 'kick'):
        ctx.args = ' '.join(argv[1:])
        return await _kick(ctx)
    if sub in ('состав', 'members'):
        return await _show(ctx, members_only=True)
    await _show(ctx)


async def _show(ctx, intro: str = '', members_only: bool = False):
    fam = await get_family(ctx.db, ctx.scope, ctx.user_id)
    if fam is None:
        invite = await ctx.db.fetchrow(
            'SELECT i.*, f.name FROM family_invites i JOIN families f ON f.id = i.family_id '
            'WHERE i.scope=$1 AND i.user_id=$2', ctx.scope, ctx.user_id)
        lines = [f'{intro}👨‍👩‍👧 Семья\n{SEP}', 'У вас пока нет семьи.',
                 f'Создать: /семья создать <название> (стоит {rub(FAMILY_COST)})',
                 'Или попросите владельца семьи пригласить вас: /семья пригласить @вы']
        kb = ctx.kb()
        if invite:
            lines.append(f'\n💌 Вас пригласили в семью «{invite["name"]}»!')
            kb.btn('✅ Принять приглашение', 'family', 'принять', color='positive').row()
        kb.btn('🏆 Форбс', 'forbes').btn('🏠 Меню', 'menu')
        return await ctx.respond('\n'.join(lines), kb)

    ids = await family_members(ctx.db, fam['id'])
    wm = await wealth.wealth_map(ctx.db, ctx.scope, ids)
    lines = [f'{intro}👨‍👩‍👧 Семья «{fam["name"]}»\n{SEP}',
             f'👑 Глава: {mention(fam["owner_id"], await accounts.display_name(ctx.app, fam["owner_id"]))}',
             f'💰 Бюджет: {rub(fam["budget"])}',
             f'💎 Богатство семьи: {rub(fam["budget"] + sum(wm.values()))}',
             f'👥 Участников: {len(ids)} из {MAX_MEMBERS}', '']
    for uid in ids:
        crown = '👑' if uid == fam['owner_id'] else '👤'
        lines.append(f'{crown} {mention(uid, await accounts.display_name(ctx.app, uid))} - {rub(wm.get(uid, 0))}')
    kb = ctx.kb().btn('💰 Бюджет', 'budget', color='primary')
    if fam['owner_id'] == ctx.user_id:
        kb.btn('➕ Пригласить', 'family', 'пригласить')
    kb.row().btn('🚪 Выйти', 'family', 'выйти', color='negative').btn('🏆 Форбс', 'forbes').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


async def _create(ctx, raw_name: str):
    name = _clean_name(raw_name)
    if len(name) < 2:
        return await ctx.respond('❗ Укажите название семьи (от 2 символов). Пример: /семья создать Ромашка')
    try:
        async with ctx.db.transaction() as tx:
            if await tx.fetchval('SELECT 1 FROM family_members WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id):
                raise _Stop('in_family')
            taken = await tx.fetch('SELECT name FROM families WHERE scope=$1', ctx.scope)
            if any(r['name'].casefold() == name.casefold() for r in taken):
                raise _Stop('taken')
            if await accounts.change(tx, ctx.scope, ctx.user_id, -FAMILY_COST, 'rub', 'family', f'семья {name}') is None:
                raise _Stop('money')
            fid = await tx.fetchval(
                'INSERT INTO families (scope, name, owner_id, created_at) VALUES ($1, $2, $3, $4) RETURNING id',
                ctx.scope, name, ctx.user_id, accounts.now())
            await tx.execute('INSERT INTO family_members (scope, user_id, family_id) VALUES ($1, $2, $3)',
                             ctx.scope, ctx.user_id, fid)
    except _Stop as stop:
        reasons = {'in_family': '❗ Вы уже состоите в семье. Сначала выйдите: /семья выйти',
                   'taken': '❗ Семья с таким названием уже есть',
                   'money': f'❗ Не хватает денег: создание семьи стоит {rub(FAMILY_COST)}'}
        return await ctx.respond(reasons[str(stop)])
    await _show(ctx, intro=f'🎉 Семья «{name}» создана!\n\n')


async def _invite(ctx):
    fam = await get_family(ctx.db, ctx.scope, ctx.user_id)
    if fam is None or fam['owner_id'] != ctx.user_id:
        return await ctx.respond('❗ Приглашать может только глава семьи')
    target, _ = await ctx.target()
    if target is None:
        return await ctx.respond('❗ Укажите, кого пригласить: /семья пригласить @имя (или ответом на сообщение)')
    if target == ctx.user_id:
        return await ctx.respond('❗ Вы уже в семье')
    if await get_family(ctx.db, ctx.scope, target):
        return await ctx.respond('❗ Этот игрок уже состоит в семье')
    if len(await family_members(ctx.db, fam['id'])) >= MAX_MEMBERS:
        return await ctx.respond(f'❗ В семье уже {MAX_MEMBERS} участников')
    await accounts.ensure_wallet(ctx.db, ctx.scope, target)
    await ctx.db.execute(
        'INSERT INTO family_invites (scope, user_id, family_id, ts) VALUES ($1, $2, $3, $4) '
        'ON CONFLICT (scope, user_id) DO UPDATE SET family_id = EXCLUDED.family_id, ts = EXCLUDED.ts',
        ctx.scope, target, fam['id'], accounts.now())
    kb = ctx.kb().btn('✅ Принять', 'family', 'принять', color='positive', u=target)
    text = (f'💌 {await ctx.mention(target)}, вас приглашают в семью «{fam["name"]}»!\n'
            'Нажмите кнопку или напишите /семья принять')
    if ctx.is_chat:
        await ctx.respond(text, kb)
    else:
        await ctx.respond(f'✅ Приглашение отправлено: {await ctx.mention(target)}')
        await ctx.app.vk.send(target, text, kb.to_json())


async def _accept(ctx):
    try:
        async with ctx.db.transaction() as tx:
            invite = await tx.fetchrow('SELECT * FROM family_invites WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
            if invite is None:
                raise _Stop('none')
            if await tx.fetchval('SELECT 1 FROM family_members WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id):
                raise _Stop('in_family')
            count = await tx.fetchval('SELECT COUNT(*) FROM family_members WHERE family_id=$1', invite['family_id'])
            if count >= MAX_MEMBERS:
                raise _Stop('full')
            await tx.execute('INSERT INTO family_members (scope, user_id, family_id) VALUES ($1, $2, $3)',
                             ctx.scope, ctx.user_id, invite['family_id'])
            await tx.execute('DELETE FROM family_invites WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
    except _Stop as stop:
        return await ctx.respond({'none': 'ℹ У вас нет приглашений в семью', 'in_family': '❗ Вы уже состоите в семье',
                                  'full': '❗ В этой семье нет мест'}[str(stop)])
    await _show(ctx, intro='✅ Вы вступили в семью!\n\n')


async def _leave(ctx):
    fam = await get_family(ctx.db, ctx.scope, ctx.user_id)
    if fam is None:
        return await ctx.respond('ℹ Вы не состоите в семье')
    if fam['owner_id'] == ctx.user_id:
        return await ctx.respond('❗ Глава не может просто выйти. Распустите семью: /семья распустить '
                                 '(бюджет вернётся вам) или исключите всех участников.')
    await ctx.db.execute('DELETE FROM family_members WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
    await ctx.respond(f'👋 Вы вышли из семьи «{fam["name"]}»', ctx.kb().btn('🏠 Меню', 'menu'))


async def _disband(ctx):
    fam = await get_family(ctx.db, ctx.scope, ctx.user_id)
    if fam is None or fam['owner_id'] != ctx.user_id:
        return await ctx.respond('❗ Распустить семью может только её глава')
    async with ctx.db.transaction() as tx:
        row = await tx.fetchrow('DELETE FROM families WHERE id=$1 AND owner_id=$2 RETURNING budget', fam['id'], ctx.user_id)
        if row is None:
            return await ctx.respond('⚠ Семья уже распущена')
        await tx.execute('DELETE FROM family_members WHERE family_id=$1', fam['id'])
        await tx.execute('DELETE FROM family_invites WHERE family_id=$1', fam['id'])
        if row['budget']:
            await accounts.change(tx, ctx.scope, ctx.user_id, row['budget'], 'rub', 'family', 'роспуск семьи')
    await ctx.respond(f'💔 Семья «{fam["name"]}» распущена. Бюджет ({rub(fam["budget"])}) возвращён главе.',
                      ctx.kb().btn('🏠 Меню', 'menu'))


async def _kick(ctx):
    fam = await get_family(ctx.db, ctx.scope, ctx.user_id)
    if fam is None or fam['owner_id'] != ctx.user_id:
        return await ctx.respond('❗ Исключать может только глава семьи')
    target, _ = await ctx.target(register=False)
    if target is None or target == ctx.user_id:
        return await ctx.respond('❗ Укажите участника: /семья исключить @имя')
    row = await ctx.db.fetchrow(
        'DELETE FROM family_members WHERE scope=$1 AND user_id=$2 AND family_id=$3 RETURNING user_id',
        ctx.scope, target, fam['id'])
    if row is None:
        return await ctx.respond('❗ Этого игрока нет в вашей семье')
    await ctx.respond(f'✅ {await ctx.mention(target)} исключён(а) из семьи')


# ---------------------------------------------------------------------------
# /бюджет
# ---------------------------------------------------------------------------

@registry.command('budget', names=['бюджет'], desc='семейный бюджет', section='family',
                  usage='[положить|снять <сумма>]')
async def cmd_budget(ctx):
    w = await ctx.wallet()
    fam = await get_family(ctx.db, ctx.scope, ctx.user_id)
    if fam is None:
        return await ctx.respond('❗ У вас нет семьи. Создайте её: /семья создать <название>',
                                 ctx.kb().btn('👨‍👩‍👧 Семья', 'family').btn('🏠 Меню', 'menu'))
    argv = [a.lower() for a in ctx.argv]
    intro = ''
    if argv:
        action = 'in'
        if argv[0] in ('снять', 'вывести', '-', 'out'):
            action = 'out'
        if argv[0] in ('положить', 'внести', '+', 'in', 'снять', 'вывести', '-', 'out'):
            argv = argv[1:]
        if not argv:
            return await ctx.respond('❗ Укажите сумму. Пример: /бюджет положить 1000')
        if action == 'in':
            amount = _value(argv[0], w['rub'])
            amount = int(amount) if amount else 0
            if amount <= 0:
                return await ctx.respond('❗ Укажите сумму. Пример: /бюджет положить 1000')
            async with ctx.db.transaction() as tx:
                if await accounts.change(tx, ctx.scope, ctx.user_id, -amount, 'rub', 'family', 'в бюджет семьи') is None:
                    return await ctx.respond(f'❗ Недостаточно средств. На руках {rub(w["rub"])}')
                await tx.execute('UPDATE families SET budget = budget + $2 WHERE id=$1', fam['id'], amount)
            intro = f'✅ В бюджет внесено: {rub(amount)}\n\n'
        else:
            if fam['owner_id'] != ctx.user_id:
                return await ctx.respond('❗ Снимать деньги из бюджета может только глава семьи')
            amount = _value(argv[0], fam['budget'])
            amount = int(amount) if amount else 0
            if amount <= 0:
                return await ctx.respond('❗ Укажите сумму. Пример: /бюджет снять 1000')
            async with ctx.db.transaction() as tx:
                row = await tx.fetchrow(
                    'UPDATE families SET budget = budget - $2 WHERE id=$1 AND budget >= $2 RETURNING budget',
                    fam['id'], amount)
                if row is None:
                    return await ctx.respond(f'❗ В бюджете только {rub(fam["budget"])}')
                await accounts.change(tx, ctx.scope, ctx.user_id, amount, 'rub', 'family', 'из бюджета семьи')
            intro = f'✅ Из бюджета снято: {rub(amount)}\n\n'
        fam = await get_family(ctx.db, ctx.scope, ctx.user_id)
        w = await ctx.wallet()

    lines = [f'{intro}💰 Бюджет семьи «{fam["name"]}»\n{SEP}', f'В бюджете: {rub(fam["budget"])}',
             f'У вас на руках: {rub(w["rub"])}', '',
             'Внести: /бюджет положить <сумма>' + ('\nСнять (глава): /бюджет снять <сумма>' if fam['owner_id'] == ctx.user_id else '')]
    kb = (ctx.kb().btn('➕ 1 000', 'budget', 'положить 1000', color='positive').btn('➕ 10 000', 'budget', 'положить 10000', color='positive')
          .btn('➕ 50%', 'budget', 'положить 50%'))
    if fam['owner_id'] == ctx.user_id:
        kb.row().btn('➖ 50%', 'budget', 'снять 50%', color='negative').btn('➖ Всё', 'budget', 'снять все', color='negative')
    kb.row().btn('👨‍👩‍👧 Семья', 'family').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)
