"""Разбор того, как пользователь указывает другого человека: @имя, ссылка, id, упоминание, ответ на сообщение."""
import re
from dataclasses import dataclass

TOKEN_RE = re.compile(r'\[[^\]]*\]|\S+')
_MENTION_RE = re.compile(r'^\[([^\[\]|\s]+)\|[^\[\]]*\]$')
_URL_RE = re.compile(r'^(?:https?://)?(?:(?:www|m)\.)?(?:vk\.com|vk\.ru|vkontakte\.ru)/([^/?#\s]+)', re.IGNORECASE)
_NUMERIC_ID_RE = re.compile(r'^(?:id)?(\d+)$', re.IGNORECASE)
_COMMUNITY_RE = re.compile(r'^(?:club|public|event)\d+$', re.IGNORECASE)
_SCREEN_NAME_RE = re.compile(r'^[A-Za-z0-9_.]{1,32}$')


@dataclass(frozen=True)
class VkTarget:
    vk_id: int | None = None
    screen_name: str | None = None


def tokenize(text: str) -> list[str]:
    """Делит строку на слова, оставляя упоминание [id1|Имя Фамилия] одним словом."""
    return TOKEN_RE.findall(text or '')


def parse_target(raw: str | None) -> VkTarget | None:
    if not raw:
        return None
    token = raw.strip()
    mention = _MENTION_RE.match(token)
    if mention:
        token = mention.group(1)
    else:
        url = _URL_RE.match(token)
        if url:
            token = url.group(1)
    token = token.lstrip('@*')
    numeric = _NUMERIC_ID_RE.match(token)
    if numeric:
        vk_id = int(numeric.group(1))
        return VkTarget(vk_id=vk_id) if vk_id > 0 else None
    if _COMMUNITY_RE.match(token):
        return None
    if _SCREEN_NAME_RE.match(token):
        return VkTarget(screen_name=token)
    return None


def is_explicit_target(token: str) -> bool:
    """Похоже ли слово на однозначное указание человека (а не на число-сумму)."""
    if token.startswith('[') or token.startswith('@') or token.startswith('*'):
        return True
    if _URL_RE.match(token):
        return True
    if re.match(r'^id\d+$', token, re.IGNORECASE):
        return True
    return bool(re.match(r'^\d{6,}$', token))
