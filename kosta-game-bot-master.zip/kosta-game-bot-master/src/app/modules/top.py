"""Рейтинги: топ игроков по балансу и топ кланов."""
from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, mention, rub

MEDALS = ['🥇', '🥈', '🥉']
CLAN_WORDS = ('клан', 'кланы', 'clan', 'clans', 'кланов')


def _tabs(ctx, current: str):
    kb = ctx.kb()
    kb.btn('💰 Игроки', 'top', 'игроки', color='primary' if current == 'users' else 'secondary')
    kb.btn('⚔ Кланы', 'top', 'клан', color='primary' if current == 'clans' else 'secondary')
    kb.row().btn('🏆 Форбс', 'forbes').btn('🏠 Меню', 'menu')
    return kb


async def top_users(ctx) -> None:
    rows = await ctx.db.fetch(
        'SELECT w.user_id, w.rub FROM wallets w JOIN users u ON u.id = w.user_id '
        'WHERE w.scope=$1 AND u.banned=0 ORDER BY w.rub DESC, w.user_id LIMIT 10', ctx.scope)
    place = 'этой беседы' if ctx.is_chat else 'личных сообщений'
    lines = [f'🏆 Топ игроков по балансу ({place})\n{SEP}']
    if not rows:
        lines.append('Пока никого нет. Станьте первым!')
    for i, r in enumerate(rows):
        mark = MEDALS[i] if i < 3 else f'{i + 1}.'
        lines.append(f'{mark} {mention(r["user_id"], await accounts.display_name(ctx.app, r["user_id"]))} - {rub(r["rub"])}')
    mine = await ctx.db.fetchval('SELECT rub FROM wallets WHERE scope=$1 AND user_id=$2', ctx.scope, ctx.user_id)
    if mine is not None and ctx.user_id not in {r['user_id'] for r in rows}:
        better = await ctx.db.fetchval(
            'SELECT COUNT(*) FROM wallets w JOIN users u ON u.id = w.user_id WHERE w.scope=$1 AND u.banned=0 AND w.rub > $2',
            ctx.scope, mine)
        lines.append(f'…\n{better + 1}. Вы - {rub(mine)}')
    lines.append('\nКто богаче с учётом имущества и бумаг - смотрите /форбс')
    await ctx.respond('\n'.join(lines), _tabs(ctx, 'users'))


async def top_clans(ctx) -> None:
    rows = await ctx.db.fetch(
        'SELECT c.id, c.name, c.trophies, c.wins, c.losses, c.level, '
        '(SELECT COUNT(*) FROM clan_members m WHERE m.clan_id = c.id) AS members '
        'FROM clans c WHERE c.scope=$1 ORDER BY c.trophies DESC, c.wins DESC, c.id LIMIT 10', ctx.scope)
    lines = [f'⚔ Топ кланов\n{SEP}']
    if not rows:
        lines.append('Кланов пока нет. Создайте первый: /клан создать <название>')
    for i, r in enumerate(rows):
        mark = MEDALS[i] if i < 3 else f'{i + 1}.'
        lines.append(f'{mark} «{r["name"]}» - 🏆 {r["trophies"]} · ур. {r["level"]} · 👥 {r["members"]} · '
                     f'побед {r["wins"]}')
    mine = await ctx.db.fetchrow(
        'SELECT c.id, c.trophies FROM clan_members m JOIN clans c ON c.id = m.clan_id WHERE m.scope=$1 AND m.user_id=$2',
        ctx.scope, ctx.user_id)
    if mine is not None and mine['id'] not in {r['id'] for r in rows}:
        better = await ctx.db.fetchval('SELECT COUNT(*) FROM clans WHERE scope=$1 AND trophies > $2', ctx.scope, mine['trophies'])
        lines.append(f'…\nВаш клан на {better + 1} месте')
    await ctx.respond('\n'.join(lines), _tabs(ctx, 'clans'))


@registry.command('top', names=['top', 'топ', 'рейтинг', 'leaders'], desc='топ игроков по балансу и топ кланов',
                  section='economy', usage='[клан]')
async def cmd_top(ctx):
    if ctx.args.strip().lower() in CLAN_WORDS:
        return await top_clans(ctx)
    await top_users(ctx)


@registry.command('clantop', names=['клантоп', 'clantop'], desc='топ кланов', section='economy')
async def cmd_clantop(ctx):
    await top_clans(ctx)
