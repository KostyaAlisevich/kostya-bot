from ..config import CHAT_BASE
from ..roles import global_to_chat_level
from ..services import accounts, chats
from ..util.fmt import mention
from .keyboards import KB
from .targets import is_explicit_target, parse_target, tokenize


class Ctx:
    """Контекст одной команды: кто, где, с какими аргументами и как ответить."""

    def __init__(self, app, peer_id: int, user_id: int, args: str = '', cmid: int | None = None,
                 via_button: bool = False, reply_from: int | None = None, fwd_from=(), user_row=None):
        self.app = app
        self.db = app.db
        self.peer_id = peer_id
        self.user_id = user_id
        self.args = args.strip()
        self.cmid = cmid
        self.via_button = via_button
        self.reply_from = reply_from
        self.fwd_from = list(fwd_from)
        self._user = user_row
        self._chat = None
        self._level = None

    # --- где мы ---
    @property
    def is_chat(self) -> bool:
        return self.peer_id >= CHAT_BASE

    @property
    def scope(self) -> int:
        """Экономический мир: 0 - личные сообщения, иначе peer_id беседы."""
        return self.peer_id if self.is_chat else 0

    @property
    def argv(self) -> list[str]:
        return tokenize(self.args)

    # --- ответы ---
    def kb(self) -> KB:
        return KB(self.user_id)

    async def send(self, text: str, kb: KB | None = None) -> bool:
        return await self.app.vk.send(self.peer_id, text, kb.to_json() if kb else None)

    async def respond(self, text: str, kb: KB | None = None) -> bool:
        """По кнопке редактирует сообщение с кнопкой, по команде отправляет новое."""
        kb_json = kb.to_json() if kb else None
        if self.via_button and self.cmid:
            if await self.app.vk.edit(self.peer_id, self.cmid, text, kb_json):
                return True
        return await self.app.vk.send(self.peer_id, text, kb_json)

    async def ask(self, kind: str, text: str, kb: KB | None = None, **data) -> None:
        """Задать вопрос: следующее сообщение пользователя уйдёт в pending-обработчик kind."""
        self.app.pending.set(self.peer_id, self.user_id, kind, **data)
        await self.respond(text, kb)

    # --- данные о пользователе ---
    async def user(self):
        if self._user is None:
            self._user = await accounts.register_user(self.app, self.user_id, dm=not self.is_chat)
        return self._user

    async def role(self) -> int:
        return (await self.user())['role']

    async def chat(self):
        if self._chat is None and self.is_chat:
            self._chat = await chats.get_chat(self.db, self.peer_id)
        return self._chat

    async def chat_level(self) -> int:
        """Роль в беседе; в личных сообщениях - уровень, соответствующий должности бота."""
        if self._level is None:
            if self.is_chat:
                self._level = await chats.member_level(self.db, self.peer_id, self.user_id)
            else:
                self._level = global_to_chat_level(await self.role())
        return self._level

    async def wallet(self):
        return await accounts.ensure_wallet(self.db, self.scope, self.user_id)

    async def name(self, uid: int | None = None) -> str:
        return await accounts.display_name(self.app, uid or self.user_id)

    async def mention(self, uid: int | None = None) -> str:
        uid = uid or self.user_id
        return mention(uid, await accounts.display_name(self.app, uid))

    # --- цели команд ---
    async def target(self, register: bool = True) -> tuple[int | None, list[str]]:
        """Кого имел в виду автор: явное указание (@имя, ссылка, id, упоминание) в начале аргументов
        либо автор сообщения, на которое ответили. Возвращает (id | None, остальные аргументы)."""
        argv = self.argv
        if argv and is_explicit_target(argv[0]):
            return await self._resolve(argv[0], register), argv[1:]
        if self.reply_from and self.reply_from > 0:
            return await self._resolve_id(self.reply_from, register), argv
        if self.fwd_from and self.fwd_from[0] > 0:
            return await self._resolve_id(self.fwd_from[0], register), argv
        if argv:
            parsed = parse_target(argv[0])
            if parsed is not None:
                return await self._resolve(argv[0], register), argv[1:]
        return None, argv

    async def _resolve(self, token: str, register: bool) -> int | None:
        parsed = parse_target(token)
        if parsed is None:
            return None
        uid = parsed.vk_id
        if uid is None:
            uid = await self.app.vk.resolve(parsed.screen_name)
        return await self._resolve_id(uid, register) if uid else None

    async def _resolve_id(self, uid: int, register: bool) -> int | None:
        if not register:
            return uid
        row = await accounts.ensure_target(self.app, uid)
        return uid if row is not None else None
